

```python
%matplotlib inline
import random, datetime
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
import statsmodels.api as sm
from scipy.stats import norm
from scipy.stats.stats import pearsonr
```


```python
# str, int, float
str(3) #, 3
```




    '3'




```python
"chengjun wang"
```




    'chengjun wang'




```python
# int
int('5')
```




    5




```python
# float
float('7.1')
```




    7.1




```python
range(10)
# for i in range(10):
#     print(i)
```




    range(0, 10)




```python
# for i in range(1, 10):
#     print(i)

range(1,10)
```




    range(1, 10)




```python
#dir
```


```python
dir(str)[-10:]
```




    ['rstrip',
     'split',
     'splitlines',
     'startswith',
     'strip',
     'swapcase',
     'title',
     'translate',
     'upper',
     'zfill']




```python
help(str)
```

    Help on class str in module builtins:
    
    class str(object)
     |  str(object='') -> str
     |  str(bytes_or_buffer[, encoding[, errors]]) -> str
     |  
     |  Create a new string object from the given object. If encoding or
     |  errors is specified, then the object must expose a data buffer
     |  that will be decoded using the given encoding and error handler.
     |  Otherwise, returns the result of object.__str__() (if defined)
     |  or repr(object).
     |  encoding defaults to sys.getdefaultencoding().
     |  errors defaults to 'strict'.
     |  
     |  Methods defined here:
     |  
     |  __add__(self, value, /)
     |      Return self+value.
     |  
     |  __contains__(self, key, /)
     |      Return key in self.
     |  
     |  __eq__(self, value, /)
     |      Return self==value.
     |  
     |  __format__(self, format_spec, /)
     |      Return a formatted version of the string as described by format_spec.
     |  
     |  __ge__(self, value, /)
     |      Return self>=value.
     |  
     |  __getattribute__(self, name, /)
     |      Return getattr(self, name).
     |  
     |  __getitem__(self, key, /)
     |      Return self[key].
     |  
     |  __getnewargs__(...)
     |  
     |  __gt__(self, value, /)
     |      Return self>value.
     |  
     |  __hash__(self, /)
     |      Return hash(self).
     |  
     |  __iter__(self, /)
     |      Implement iter(self).
     |  
     |  __le__(self, value, /)
     |      Return self<=value.
     |  
     |  __len__(self, /)
     |      Return len(self).
     |  
     |  __lt__(self, value, /)
     |      Return self<value.
     |  
     |  __mod__(self, value, /)
     |      Return self%value.
     |  
     |  __mul__(self, value, /)
     |      Return self*value.
     |  
     |  __ne__(self, value, /)
     |      Return self!=value.
     |  
     |  __repr__(self, /)
     |      Return repr(self).
     |  
     |  __rmod__(self, value, /)
     |      Return value%self.
     |  
     |  __rmul__(self, value, /)
     |      Return value*self.
     |  
     |  __sizeof__(self, /)
     |      Return the size of the string in memory, in bytes.
     |  
     |  __str__(self, /)
     |      Return str(self).
     |  
     |  capitalize(self, /)
     |      Return a capitalized version of the string.
     |      
     |      More specifically, make the first character have upper case and the rest lower
     |      case.
     |  
     |  casefold(self, /)
     |      Return a version of the string suitable for caseless comparisons.
     |  
     |  center(self, width, fillchar=' ', /)
     |      Return a centered string of length width.
     |      
     |      Padding is done using the specified fill character (default is a space).
     |  
     |  count(...)
     |      S.count(sub[, start[, end]]) -> int
     |      
     |      Return the number of non-overlapping occurrences of substring sub in
     |      string S[start:end].  Optional arguments start and end are
     |      interpreted as in slice notation.
     |  
     |  encode(self, /, encoding='utf-8', errors='strict')
     |      Encode the string using the codec registered for encoding.
     |      
     |      encoding
     |        The encoding in which to encode the string.
     |      errors
     |        The error handling scheme to use for encoding errors.
     |        The default is 'strict' meaning that encoding errors raise a
     |        UnicodeEncodeError.  Other possible values are 'ignore', 'replace' and
     |        'xmlcharrefreplace' as well as any other name registered with
     |        codecs.register_error that can handle UnicodeEncodeErrors.
     |  
     |  endswith(...)
     |      S.endswith(suffix[, start[, end]]) -> bool
     |      
     |      Return True if S ends with the specified suffix, False otherwise.
     |      With optional start, test S beginning at that position.
     |      With optional end, stop comparing S at that position.
     |      suffix can also be a tuple of strings to try.
     |  
     |  expandtabs(self, /, tabsize=8)
     |      Return a copy where all tab characters are expanded using spaces.
     |      
     |      If tabsize is not given, a tab size of 8 characters is assumed.
     |  
     |  find(...)
     |      S.find(sub[, start[, end]]) -> int
     |      
     |      Return the lowest index in S where substring sub is found,
     |      such that sub is contained within S[start:end].  Optional
     |      arguments start and end are interpreted as in slice notation.
     |      
     |      Return -1 on failure.
     |  
     |  format(...)
     |      S.format(*args, **kwargs) -> str
     |      
     |      Return a formatted version of S, using substitutions from args and kwargs.
     |      The substitutions are identified by braces ('{' and '}').
     |  
     |  format_map(...)
     |      S.format_map(mapping) -> str
     |      
     |      Return a formatted version of S, using substitutions from mapping.
     |      The substitutions are identified by braces ('{' and '}').
     |  
     |  index(...)
     |      S.index(sub[, start[, end]]) -> int
     |      
     |      Return the lowest index in S where substring sub is found, 
     |      such that sub is contained within S[start:end].  Optional
     |      arguments start and end are interpreted as in slice notation.
     |      
     |      Raises ValueError when the substring is not found.
     |  
     |  isalnum(self, /)
     |      Return True if the string is an alpha-numeric string, False otherwise.
     |      
     |      A string is alpha-numeric if all characters in the string are alpha-numeric and
     |      there is at least one character in the string.
     |  
     |  isalpha(self, /)
     |      Return True if the string is an alphabetic string, False otherwise.
     |      
     |      A string is alphabetic if all characters in the string are alphabetic and there
     |      is at least one character in the string.
     |  
     |  isascii(self, /)
     |      Return True if all characters in the string are ASCII, False otherwise.
     |      
     |      ASCII characters have code points in the range U+0000-U+007F.
     |      Empty string is ASCII too.
     |  
     |  isdecimal(self, /)
     |      Return True if the string is a decimal string, False otherwise.
     |      
     |      A string is a decimal string if all characters in the string are decimal and
     |      there is at least one character in the string.
     |  
     |  isdigit(self, /)
     |      Return True if the string is a digit string, False otherwise.
     |      
     |      A string is a digit string if all characters in the string are digits and there
     |      is at least one character in the string.
     |  
     |  isidentifier(self, /)
     |      Return True if the string is a valid Python identifier, False otherwise.
     |      
     |      Use keyword.iskeyword() to test for reserved identifiers such as "def" and
     |      "class".
     |  
     |  islower(self, /)
     |      Return True if the string is a lowercase string, False otherwise.
     |      
     |      A string is lowercase if all cased characters in the string are lowercase and
     |      there is at least one cased character in the string.
     |  
     |  isnumeric(self, /)
     |      Return True if the string is a numeric string, False otherwise.
     |      
     |      A string is numeric if all characters in the string are numeric and there is at
     |      least one character in the string.
     |  
     |  isprintable(self, /)
     |      Return True if the string is printable, False otherwise.
     |      
     |      A string is printable if all of its characters are considered printable in
     |      repr() or if it is empty.
     |  
     |  isspace(self, /)
     |      Return True if the string is a whitespace string, False otherwise.
     |      
     |      A string is whitespace if all characters in the string are whitespace and there
     |      is at least one character in the string.
     |  
     |  istitle(self, /)
     |      Return True if the string is a title-cased string, False otherwise.
     |      
     |      In a title-cased string, upper- and title-case characters may only
     |      follow uncased characters and lowercase characters only cased ones.
     |  
     |  isupper(self, /)
     |      Return True if the string is an uppercase string, False otherwise.
     |      
     |      A string is uppercase if all cased characters in the string are uppercase and
     |      there is at least one cased character in the string.
     |  
     |  join(self, iterable, /)
     |      Concatenate any number of strings.
     |      
     |      The string whose method is called is inserted in between each given string.
     |      The result is returned as a new string.
     |      
     |      Example: '.'.join(['ab', 'pq', 'rs']) -> 'ab.pq.rs'
     |  
     |  ljust(self, width, fillchar=' ', /)
     |      Return a left-justified string of length width.
     |      
     |      Padding is done using the specified fill character (default is a space).
     |  
     |  lower(self, /)
     |      Return a copy of the string converted to lowercase.
     |  
     |  lstrip(self, chars=None, /)
     |      Return a copy of the string with leading whitespace removed.
     |      
     |      If chars is given and not None, remove characters in chars instead.
     |  
     |  partition(self, sep, /)
     |      Partition the string into three parts using the given separator.
     |      
     |      This will search for the separator in the string.  If the separator is found,
     |      returns a 3-tuple containing the part before the separator, the separator
     |      itself, and the part after it.
     |      
     |      If the separator is not found, returns a 3-tuple containing the original string
     |      and two empty strings.
     |  
     |  replace(self, old, new, count=-1, /)
     |      Return a copy with all occurrences of substring old replaced by new.
     |      
     |        count
     |          Maximum number of occurrences to replace.
     |          -1 (the default value) means replace all occurrences.
     |      
     |      If the optional argument count is given, only the first count occurrences are
     |      replaced.
     |  
     |  rfind(...)
     |      S.rfind(sub[, start[, end]]) -> int
     |      
     |      Return the highest index in S where substring sub is found,
     |      such that sub is contained within S[start:end].  Optional
     |      arguments start and end are interpreted as in slice notation.
     |      
     |      Return -1 on failure.
     |  
     |  rindex(...)
     |      S.rindex(sub[, start[, end]]) -> int
     |      
     |      Return the highest index in S where substring sub is found,
     |      such that sub is contained within S[start:end].  Optional
     |      arguments start and end are interpreted as in slice notation.
     |      
     |      Raises ValueError when the substring is not found.
     |  
     |  rjust(self, width, fillchar=' ', /)
     |      Return a right-justified string of length width.
     |      
     |      Padding is done using the specified fill character (default is a space).
     |  
     |  rpartition(self, sep, /)
     |      Partition the string into three parts using the given separator.
     |      
     |      This will search for the separator in the string, starting at the end. If
     |      the separator is found, returns a 3-tuple containing the part before the
     |      separator, the separator itself, and the part after it.
     |      
     |      If the separator is not found, returns a 3-tuple containing two empty strings
     |      and the original string.
     |  
     |  rsplit(self, /, sep=None, maxsplit=-1)
     |      Return a list of the words in the string, using sep as the delimiter string.
     |      
     |        sep
     |          The delimiter according which to split the string.
     |          None (the default value) means split according to any whitespace,
     |          and discard empty strings from the result.
     |        maxsplit
     |          Maximum number of splits to do.
     |          -1 (the default value) means no limit.
     |      
     |      Splits are done starting at the end of the string and working to the front.
     |  
     |  rstrip(self, chars=None, /)
     |      Return a copy of the string with trailing whitespace removed.
     |      
     |      If chars is given and not None, remove characters in chars instead.
     |  
     |  split(self, /, sep=None, maxsplit=-1)
     |      Return a list of the words in the string, using sep as the delimiter string.
     |      
     |      sep
     |        The delimiter according which to split the string.
     |        None (the default value) means split according to any whitespace,
     |        and discard empty strings from the result.
     |      maxsplit
     |        Maximum number of splits to do.
     |        -1 (the default value) means no limit.
     |  
     |  splitlines(self, /, keepends=False)
     |      Return a list of the lines in the string, breaking at line boundaries.
     |      
     |      Line breaks are not included in the resulting list unless keepends is given and
     |      true.
     |  
     |  startswith(...)
     |      S.startswith(prefix[, start[, end]]) -> bool
     |      
     |      Return True if S starts with the specified prefix, False otherwise.
     |      With optional start, test S beginning at that position.
     |      With optional end, stop comparing S at that position.
     |      prefix can also be a tuple of strings to try.
     |  
     |  strip(self, chars=None, /)
     |      Return a copy of the string with leading and trailing whitespace remove.
     |      
     |      If chars is given and not None, remove characters in chars instead.
     |  
     |  swapcase(self, /)
     |      Convert uppercase characters to lowercase and lowercase characters to uppercase.
     |  
     |  title(self, /)
     |      Return a version of the string where each word is titlecased.
     |      
     |      More specifically, words start with uppercased characters and all remaining
     |      cased characters have lower case.
     |  
     |  translate(self, table, /)
     |      Replace each character in the string using the given translation table.
     |      
     |        table
     |          Translation table, which must be a mapping of Unicode ordinals to
     |          Unicode ordinals, strings, or None.
     |      
     |      The table must implement lookup/indexing via __getitem__, for instance a
     |      dictionary or list.  If this operation raises LookupError, the character is
     |      left untouched.  Characters mapped to None are deleted.
     |  
     |  upper(self, /)
     |      Return a copy of the string converted to uppercase.
     |  
     |  zfill(self, width, /)
     |      Pad a numeric string with zeros on the left, to fill a field of the given width.
     |      
     |      The string is never truncated.
     |  
     |  ----------------------------------------------------------------------
     |  Static methods defined here:
     |  
     |  __new__(*args, **kwargs) from builtins.type
     |      Create and return a new object.  See help(type) for accurate signature.
     |  
     |  maketrans(x, y=None, z=None, /)
     |      Return a translation table usable for str.translate().
     |      
     |      If there is only one argument, it must be a dictionary mapping Unicode
     |      ordinals (integers) or characters to Unicode ordinals, strings or None.
     |      Character keys will be then converted to ordinals.
     |      If there are two arguments, they must be strings of equal length, and
     |      in the resulting dictionary, each character in x will be mapped to the
     |      character at the same position in y. If there is a third argument, it
     |      must be a string, whose characters will be mapped to None in the result.
    
    


```python
x = ' Hello WorlD  '
dir(x)[-10:]
```




    ['rstrip',
     'split',
     'splitlines',
     'startswith',
     'strip',
     'swapcase',
     'title',
     'translate',
     'upper',
     'zfill']




```python

# lower
x.lower()
```




    ' hello world  '




```python
# upper
x.upper()
```




    ' HELLO WORLD  '




```python

# rstrip
x.rstrip()
```




    ' Hello WorlD'




```python
# strip
x.strip()
```




    'Hello WorlD'




```python

# replace
x.replace('lo', '')
```




    ' Hel WorlD  '




```python
# split
x.split('lo')
```




    [' Hel', ' WorlD  ']




```python
# join 
','.join(['a', 'b'])
#?x.split
```




    'a,b'




```python
x = 'hello world'
type(x)
```




    str




```python
l = [1,2,3,3] # list
t = (1, 2, 3, 3) # tuple
s = {1, 2, 3, 3}
#s = set([1,2,3,3]) # set
d = {'a':1,'b':2,'c':3} # dict
a = np.array(l) # array
print(l, t, s, d, a)
```

    [1, 2, 3, 3] (1, 2, 3, 3) {1, 2, 3} {'a': 1, 'b': 2, 'c': 3} [1 2 3 3]
    


```python

l = [1,2,3,3] # list
l.append(4)
l
```




    [1, 2, 3, 3, 4]




```python
d = {'a':1,'b':2,'c':3} # dict
d.keys()
```




    dict_keys(['a', 'b', 'c'])




```python

d = {'a':1,'b':2,'c':3} # dict
d.values()
```




    dict_values([1, 2, 3])




```python
d = {'a':1,'b':2,'c':3} # dict
d['b']
```




    2




```python
d = {'a':1,'b':2,'c':3} # dict
d.items()
```




    dict_items([('a', 1), ('b', 2), ('c', 3)])




```python
def devidePlus(m, n): # 结尾是冒号
    y = m/n + 1 # 注意：空格
    return y          # 注意：return
```


```python
range(10)
```




    range(0, 10)




```python
range(1, 10)
```




    range(1, 10)




```python
for i in range(10):
    print(i, i*10, i**2)
```

    0 0 0
    1 10 1
    2 20 4
    3 30 9
    4 40 16
    5 50 25
    6 60 36
    7 70 49
    8 80 64
    9 90 81
    


```python
for i in range(10):
    print(i*10)
```

    0
    10
    20
    30
    40
    50
    60
    70
    80
    90
    


```python
for i in range(10):
    print(devidePlus(i, 2))
```

    1.0
    1.5
    2.0
    2.5
    3.0
    3.5
    4.0
    4.5
    5.0
    5.5
    


```python
# 列表内部的for循环
r = [devidePlus(i, 2)  for i in range(10)]
r
```




    [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5]




```python
m1 = map(devidePlus, [4,3,2], [2, 1, 5])
print(*m1)
#print(*map(devidePlus, [4,3,2], [2, 1, 5]))
# 注意： 将（4， 2)作为一个组合进行计算，将（3， 1）作为一个组合进行计算
```

    3.0 4.0 1.4
    


```python
m2 = map(lambda x, y: x + y, [1, 3, 5, 7, 9], [2, 4, 6, 8, 10])
print(*m2)
```

    3 7 11 15 19
    


```python
m3 = map(lambda x, y, z: x + y - z, [1, 3, 5, 7, 9], [2, 4, 6, 8, 10], [3, 3, 2, 2, 5])
print(*m3)
```

    0 4 9 13 14
    


```python

j = 5
if j%2 == 1:
    print(r'余数是1')
elif j%2 ==0:
    print(r'余数是0')
else:
    print(r'余数既不是1也不是0')
```

    余数是1
    


```python
x = 5
if x < 5:
    y = -1
    z = 5
elif x > 5:
    y = 1
    z = 11
else:
    y = 0
    z = 10
print(x, y, z)
```

    5 0 10
    


```python
j = 0
while j <10:
    print(j)
    j +=  1 # avoid dead loop
```

    0
    1
    2
    3
    4
    5
    6
    7
    8
    9
    


```python
j = 0
while j <10:
    if j%2 != 0: 
        print(j**2)
    j+=1 # avoid dead loop
```

    1
    9
    25
    49
    81
    


```python

j = 0
while j <50:
    if j == 30:
        break
    if j%2 != 0: 
        print(j**2)
    j+=1 # avoid dead loop
```

    1
    9
    25
    49
    81
    121
    169
    225
    289
    361
    441
    529
    625
    729
    841
    


```python
a = 4
while a: # 0, None, False
    print(a) 
    a -= 1
    if a < 2:
        a = None #, False, None # []
```

    4
    3
    2
    


```python
def devidePlus(m, n): # 结尾是冒号
    return m/n+ 1 # 注意：空格


for i in [2, 0, 5]:
    #print(devidePlus(4, i))
    try:
        print(devidePlus(4, i))
    except Exception as e:
        print(e)
        pass
```

    3.0
    division by zero
    1.8
    


```python
alist = [[1,1], [0, 0, 1]]
for aa in alist:
    try:
        for a in aa:
            print(10 / a)
    except Exception as e:
        print(e)
        pass
```

    10.0
    10.0
    division by zero
    


```python
alist = [[1,1], [0, 0, 1]]
for aa in alist:
    for a in aa:
        try:
            print(10 / a)
        except Exception as e:
            print(e)
            pass
```

    10.0
    10.0
    division by zero
    division by zero
    10.0
    


```python
data =[[i, i**2, i**3] for i in range(10)] 
data
```




    [[0, 0, 0],
     [1, 1, 1],
     [2, 4, 8],
     [3, 9, 27],
     [4, 16, 64],
     [5, 25, 125],
     [6, 36, 216],
     [7, 49, 343],
     [8, 64, 512],
     [9, 81, 729]]




```python
for i in data:
    print('\t'.join(map(str, i)))
```

    0	0	0
    1	1	1
    2	4	8
    3	9	27
    4	16	64
    5	25	125
    6	36	216
    7	49	343
    8	64	512
    9	81	729
    


```python
type(data)
```




    list




```python

len(data)
```




    10




```python

data[0]
```




    [0, 0, 0]




```python
#help(f.write)
```


```python
# 保存数据
data =[[i, i**2, i**3] for i in range(10000)] 

f = open("data_write_to_file.txt", "w")
for i in data:
    f.write('\t'.join(map(str,i)) + '\n')
f.close()
```


```python
with open('data_write_to_file.txt','r') as f:
    data = f.readlines()
data[:5]
```




    ['0\t0\t0\n', '1\t1\t1\n', '2\t4\t8\n', '3\t9\t27\n', '4\t16\t64\n']




```python
with open('data_write_to_file.txt','r') as f:
    data = f.readlines(1000)
len(data)
```




    77




```python
with open('data_write_to_file.txt','r') as f:
    print(f.readline())
```

    0	0	0
    
    


```python
f = [1, 2, 3, 4, 5]
for k, i in enumerate(f):
    print(k, i)
```

    0 1
    1 2
    2 3
    3 4
    4 5
    


```python
with open('data_write_to_file.txt','r') as f:
    for i in f:
        print(i)
```

    0	0	0
    
    1	1	1
    
    2	4	8
    
    3	9	27
    
    4	16	64
    
    5	25	125
    
    6	36	216
    
    7	49	343
    
    8	64	512
    
    9	81	729
    
    10	100	1000
    
    11	121	1331
    
    12	144	1728
    
    13	169	2197
    
    14	196	2744
    
    15	225	3375
    
    16	256	4096
    
    17	289	4913
    
    18	324	5832
    
    19	361	6859
    
    20	400	8000
    
    21	441	9261
    
    22	484	10648
    
    23	529	12167
    
    24	576	13824
    
    25	625	15625
    
    26	676	17576
    
    27	729	19683
    
    28	784	21952
    
    29	841	24389
    
    30	900	27000
    
    31	961	29791
    
    32	1024	32768
    
    33	1089	35937
    
    34	1156	39304
    
    35	1225	42875
    
    36	1296	46656
    
    37	1369	50653
    
    38	1444	54872
    
    39	1521	59319
    
    40	1600	64000
    
    41	1681	68921
    
    42	1764	74088
    
    43	1849	79507
    
    44	1936	85184
    
    45	2025	91125
    
    46	2116	97336
    
    47	2209	103823
    
    48	2304	110592
    
    49	2401	117649
    
    50	2500	125000
    
    51	2601	132651
    
    52	2704	140608
    
    53	2809	148877
    
    54	2916	157464
    
    55	3025	166375
    
    56	3136	175616
    
    57	3249	185193
    
    58	3364	195112
    
    59	3481	205379
    
    60	3600	216000
    
    61	3721	226981
    
    62	3844	238328
    
    63	3969	250047
    
    64	4096	262144
    
    65	4225	274625
    
    66	4356	287496
    
    67	4489	300763
    
    68	4624	314432
    
    69	4761	328509
    
    70	4900	343000
    
    71	5041	357911
    
    72	5184	373248
    
    73	5329	389017
    
    74	5476	405224
    
    75	5625	421875
    
    76	5776	438976
    
    77	5929	456533
    
    78	6084	474552
    
    79	6241	493039
    
    80	6400	512000
    
    81	6561	531441
    
    82	6724	551368
    
    83	6889	571787
    
    84	7056	592704
    
    85	7225	614125
    
    86	7396	636056
    
    87	7569	658503
    
    88	7744	681472
    
    89	7921	704969
    
    90	8100	729000
    
    91	8281	753571
    
    92	8464	778688
    
    93	8649	804357
    
    94	8836	830584
    
    95	9025	857375
    
    96	9216	884736
    
    97	9409	912673
    
    98	9604	941192
    
    99	9801	970299
    
    100	10000	1000000
    
    101	10201	1030301
    
    102	10404	1061208
    
    103	10609	1092727
    
    104	10816	1124864
    
    105	11025	1157625
    
    106	11236	1191016
    
    107	11449	1225043
    
    108	11664	1259712
    
    109	11881	1295029
    
    110	12100	1331000
    
    111	12321	1367631
    
    112	12544	1404928
    
    113	12769	1442897
    
    114	12996	1481544
    
    115	13225	1520875
    
    116	13456	1560896
    
    117	13689	1601613
    
    118	13924	1643032
    
    119	14161	1685159
    
    120	14400	1728000
    
    121	14641	1771561
    
    122	14884	1815848
    
    123	15129	1860867
    
    124	15376	1906624
    
    125	15625	1953125
    
    126	15876	2000376
    
    127	16129	2048383
    
    128	16384	2097152
    
    129	16641	2146689
    
    130	16900	2197000
    
    131	17161	2248091
    
    132	17424	2299968
    
    133	17689	2352637
    
    134	17956	2406104
    
    135	18225	2460375
    
    136	18496	2515456
    
    137	18769	2571353
    
    138	19044	2628072
    
    139	19321	2685619
    
    140	19600	2744000
    
    141	19881	2803221
    
    142	20164	2863288
    
    143	20449	2924207
    
    144	20736	2985984
    
    145	21025	3048625
    
    146	21316	3112136
    
    147	21609	3176523
    
    148	21904	3241792
    
    149	22201	3307949
    
    150	22500	3375000
    
    151	22801	3442951
    
    152	23104	3511808
    
    153	23409	3581577
    
    154	23716	3652264
    
    155	24025	3723875
    
    156	24336	3796416
    
    157	24649	3869893
    
    158	24964	3944312
    
    159	25281	4019679
    
    160	25600	4096000
    
    161	25921	4173281
    
    162	26244	4251528
    
    163	26569	4330747
    
    164	26896	4410944
    
    165	27225	4492125
    
    166	27556	4574296
    
    167	27889	4657463
    
    168	28224	4741632
    
    169	28561	4826809
    
    170	28900	4913000
    
    171	29241	5000211
    
    172	29584	5088448
    
    173	29929	5177717
    
    174	30276	5268024
    
    175	30625	5359375
    
    176	30976	5451776
    
    177	31329	5545233
    
    178	31684	5639752
    
    179	32041	5735339
    
    180	32400	5832000
    
    181	32761	5929741
    
    182	33124	6028568
    
    183	33489	6128487
    
    184	33856	6229504
    
    185	34225	6331625
    
    186	34596	6434856
    
    187	34969	6539203
    
    188	35344	6644672
    
    189	35721	6751269
    
    190	36100	6859000
    
    191	36481	6967871
    
    192	36864	7077888
    
    193	37249	7189057
    
    194	37636	7301384
    
    195	38025	7414875
    
    196	38416	7529536
    
    197	38809	7645373
    
    198	39204	7762392
    
    199	39601	7880599
    
    200	40000	8000000
    
    201	40401	8120601
    
    202	40804	8242408
    
    203	41209	8365427
    
    204	41616	8489664
    
    205	42025	8615125
    
    206	42436	8741816
    
    207	42849	8869743
    
    208	43264	8998912
    
    209	43681	9129329
    
    210	44100	9261000
    
    211	44521	9393931
    
    212	44944	9528128
    
    213	45369	9663597
    
    214	45796	9800344
    
    215	46225	9938375
    
    216	46656	10077696
    
    217	47089	10218313
    
    218	47524	10360232
    
    219	47961	10503459
    
    220	48400	10648000
    
    221	48841	10793861
    
    222	49284	10941048
    
    223	49729	11089567
    
    224	50176	11239424
    
    225	50625	11390625
    
    226	51076	11543176
    
    227	51529	11697083
    
    228	51984	11852352
    
    229	52441	12008989
    
    230	52900	12167000
    
    231	53361	12326391
    
    232	53824	12487168
    
    233	54289	12649337
    
    234	54756	12812904
    
    235	55225	12977875
    
    236	55696	13144256
    
    237	56169	13312053
    
    238	56644	13481272
    
    239	57121	13651919
    
    240	57600	13824000
    
    241	58081	13997521
    
    242	58564	14172488
    
    243	59049	14348907
    
    244	59536	14526784
    
    245	60025	14706125
    
    246	60516	14886936
    
    247	61009	15069223
    
    248	61504	15252992
    
    249	62001	15438249
    
    250	62500	15625000
    
    251	63001	15813251
    
    252	63504	16003008
    
    253	64009	16194277
    
    254	64516	16387064
    
    255	65025	16581375
    
    256	65536	16777216
    
    257	66049	16974593
    
    258	66564	17173512
    
    259	67081	17373979
    
    260	67600	17576000
    
    261	68121	17779581
    
    262	68644	17984728
    
    263	69169	18191447
    
    264	69696	18399744
    
    265	70225	18609625
    
    266	70756	18821096
    
    267	71289	19034163
    
    268	71824	19248832
    
    269	72361	19465109
    
    270	72900	19683000
    
    271	73441	19902511
    
    272	73984	20123648
    
    273	74529	20346417
    
    274	75076	20570824
    
    275	75625	20796875
    
    276	76176	21024576
    
    277	76729	21253933
    
    278	77284	21484952
    
    279	77841	21717639
    
    280	78400	21952000
    
    281	78961	22188041
    
    282	79524	22425768
    
    283	80089	22665187
    
    284	80656	22906304
    
    285	81225	23149125
    
    286	81796	23393656
    
    287	82369	23639903
    
    288	82944	23887872
    
    289	83521	24137569
    
    290	84100	24389000
    
    291	84681	24642171
    
    292	85264	24897088
    
    293	85849	25153757
    
    294	86436	25412184
    
    295	87025	25672375
    
    296	87616	25934336
    
    297	88209	26198073
    
    298	88804	26463592
    
    299	89401	26730899
    
    300	90000	27000000
    
    301	90601	27270901
    
    302	91204	27543608
    
    303	91809	27818127
    
    304	92416	28094464
    
    305	93025	28372625
    
    306	93636	28652616
    
    307	94249	28934443
    
    308	94864	29218112
    
    309	95481	29503629
    
    310	96100	29791000
    
    311	96721	30080231
    
    312	97344	30371328
    
    313	97969	30664297
    
    314	98596	30959144
    
    315	99225	31255875
    
    316	99856	31554496
    
    317	100489	31855013
    
    318	101124	32157432
    
    319	101761	32461759
    
    320	102400	32768000
    
    321	103041	33076161
    
    322	103684	33386248
    
    323	104329	33698267
    
    324	104976	34012224
    
    325	105625	34328125
    
    326	106276	34645976
    
    327	106929	34965783
    
    328	107584	35287552
    
    329	108241	35611289
    
    330	108900	35937000
    
    331	109561	36264691
    
    332	110224	36594368
    
    333	110889	36926037
    
    334	111556	37259704
    
    335	112225	37595375
    
    336	112896	37933056
    
    337	113569	38272753
    
    338	114244	38614472
    
    339	114921	38958219
    
    340	115600	39304000
    
    341	116281	39651821
    
    342	116964	40001688
    
    343	117649	40353607
    
    344	118336	40707584
    
    345	119025	41063625
    
    346	119716	41421736
    
    347	120409	41781923
    
    348	121104	42144192
    
    349	121801	42508549
    
    350	122500	42875000
    
    351	123201	43243551
    
    352	123904	43614208
    
    353	124609	43986977
    
    354	125316	44361864
    
    355	126025	44738875
    
    356	126736	45118016
    
    357	127449	45499293
    
    358	128164	45882712
    
    359	128881	46268279
    
    360	129600	46656000
    
    361	130321	47045881
    
    362	131044	47437928
    
    363	131769	47832147
    
    364	132496	48228544
    
    365	133225	48627125
    
    366	133956	49027896
    
    367	134689	49430863
    
    368	135424	49836032
    
    369	136161	50243409
    
    370	136900	50653000
    
    371	137641	51064811
    
    372	138384	51478848
    
    373	139129	51895117
    
    374	139876	52313624
    
    375	140625	52734375
    
    376	141376	53157376
    
    377	142129	53582633
    
    378	142884	54010152
    
    379	143641	54439939
    
    380	144400	54872000
    
    381	145161	55306341
    
    382	145924	55742968
    
    383	146689	56181887
    
    384	147456	56623104
    
    385	148225	57066625
    
    386	148996	57512456
    
    387	149769	57960603
    
    388	150544	58411072
    
    389	151321	58863869
    
    390	152100	59319000
    
    391	152881	59776471
    
    392	153664	60236288
    
    393	154449	60698457
    
    394	155236	61162984
    
    395	156025	61629875
    
    396	156816	62099136
    
    397	157609	62570773
    
    398	158404	63044792
    
    399	159201	63521199
    
    400	160000	64000000
    
    401	160801	64481201
    
    402	161604	64964808
    
    403	162409	65450827
    
    404	163216	65939264
    
    405	164025	66430125
    
    406	164836	66923416
    
    407	165649	67419143
    
    408	166464	67917312
    
    409	167281	68417929
    
    410	168100	68921000
    
    411	168921	69426531
    
    412	169744	69934528
    
    413	170569	70444997
    
    414	171396	70957944
    
    415	172225	71473375
    
    416	173056	71991296
    
    417	173889	72511713
    
    418	174724	73034632
    
    419	175561	73560059
    
    420	176400	74088000
    
    421	177241	74618461
    
    422	178084	75151448
    
    423	178929	75686967
    
    424	179776	76225024
    
    425	180625	76765625
    
    426	181476	77308776
    
    427	182329	77854483
    
    428	183184	78402752
    
    429	184041	78953589
    
    430	184900	79507000
    
    431	185761	80062991
    
    432	186624	80621568
    
    433	187489	81182737
    
    434	188356	81746504
    
    435	189225	82312875
    
    436	190096	82881856
    
    437	190969	83453453
    
    438	191844	84027672
    
    439	192721	84604519
    
    440	193600	85184000
    
    441	194481	85766121
    
    442	195364	86350888
    
    443	196249	86938307
    
    444	197136	87528384
    
    445	198025	88121125
    
    446	198916	88716536
    
    447	199809	89314623
    
    448	200704	89915392
    
    449	201601	90518849
    
    450	202500	91125000
    
    451	203401	91733851
    
    452	204304	92345408
    
    453	205209	92959677
    
    454	206116	93576664
    
    455	207025	94196375
    
    456	207936	94818816
    
    457	208849	95443993
    
    458	209764	96071912
    
    459	210681	96702579
    
    460	211600	97336000
    
    461	212521	97972181
    
    462	213444	98611128
    
    463	214369	99252847
    
    464	215296	99897344
    
    465	216225	100544625
    
    466	217156	101194696
    
    467	218089	101847563
    
    468	219024	102503232
    
    469	219961	103161709
    
    470	220900	103823000
    
    471	221841	104487111
    
    472	222784	105154048
    
    473	223729	105823817
    
    474	224676	106496424
    
    475	225625	107171875
    
    476	226576	107850176
    
    477	227529	108531333
    
    478	228484	109215352
    
    479	229441	109902239
    
    480	230400	110592000
    
    481	231361	111284641
    
    482	232324	111980168
    
    483	233289	112678587
    
    484	234256	113379904
    
    485	235225	114084125
    
    486	236196	114791256
    
    487	237169	115501303
    
    488	238144	116214272
    
    489	239121	116930169
    
    490	240100	117649000
    
    491	241081	118370771
    
    492	242064	119095488
    
    493	243049	119823157
    
    494	244036	120553784
    
    495	245025	121287375
    
    496	246016	122023936
    
    497	247009	122763473
    
    498	248004	123505992
    
    499	249001	124251499
    
    500	250000	125000000
    
    501	251001	125751501
    
    502	252004	126506008
    
    503	253009	127263527
    
    504	254016	128024064
    
    505	255025	128787625
    
    506	256036	129554216
    
    507	257049	130323843
    
    508	258064	131096512
    
    509	259081	131872229
    
    510	260100	132651000
    
    511	261121	133432831
    
    512	262144	134217728
    
    513	263169	135005697
    
    514	264196	135796744
    
    515	265225	136590875
    
    516	266256	137388096
    
    517	267289	138188413
    
    518	268324	138991832
    
    519	269361	139798359
    
    520	270400	140608000
    
    521	271441	141420761
    
    522	272484	142236648
    
    523	273529	143055667
    
    524	274576	143877824
    
    525	275625	144703125
    
    526	276676	145531576
    
    527	277729	146363183
    
    528	278784	147197952
    
    529	279841	148035889
    
    530	280900	148877000
    
    531	281961	149721291
    
    532	283024	150568768
    
    533	284089	151419437
    
    534	285156	152273304
    
    535	286225	153130375
    
    536	287296	153990656
    
    537	288369	154854153
    
    538	289444	155720872
    
    539	290521	156590819
    
    540	291600	157464000
    
    541	292681	158340421
    
    542	293764	159220088
    
    543	294849	160103007
    
    544	295936	160989184
    
    545	297025	161878625
    
    546	298116	162771336
    
    547	299209	163667323
    
    548	300304	164566592
    
    549	301401	165469149
    
    550	302500	166375000
    
    551	303601	167284151
    
    552	304704	168196608
    
    553	305809	169112377
    
    554	306916	170031464
    
    555	308025	170953875
    
    556	309136	171879616
    
    557	310249	172808693
    
    558	311364	173741112
    
    559	312481	174676879
    
    560	313600	175616000
    
    561	314721	176558481
    
    562	315844	177504328
    
    563	316969	178453547
    
    564	318096	179406144
    
    565	319225	180362125
    
    566	320356	181321496
    
    567	321489	182284263
    
    568	322624	183250432
    
    569	323761	184220009
    
    570	324900	185193000
    
    571	326041	186169411
    
    572	327184	187149248
    
    573	328329	188132517
    
    574	329476	189119224
    
    575	330625	190109375
    
    576	331776	191102976
    
    577	332929	192100033
    
    578	334084	193100552
    
    579	335241	194104539
    
    580	336400	195112000
    
    581	337561	196122941
    
    582	338724	197137368
    
    583	339889	198155287
    
    584	341056	199176704
    
    585	342225	200201625
    
    586	343396	201230056
    
    587	344569	202262003
    
    588	345744	203297472
    
    589	346921	204336469
    
    590	348100	205379000
    
    591	349281	206425071
    
    592	350464	207474688
    
    593	351649	208527857
    
    594	352836	209584584
    
    595	354025	210644875
    
    596	355216	211708736
    
    597	356409	212776173
    
    598	357604	213847192
    
    599	358801	214921799
    
    600	360000	216000000
    
    601	361201	217081801
    
    602	362404	218167208
    
    603	363609	219256227
    
    604	364816	220348864
    
    605	366025	221445125
    
    606	367236	222545016
    
    607	368449	223648543
    
    608	369664	224755712
    
    609	370881	225866529
    
    610	372100	226981000
    
    611	373321	228099131
    
    612	374544	229220928
    
    613	375769	230346397
    
    614	376996	231475544
    
    615	378225	232608375
    
    616	379456	233744896
    
    617	380689	234885113
    
    618	381924	236029032
    
    619	383161	237176659
    
    620	384400	238328000
    
    621	385641	239483061
    
    622	386884	240641848
    
    623	388129	241804367
    
    624	389376	242970624
    
    625	390625	244140625
    
    626	391876	245314376
    
    627	393129	246491883
    
    628	394384	247673152
    
    629	395641	248858189
    
    630	396900	250047000
    
    631	398161	251239591
    
    632	399424	252435968
    
    633	400689	253636137
    
    634	401956	254840104
    
    635	403225	256047875
    
    636	404496	257259456
    
    637	405769	258474853
    
    638	407044	259694072
    
    639	408321	260917119
    
    640	409600	262144000
    
    641	410881	263374721
    
    642	412164	264609288
    
    643	413449	265847707
    
    644	414736	267089984
    
    645	416025	268336125
    
    646	417316	269586136
    
    647	418609	270840023
    
    648	419904	272097792
    
    649	421201	273359449
    
    650	422500	274625000
    
    651	423801	275894451
    
    652	425104	277167808
    
    653	426409	278445077
    
    654	427716	279726264
    
    655	429025	281011375
    
    656	430336	282300416
    
    657	431649	283593393
    
    658	432964	284890312
    
    659	434281	286191179
    
    660	435600	287496000
    
    661	436921	288804781
    
    662	438244	290117528
    
    663	439569	291434247
    
    664	440896	292754944
    
    665	442225	294079625
    
    666	443556	295408296
    
    667	444889	296740963
    
    668	446224	298077632
    
    669	447561	299418309
    
    670	448900	300763000
    
    671	450241	302111711
    
    672	451584	303464448
    
    673	452929	304821217
    
    674	454276	306182024
    
    675	455625	307546875
    
    676	456976	308915776
    
    677	458329	310288733
    
    678	459684	311665752
    
    679	461041	313046839
    
    680	462400	314432000
    
    681	463761	315821241
    
    682	465124	317214568
    
    683	466489	318611987
    
    684	467856	320013504
    
    685	469225	321419125
    
    686	470596	322828856
    
    687	471969	324242703
    
    688	473344	325660672
    
    689	474721	327082769
    
    690	476100	328509000
    
    691	477481	329939371
    
    692	478864	331373888
    
    693	480249	332812557
    
    694	481636	334255384
    
    695	483025	335702375
    
    696	484416	337153536
    
    697	485809	338608873
    
    698	487204	340068392
    
    699	488601	341532099
    
    700	490000	343000000
    
    701	491401	344472101
    
    702	492804	345948408
    
    703	494209	347428927
    
    704	495616	348913664
    
    705	497025	350402625
    
    706	498436	351895816
    
    707	499849	353393243
    
    708	501264	354894912
    
    709	502681	356400829
    
    710	504100	357911000
    
    711	505521	359425431
    
    712	506944	360944128
    
    713	508369	362467097
    
    714	509796	363994344
    
    715	511225	365525875
    
    716	512656	367061696
    
    717	514089	368601813
    
    718	515524	370146232
    
    719	516961	371694959
    
    720	518400	373248000
    
    721	519841	374805361
    
    722	521284	376367048
    
    723	522729	377933067
    
    724	524176	379503424
    
    725	525625	381078125
    
    726	527076	382657176
    
    727	528529	384240583
    
    728	529984	385828352
    
    729	531441	387420489
    
    730	532900	389017000
    
    731	534361	390617891
    
    732	535824	392223168
    
    733	537289	393832837
    
    734	538756	395446904
    
    735	540225	397065375
    
    736	541696	398688256
    
    737	543169	400315553
    
    738	544644	401947272
    
    739	546121	403583419
    
    740	547600	405224000
    
    741	549081	406869021
    
    742	550564	408518488
    
    743	552049	410172407
    
    744	553536	411830784
    
    745	555025	413493625
    
    746	556516	415160936
    
    747	558009	416832723
    
    748	559504	418508992
    
    749	561001	420189749
    
    750	562500	421875000
    
    751	564001	423564751
    
    752	565504	425259008
    
    753	567009	426957777
    
    754	568516	428661064
    
    755	570025	430368875
    
    756	571536	432081216
    
    757	573049	433798093
    
    758	574564	435519512
    
    759	576081	437245479
    
    760	577600	438976000
    
    761	579121	440711081
    
    762	580644	442450728
    
    763	582169	444194947
    
    764	583696	445943744
    
    765	585225	447697125
    
    766	586756	449455096
    
    767	588289	451217663
    
    768	589824	452984832
    
    769	591361	454756609
    
    770	592900	456533000
    
    771	594441	458314011
    
    772	595984	460099648
    
    773	597529	461889917
    
    774	599076	463684824
    
    775	600625	465484375
    
    776	602176	467288576
    
    777	603729	469097433
    
    778	605284	470910952
    
    779	606841	472729139
    
    780	608400	474552000
    
    781	609961	476379541
    
    782	611524	478211768
    
    783	613089	480048687
    
    784	614656	481890304
    
    785	616225	483736625
    
    786	617796	485587656
    
    787	619369	487443403
    
    788	620944	489303872
    
    789	622521	491169069
    
    790	624100	493039000
    
    791	625681	494913671
    
    792	627264	496793088
    
    793	628849	498677257
    
    794	630436	500566184
    
    795	632025	502459875
    
    796	633616	504358336
    
    797	635209	506261573
    
    798	636804	508169592
    
    799	638401	510082399
    
    800	640000	512000000
    
    801	641601	513922401
    
    802	643204	515849608
    
    803	644809	517781627
    
    804	646416	519718464
    
    805	648025	521660125
    
    806	649636	523606616
    
    807	651249	525557943
    
    808	652864	527514112
    
    809	654481	529475129
    
    810	656100	531441000
    
    811	657721	533411731
    
    812	659344	535387328
    
    813	660969	537367797
    
    814	662596	539353144
    
    815	664225	541343375
    
    816	665856	543338496
    
    817	667489	545338513
    
    818	669124	547343432
    
    819	670761	549353259
    
    820	672400	551368000
    
    821	674041	553387661
    
    822	675684	555412248
    
    823	677329	557441767
    
    824	678976	559476224
    
    825	680625	561515625
    
    826	682276	563559976
    
    827	683929	565609283
    
    828	685584	567663552
    
    829	687241	569722789
    
    830	688900	571787000
    
    831	690561	573856191
    
    832	692224	575930368
    
    833	693889	578009537
    
    834	695556	580093704
    
    835	697225	582182875
    
    836	698896	584277056
    
    837	700569	586376253
    
    838	702244	588480472
    
    839	703921	590589719
    
    840	705600	592704000
    
    841	707281	594823321
    
    842	708964	596947688
    
    843	710649	599077107
    
    844	712336	601211584
    
    845	714025	603351125
    
    846	715716	605495736
    
    847	717409	607645423
    
    848	719104	609800192
    
    849	720801	611960049
    
    850	722500	614125000
    
    851	724201	616295051
    
    852	725904	618470208
    
    853	727609	620650477
    
    854	729316	622835864
    
    855	731025	625026375
    
    856	732736	627222016
    
    857	734449	629422793
    
    858	736164	631628712
    
    859	737881	633839779
    
    860	739600	636056000
    
    861	741321	638277381
    
    862	743044	640503928
    
    863	744769	642735647
    
    864	746496	644972544
    
    865	748225	647214625
    
    866	749956	649461896
    
    867	751689	651714363
    
    868	753424	653972032
    
    869	755161	656234909
    
    870	756900	658503000
    
    871	758641	660776311
    
    872	760384	663054848
    
    873	762129	665338617
    
    874	763876	667627624
    
    875	765625	669921875
    
    876	767376	672221376
    
    877	769129	674526133
    
    878	770884	676836152
    
    879	772641	679151439
    
    880	774400	681472000
    
    881	776161	683797841
    
    882	777924	686128968
    
    883	779689	688465387
    
    884	781456	690807104
    
    885	783225	693154125
    
    886	784996	695506456
    
    887	786769	697864103
    
    888	788544	700227072
    
    889	790321	702595369
    
    890	792100	704969000
    
    891	793881	707347971
    
    892	795664	709732288
    
    893	797449	712121957
    
    894	799236	714516984
    
    895	801025	716917375
    
    896	802816	719323136
    
    897	804609	721734273
    
    898	806404	724150792
    
    899	808201	726572699
    
    900	810000	729000000
    
    901	811801	731432701
    
    902	813604	733870808
    
    903	815409	736314327
    
    904	817216	738763264
    
    905	819025	741217625
    
    906	820836	743677416
    
    907	822649	746142643
    
    908	824464	748613312
    
    909	826281	751089429
    
    910	828100	753571000
    
    911	829921	756058031
    
    912	831744	758550528
    
    913	833569	761048497
    
    914	835396	763551944
    
    915	837225	766060875
    
    916	839056	768575296
    
    917	840889	771095213
    
    918	842724	773620632
    
    919	844561	776151559
    
    920	846400	778688000
    
    921	848241	781229961
    
    922	850084	783777448
    
    923	851929	786330467
    
    924	853776	788889024
    
    925	855625	791453125
    
    926	857476	794022776
    
    927	859329	796597983
    
    928	861184	799178752
    
    929	863041	801765089
    
    930	864900	804357000
    
    931	866761	806954491
    
    932	868624	809557568
    
    933	870489	812166237
    
    934	872356	814780504
    
    935	874225	817400375
    
    936	876096	820025856
    
    937	877969	822656953
    
    938	879844	825293672
    
    939	881721	827936019
    
    940	883600	830584000
    
    941	885481	833237621
    
    942	887364	835896888
    
    943	889249	838561807
    
    944	891136	841232384
    
    945	893025	843908625
    
    946	894916	846590536
    
    947	896809	849278123
    
    948	898704	851971392
    
    949	900601	854670349
    
    950	902500	857375000
    
    951	904401	860085351
    
    952	906304	862801408
    
    953	908209	865523177
    
    954	910116	868250664
    
    955	912025	870983875
    
    956	913936	873722816
    
    957	915849	876467493
    
    958	917764	879217912
    
    959	919681	881974079
    
    960	921600	884736000
    
    961	923521	887503681
    
    962	925444	890277128
    
    963	927369	893056347
    
    964	929296	895841344
    
    965	931225	898632125
    
    966	933156	901428696
    
    967	935089	904231063
    
    968	937024	907039232
    
    969	938961	909853209
    
    970	940900	912673000
    
    971	942841	915498611
    
    972	944784	918330048
    
    973	946729	921167317
    
    974	948676	924010424
    
    975	950625	926859375
    
    976	952576	929714176
    
    977	954529	932574833
    
    978	956484	935441352
    
    979	958441	938313739
    
    980	960400	941192000
    
    981	962361	944076141
    
    982	964324	946966168
    
    983	966289	949862087
    
    984	968256	952763904
    
    985	970225	955671625
    
    986	972196	958585256
    
    987	974169	961504803
    
    988	976144	964430272
    
    989	978121	967361669
    
    990	980100	970299000
    
    991	982081	973242271
    
    992	984064	976191488
    
    993	986049	979146657
    
    994	988036	982107784
    
    995	990025	985074875
    
    996	992016	988047936
    
    997	994009	991026973
    
    998	996004	994011992
    
    999	998001	997002999
    
    1000	1000000	1000000000
    
    1001	1002001	1003003001
    
    1002	1004004	1006012008
    
    1003	1006009	1009027027
    
    1004	1008016	1012048064
    
    1005	1010025	1015075125
    
    1006	1012036	1018108216
    
    1007	1014049	1021147343
    
    1008	1016064	1024192512
    
    1009	1018081	1027243729
    
    1010	1020100	1030301000
    
    1011	1022121	1033364331
    
    1012	1024144	1036433728
    
    1013	1026169	1039509197
    
    1014	1028196	1042590744
    
    1015	1030225	1045678375
    
    1016	1032256	1048772096
    
    1017	1034289	1051871913
    
    1018	1036324	1054977832
    
    1019	1038361	1058089859
    
    1020	1040400	1061208000
    
    1021	1042441	1064332261
    
    1022	1044484	1067462648
    
    1023	1046529	1070599167
    
    1024	1048576	1073741824
    
    1025	1050625	1076890625
    
    1026	1052676	1080045576
    
    1027	1054729	1083206683
    
    1028	1056784	1086373952
    
    1029	1058841	1089547389
    
    1030	1060900	1092727000
    
    1031	1062961	1095912791
    
    1032	1065024	1099104768
    
    1033	1067089	1102302937
    
    1034	1069156	1105507304
    
    1035	1071225	1108717875
    
    1036	1073296	1111934656
    
    1037	1075369	1115157653
    
    1038	1077444	1118386872
    
    1039	1079521	1121622319
    
    1040	1081600	1124864000
    
    1041	1083681	1128111921
    
    1042	1085764	1131366088
    
    1043	1087849	1134626507
    
    1044	1089936	1137893184
    
    1045	1092025	1141166125
    
    1046	1094116	1144445336
    
    1047	1096209	1147730823
    
    1048	1098304	1151022592
    
    1049	1100401	1154320649
    
    1050	1102500	1157625000
    
    1051	1104601	1160935651
    
    1052	1106704	1164252608
    
    1053	1108809	1167575877
    
    1054	1110916	1170905464
    
    1055	1113025	1174241375
    
    1056	1115136	1177583616
    
    1057	1117249	1180932193
    
    1058	1119364	1184287112
    
    1059	1121481	1187648379
    
    1060	1123600	1191016000
    
    1061	1125721	1194389981
    
    1062	1127844	1197770328
    
    1063	1129969	1201157047
    
    1064	1132096	1204550144
    
    1065	1134225	1207949625
    
    1066	1136356	1211355496
    
    1067	1138489	1214767763
    
    1068	1140624	1218186432
    
    1069	1142761	1221611509
    
    1070	1144900	1225043000
    
    1071	1147041	1228480911
    
    1072	1149184	1231925248
    
    1073	1151329	1235376017
    
    1074	1153476	1238833224
    
    1075	1155625	1242296875
    
    1076	1157776	1245766976
    
    1077	1159929	1249243533
    
    1078	1162084	1252726552
    
    1079	1164241	1256216039
    
    1080	1166400	1259712000
    
    1081	1168561	1263214441
    
    1082	1170724	1266723368
    
    1083	1172889	1270238787
    
    1084	1175056	1273760704
    
    1085	1177225	1277289125
    
    1086	1179396	1280824056
    
    1087	1181569	1284365503
    
    1088	1183744	1287913472
    
    1089	1185921	1291467969
    
    1090	1188100	1295029000
    
    1091	1190281	1298596571
    
    1092	1192464	1302170688
    
    1093	1194649	1305751357
    
    1094	1196836	1309338584
    
    1095	1199025	1312932375
    
    1096	1201216	1316532736
    
    1097	1203409	1320139673
    
    1098	1205604	1323753192
    
    1099	1207801	1327373299
    
    1100	1210000	1331000000
    
    1101	1212201	1334633301
    
    1102	1214404	1338273208
    
    1103	1216609	1341919727
    
    1104	1218816	1345572864
    
    1105	1221025	1349232625
    
    1106	1223236	1352899016
    
    1107	1225449	1356572043
    
    1108	1227664	1360251712
    
    1109	1229881	1363938029
    
    1110	1232100	1367631000
    
    1111	1234321	1371330631
    
    1112	1236544	1375036928
    
    1113	1238769	1378749897
    
    1114	1240996	1382469544
    
    1115	1243225	1386195875
    
    1116	1245456	1389928896
    
    1117	1247689	1393668613
    
    1118	1249924	1397415032
    
    1119	1252161	1401168159
    
    1120	1254400	1404928000
    
    1121	1256641	1408694561
    
    1122	1258884	1412467848
    
    1123	1261129	1416247867
    
    1124	1263376	1420034624
    
    1125	1265625	1423828125
    
    1126	1267876	1427628376
    
    1127	1270129	1431435383
    
    1128	1272384	1435249152
    
    1129	1274641	1439069689
    
    1130	1276900	1442897000
    
    1131	1279161	1446731091
    
    1132	1281424	1450571968
    
    1133	1283689	1454419637
    
    1134	1285956	1458274104
    
    1135	1288225	1462135375
    
    1136	1290496	1466003456
    
    1137	1292769	1469878353
    
    1138	1295044	1473760072
    
    1139	1297321	1477648619
    
    1140	1299600	1481544000
    
    1141	1301881	1485446221
    
    1142	1304164	1489355288
    
    1143	1306449	1493271207
    
    1144	1308736	1497193984
    
    1145	1311025	1501123625
    
    1146	1313316	1505060136
    
    1147	1315609	1509003523
    
    1148	1317904	1512953792
    
    1149	1320201	1516910949
    
    1150	1322500	1520875000
    
    1151	1324801	1524845951
    
    1152	1327104	1528823808
    
    1153	1329409	1532808577
    
    1154	1331716	1536800264
    
    1155	1334025	1540798875
    
    1156	1336336	1544804416
    
    1157	1338649	1548816893
    
    1158	1340964	1552836312
    
    1159	1343281	1556862679
    
    1160	1345600	1560896000
    
    1161	1347921	1564936281
    
    1162	1350244	1568983528
    
    1163	1352569	1573037747
    
    1164	1354896	1577098944
    
    1165	1357225	1581167125
    
    1166	1359556	1585242296
    
    1167	1361889	1589324463
    
    1168	1364224	1593413632
    
    1169	1366561	1597509809
    
    1170	1368900	1601613000
    
    1171	1371241	1605723211
    
    1172	1373584	1609840448
    
    1173	1375929	1613964717
    
    1174	1378276	1618096024
    
    1175	1380625	1622234375
    
    1176	1382976	1626379776
    
    1177	1385329	1630532233
    
    1178	1387684	1634691752
    
    1179	1390041	1638858339
    
    1180	1392400	1643032000
    
    1181	1394761	1647212741
    
    1182	1397124	1651400568
    
    1183	1399489	1655595487
    
    1184	1401856	1659797504
    
    1185	1404225	1664006625
    
    1186	1406596	1668222856
    
    1187	1408969	1672446203
    
    1188	1411344	1676676672
    
    1189	1413721	1680914269
    
    1190	1416100	1685159000
    
    1191	1418481	1689410871
    
    1192	1420864	1693669888
    
    1193	1423249	1697936057
    
    1194	1425636	1702209384
    
    1195	1428025	1706489875
    
    1196	1430416	1710777536
    
    1197	1432809	1715072373
    
    1198	1435204	1719374392
    
    1199	1437601	1723683599
    
    1200	1440000	1728000000
    
    1201	1442401	1732323601
    
    1202	1444804	1736654408
    
    1203	1447209	1740992427
    
    1204	1449616	1745337664
    
    1205	1452025	1749690125
    
    1206	1454436	1754049816
    
    1207	1456849	1758416743
    
    1208	1459264	1762790912
    
    1209	1461681	1767172329
    
    1210	1464100	1771561000
    
    1211	1466521	1775956931
    
    1212	1468944	1780360128
    
    1213	1471369	1784770597
    
    1214	1473796	1789188344
    
    1215	1476225	1793613375
    
    1216	1478656	1798045696
    
    1217	1481089	1802485313
    
    1218	1483524	1806932232
    
    1219	1485961	1811386459
    
    1220	1488400	1815848000
    
    1221	1490841	1820316861
    
    1222	1493284	1824793048
    
    1223	1495729	1829276567
    
    1224	1498176	1833767424
    
    1225	1500625	1838265625
    
    1226	1503076	1842771176
    
    1227	1505529	1847284083
    
    1228	1507984	1851804352
    
    1229	1510441	1856331989
    
    1230	1512900	1860867000
    
    1231	1515361	1865409391
    
    1232	1517824	1869959168
    
    1233	1520289	1874516337
    
    1234	1522756	1879080904
    
    1235	1525225	1883652875
    
    1236	1527696	1888232256
    
    1237	1530169	1892819053
    
    1238	1532644	1897413272
    
    1239	1535121	1902014919
    
    1240	1537600	1906624000
    
    1241	1540081	1911240521
    
    1242	1542564	1915864488
    
    1243	1545049	1920495907
    
    1244	1547536	1925134784
    
    1245	1550025	1929781125
    
    1246	1552516	1934434936
    
    1247	1555009	1939096223
    
    1248	1557504	1943764992
    
    1249	1560001	1948441249
    
    1250	1562500	1953125000
    
    1251	1565001	1957816251
    
    1252	1567504	1962515008
    
    1253	1570009	1967221277
    
    1254	1572516	1971935064
    
    1255	1575025	1976656375
    
    1256	1577536	1981385216
    
    1257	1580049	1986121593
    
    1258	1582564	1990865512
    
    1259	1585081	1995616979
    
    1260	1587600	2000376000
    
    1261	1590121	2005142581
    
    1262	1592644	2009916728
    
    1263	1595169	2014698447
    
    1264	1597696	2019487744
    
    1265	1600225	2024284625
    
    1266	1602756	2029089096
    
    1267	1605289	2033901163
    
    1268	1607824	2038720832
    
    1269	1610361	2043548109
    
    1270	1612900	2048383000
    
    1271	1615441	2053225511
    
    1272	1617984	2058075648
    
    1273	1620529	2062933417
    
    1274	1623076	2067798824
    
    1275	1625625	2072671875
    
    1276	1628176	2077552576
    
    1277	1630729	2082440933
    
    1278	1633284	2087336952
    
    1279	1635841	2092240639
    
    1280	1638400	2097152000
    
    1281	1640961	2102071041
    
    1282	1643524	2106997768
    
    1283	1646089	2111932187
    
    1284	1648656	2116874304
    
    1285	1651225	2121824125
    
    1286	1653796	2126781656
    
    1287	1656369	2131746903
    
    1288	1658944	2136719872
    
    1289	1661521	2141700569
    
    1290	1664100	2146689000
    
    1291	1666681	2151685171
    
    1292	1669264	2156689088
    
    1293	1671849	2161700757
    
    1294	1674436	2166720184
    
    1295	1677025	2171747375
    
    1296	1679616	2176782336
    
    1297	1682209	2181825073
    
    1298	1684804	2186875592
    
    1299	1687401	2191933899
    
    1300	1690000	2197000000
    
    1301	1692601	2202073901
    
    1302	1695204	2207155608
    
    1303	1697809	2212245127
    
    1304	1700416	2217342464
    
    1305	1703025	2222447625
    
    1306	1705636	2227560616
    
    1307	1708249	2232681443
    
    1308	1710864	2237810112
    
    1309	1713481	2242946629
    
    1310	1716100	2248091000
    
    1311	1718721	2253243231
    
    1312	1721344	2258403328
    
    1313	1723969	2263571297
    
    1314	1726596	2268747144
    
    1315	1729225	2273930875
    
    1316	1731856	2279122496
    
    1317	1734489	2284322013
    
    1318	1737124	2289529432
    
    1319	1739761	2294744759
    
    1320	1742400	2299968000
    
    1321	1745041	2305199161
    
    1322	1747684	2310438248
    
    1323	1750329	2315685267
    
    1324	1752976	2320940224
    
    1325	1755625	2326203125
    
    1326	1758276	2331473976
    
    1327	1760929	2336752783
    
    1328	1763584	2342039552
    
    1329	1766241	2347334289
    
    1330	1768900	2352637000
    
    1331	1771561	2357947691
    
    1332	1774224	2363266368
    
    1333	1776889	2368593037
    
    1334	1779556	2373927704
    
    1335	1782225	2379270375
    
    1336	1784896	2384621056
    
    1337	1787569	2389979753
    
    1338	1790244	2395346472
    
    1339	1792921	2400721219
    
    1340	1795600	2406104000
    
    1341	1798281	2411494821
    
    1342	1800964	2416893688
    
    1343	1803649	2422300607
    
    1344	1806336	2427715584
    
    1345	1809025	2433138625
    
    1346	1811716	2438569736
    
    1347	1814409	2444008923
    
    1348	1817104	2449456192
    
    1349	1819801	2454911549
    
    1350	1822500	2460375000
    
    1351	1825201	2465846551
    
    1352	1827904	2471326208
    
    1353	1830609	2476813977
    
    1354	1833316	2482309864
    
    1355	1836025	2487813875
    
    1356	1838736	2493326016
    
    1357	1841449	2498846293
    
    1358	1844164	2504374712
    
    1359	1846881	2509911279
    
    1360	1849600	2515456000
    
    1361	1852321	2521008881
    
    1362	1855044	2526569928
    
    1363	1857769	2532139147
    
    1364	1860496	2537716544
    
    1365	1863225	2543302125
    
    1366	1865956	2548895896
    
    1367	1868689	2554497863
    
    1368	1871424	2560108032
    
    1369	1874161	2565726409
    
    1370	1876900	2571353000
    
    1371	1879641	2576987811
    
    1372	1882384	2582630848
    
    1373	1885129	2588282117
    
    1374	1887876	2593941624
    
    1375	1890625	2599609375
    
    1376	1893376	2605285376
    
    1377	1896129	2610969633
    
    1378	1898884	2616662152
    
    1379	1901641	2622362939
    
    1380	1904400	2628072000
    
    1381	1907161	2633789341
    
    1382	1909924	2639514968
    
    1383	1912689	2645248887
    
    1384	1915456	2650991104
    
    1385	1918225	2656741625
    
    1386	1920996	2662500456
    
    1387	1923769	2668267603
    
    1388	1926544	2674043072
    
    1389	1929321	2679826869
    
    1390	1932100	2685619000
    
    1391	1934881	2691419471
    
    1392	1937664	2697228288
    
    1393	1940449	2703045457
    
    1394	1943236	2708870984
    
    1395	1946025	2714704875
    
    1396	1948816	2720547136
    
    1397	1951609	2726397773
    
    1398	1954404	2732256792
    
    1399	1957201	2738124199
    
    1400	1960000	2744000000
    
    1401	1962801	2749884201
    
    1402	1965604	2755776808
    
    1403	1968409	2761677827
    
    1404	1971216	2767587264
    
    1405	1974025	2773505125
    
    1406	1976836	2779431416
    
    1407	1979649	2785366143
    
    1408	1982464	2791309312
    
    1409	1985281	2797260929
    
    1410	1988100	2803221000
    
    1411	1990921	2809189531
    
    1412	1993744	2815166528
    
    1413	1996569	2821151997
    
    1414	1999396	2827145944
    
    1415	2002225	2833148375
    
    1416	2005056	2839159296
    
    1417	2007889	2845178713
    
    1418	2010724	2851206632
    
    1419	2013561	2857243059
    
    1420	2016400	2863288000
    
    1421	2019241	2869341461
    
    1422	2022084	2875403448
    
    1423	2024929	2881473967
    
    1424	2027776	2887553024
    
    1425	2030625	2893640625
    
    1426	2033476	2899736776
    
    1427	2036329	2905841483
    
    1428	2039184	2911954752
    
    1429	2042041	2918076589
    
    1430	2044900	2924207000
    
    1431	2047761	2930345991
    
    1432	2050624	2936493568
    
    1433	2053489	2942649737
    
    1434	2056356	2948814504
    
    1435	2059225	2954987875
    
    1436	2062096	2961169856
    
    1437	2064969	2967360453
    
    1438	2067844	2973559672
    
    1439	2070721	2979767519
    
    1440	2073600	2985984000
    
    1441	2076481	2992209121
    
    1442	2079364	2998442888
    
    1443	2082249	3004685307
    
    1444	2085136	3010936384
    
    1445	2088025	3017196125
    
    1446	2090916	3023464536
    
    1447	2093809	3029741623
    
    1448	2096704	3036027392
    
    1449	2099601	3042321849
    
    1450	2102500	3048625000
    
    1451	2105401	3054936851
    
    1452	2108304	3061257408
    
    1453	2111209	3067586677
    
    1454	2114116	3073924664
    
    1455	2117025	3080271375
    
    1456	2119936	3086626816
    
    1457	2122849	3092990993
    
    1458	2125764	3099363912
    
    1459	2128681	3105745579
    
    1460	2131600	3112136000
    
    1461	2134521	3118535181
    
    1462	2137444	3124943128
    
    1463	2140369	3131359847
    
    1464	2143296	3137785344
    
    1465	2146225	3144219625
    
    1466	2149156	3150662696
    
    1467	2152089	3157114563
    
    1468	2155024	3163575232
    
    1469	2157961	3170044709
    
    1470	2160900	3176523000
    
    1471	2163841	3183010111
    
    1472	2166784	3189506048
    
    1473	2169729	3196010817
    
    1474	2172676	3202524424
    
    1475	2175625	3209046875
    
    1476	2178576	3215578176
    
    1477	2181529	3222118333
    
    1478	2184484	3228667352
    
    1479	2187441	3235225239
    
    1480	2190400	3241792000
    
    1481	2193361	3248367641
    
    1482	2196324	3254952168
    
    1483	2199289	3261545587
    
    1484	2202256	3268147904
    
    1485	2205225	3274759125
    
    1486	2208196	3281379256
    
    1487	2211169	3288008303
    
    1488	2214144	3294646272
    
    1489	2217121	3301293169
    
    1490	2220100	3307949000
    
    1491	2223081	3314613771
    
    1492	2226064	3321287488
    
    1493	2229049	3327970157
    
    1494	2232036	3334661784
    
    1495	2235025	3341362375
    
    1496	2238016	3348071936
    
    1497	2241009	3354790473
    
    1498	2244004	3361517992
    
    1499	2247001	3368254499
    
    1500	2250000	3375000000
    
    1501	2253001	3381754501
    
    1502	2256004	3388518008
    
    1503	2259009	3395290527
    
    1504	2262016	3402072064
    
    1505	2265025	3408862625
    
    1506	2268036	3415662216
    
    1507	2271049	3422470843
    
    1508	2274064	3429288512
    
    1509	2277081	3436115229
    
    1510	2280100	3442951000
    
    1511	2283121	3449795831
    
    1512	2286144	3456649728
    
    1513	2289169	3463512697
    
    1514	2292196	3470384744
    
    1515	2295225	3477265875
    
    1516	2298256	3484156096
    
    1517	2301289	3491055413
    
    1518	2304324	3497963832
    
    1519	2307361	3504881359
    
    1520	2310400	3511808000
    
    1521	2313441	3518743761
    
    1522	2316484	3525688648
    
    1523	2319529	3532642667
    
    1524	2322576	3539605824
    
    1525	2325625	3546578125
    
    1526	2328676	3553559576
    
    1527	2331729	3560550183
    
    1528	2334784	3567549952
    
    1529	2337841	3574558889
    
    1530	2340900	3581577000
    
    1531	2343961	3588604291
    
    1532	2347024	3595640768
    
    1533	2350089	3602686437
    
    1534	2353156	3609741304
    
    1535	2356225	3616805375
    
    1536	2359296	3623878656
    
    1537	2362369	3630961153
    
    1538	2365444	3638052872
    
    1539	2368521	3645153819
    
    1540	2371600	3652264000
    
    1541	2374681	3659383421
    
    1542	2377764	3666512088
    
    1543	2380849	3673650007
    
    1544	2383936	3680797184
    
    1545	2387025	3687953625
    
    1546	2390116	3695119336
    
    1547	2393209	3702294323
    
    1548	2396304	3709478592
    
    1549	2399401	3716672149
    
    1550	2402500	3723875000
    
    1551	2405601	3731087151
    
    1552	2408704	3738308608
    
    1553	2411809	3745539377
    
    1554	2414916	3752779464
    
    1555	2418025	3760028875
    
    1556	2421136	3767287616
    
    1557	2424249	3774555693
    
    1558	2427364	3781833112
    
    1559	2430481	3789119879
    
    1560	2433600	3796416000
    
    1561	2436721	3803721481
    
    1562	2439844	3811036328
    
    1563	2442969	3818360547
    
    1564	2446096	3825694144
    
    1565	2449225	3833037125
    
    1566	2452356	3840389496
    
    1567	2455489	3847751263
    
    1568	2458624	3855122432
    
    1569	2461761	3862503009
    
    1570	2464900	3869893000
    
    1571	2468041	3877292411
    
    1572	2471184	3884701248
    
    1573	2474329	3892119517
    
    1574	2477476	3899547224
    
    1575	2480625	3906984375
    
    1576	2483776	3914430976
    
    1577	2486929	3921887033
    
    1578	2490084	3929352552
    
    1579	2493241	3936827539
    
    1580	2496400	3944312000
    
    1581	2499561	3951805941
    
    1582	2502724	3959309368
    
    1583	2505889	3966822287
    
    1584	2509056	3974344704
    
    1585	2512225	3981876625
    
    1586	2515396	3989418056
    
    1587	2518569	3996969003
    
    1588	2521744	4004529472
    
    1589	2524921	4012099469
    
    1590	2528100	4019679000
    
    1591	2531281	4027268071
    
    1592	2534464	4034866688
    
    1593	2537649	4042474857
    
    1594	2540836	4050092584
    
    1595	2544025	4057719875
    
    1596	2547216	4065356736
    
    1597	2550409	4073003173
    
    1598	2553604	4080659192
    
    1599	2556801	4088324799
    
    1600	2560000	4096000000
    
    1601	2563201	4103684801
    
    1602	2566404	4111379208
    
    1603	2569609	4119083227
    
    1604	2572816	4126796864
    
    1605	2576025	4134520125
    
    1606	2579236	4142253016
    
    1607	2582449	4149995543
    
    1608	2585664	4157747712
    
    1609	2588881	4165509529
    
    1610	2592100	4173281000
    
    1611	2595321	4181062131
    
    1612	2598544	4188852928
    
    1613	2601769	4196653397
    
    1614	2604996	4204463544
    
    1615	2608225	4212283375
    
    1616	2611456	4220112896
    
    1617	2614689	4227952113
    
    1618	2617924	4235801032
    
    1619	2621161	4243659659
    
    1620	2624400	4251528000
    
    1621	2627641	4259406061
    
    1622	2630884	4267293848
    
    1623	2634129	4275191367
    
    1624	2637376	4283098624
    
    1625	2640625	4291015625
    
    1626	2643876	4298942376
    
    1627	2647129	4306878883
    
    1628	2650384	4314825152
    
    1629	2653641	4322781189
    
    1630	2656900	4330747000
    
    1631	2660161	4338722591
    
    1632	2663424	4346707968
    
    1633	2666689	4354703137
    
    1634	2669956	4362708104
    
    1635	2673225	4370722875
    
    1636	2676496	4378747456
    
    1637	2679769	4386781853
    
    1638	2683044	4394826072
    
    1639	2686321	4402880119
    
    1640	2689600	4410944000
    
    1641	2692881	4419017721
    
    1642	2696164	4427101288
    
    1643	2699449	4435194707
    
    1644	2702736	4443297984
    
    1645	2706025	4451411125
    
    1646	2709316	4459534136
    
    1647	2712609	4467667023
    
    1648	2715904	4475809792
    
    1649	2719201	4483962449
    
    1650	2722500	4492125000
    
    1651	2725801	4500297451
    
    1652	2729104	4508479808
    
    1653	2732409	4516672077
    
    1654	2735716	4524874264
    
    1655	2739025	4533086375
    
    1656	2742336	4541308416
    
    1657	2745649	4549540393
    
    1658	2748964	4557782312
    
    1659	2752281	4566034179
    
    1660	2755600	4574296000
    
    1661	2758921	4582567781
    
    1662	2762244	4590849528
    
    1663	2765569	4599141247
    
    1664	2768896	4607442944
    
    1665	2772225	4615754625
    
    1666	2775556	4624076296
    
    1667	2778889	4632407963
    
    1668	2782224	4640749632
    
    1669	2785561	4649101309
    
    1670	2788900	4657463000
    
    1671	2792241	4665834711
    
    1672	2795584	4674216448
    
    1673	2798929	4682608217
    
    1674	2802276	4691010024
    
    1675	2805625	4699421875
    
    1676	2808976	4707843776
    
    1677	2812329	4716275733
    
    1678	2815684	4724717752
    
    1679	2819041	4733169839
    
    1680	2822400	4741632000
    
    1681	2825761	4750104241
    
    1682	2829124	4758586568
    
    1683	2832489	4767078987
    
    1684	2835856	4775581504
    
    1685	2839225	4784094125
    
    1686	2842596	4792616856
    
    1687	2845969	4801149703
    
    1688	2849344	4809692672
    
    1689	2852721	4818245769
    
    1690	2856100	4826809000
    
    1691	2859481	4835382371
    
    1692	2862864	4843965888
    
    1693	2866249	4852559557
    
    1694	2869636	4861163384
    
    1695	2873025	4869777375
    
    1696	2876416	4878401536
    
    1697	2879809	4887035873
    
    1698	2883204	4895680392
    
    1699	2886601	4904335099
    
    1700	2890000	4913000000
    
    1701	2893401	4921675101
    
    1702	2896804	4930360408
    
    1703	2900209	4939055927
    
    1704	2903616	4947761664
    
    1705	2907025	4956477625
    
    1706	2910436	4965203816
    
    1707	2913849	4973940243
    
    1708	2917264	4982686912
    
    1709	2920681	4991443829
    
    1710	2924100	5000211000
    
    1711	2927521	5008988431
    
    1712	2930944	5017776128
    
    1713	2934369	5026574097
    
    1714	2937796	5035382344
    
    1715	2941225	5044200875
    
    1716	2944656	5053029696
    
    1717	2948089	5061868813
    
    1718	2951524	5070718232
    
    1719	2954961	5079577959
    
    1720	2958400	5088448000
    
    1721	2961841	5097328361
    
    1722	2965284	5106219048
    
    1723	2968729	5115120067
    
    1724	2972176	5124031424
    
    1725	2975625	5132953125
    
    1726	2979076	5141885176
    
    1727	2982529	5150827583
    
    1728	2985984	5159780352
    
    1729	2989441	5168743489
    
    1730	2992900	5177717000
    
    1731	2996361	5186700891
    
    1732	2999824	5195695168
    
    1733	3003289	5204699837
    
    1734	3006756	5213714904
    
    1735	3010225	5222740375
    
    1736	3013696	5231776256
    
    1737	3017169	5240822553
    
    1738	3020644	5249879272
    
    1739	3024121	5258946419
    
    1740	3027600	5268024000
    
    1741	3031081	5277112021
    
    1742	3034564	5286210488
    
    1743	3038049	5295319407
    
    1744	3041536	5304438784
    
    1745	3045025	5313568625
    
    1746	3048516	5322708936
    
    1747	3052009	5331859723
    
    1748	3055504	5341020992
    
    1749	3059001	5350192749
    
    1750	3062500	5359375000
    
    1751	3066001	5368567751
    
    1752	3069504	5377771008
    
    1753	3073009	5386984777
    
    1754	3076516	5396209064
    
    1755	3080025	5405443875
    
    1756	3083536	5414689216
    
    1757	3087049	5423945093
    
    1758	3090564	5433211512
    
    1759	3094081	5442488479
    
    1760	3097600	5451776000
    
    1761	3101121	5461074081
    
    1762	3104644	5470382728
    
    1763	3108169	5479701947
    
    1764	3111696	5489031744
    
    1765	3115225	5498372125
    
    1766	3118756	5507723096
    
    1767	3122289	5517084663
    
    1768	3125824	5526456832
    
    1769	3129361	5535839609
    
    1770	3132900	5545233000
    
    1771	3136441	5554637011
    
    1772	3139984	5564051648
    
    1773	3143529	5573476917
    
    1774	3147076	5582912824
    
    1775	3150625	5592359375
    
    1776	3154176	5601816576
    
    1777	3157729	5611284433
    
    1778	3161284	5620762952
    
    1779	3164841	5630252139
    
    1780	3168400	5639752000
    
    1781	3171961	5649262541
    
    1782	3175524	5658783768
    
    1783	3179089	5668315687
    
    1784	3182656	5677858304
    
    1785	3186225	5687411625
    
    1786	3189796	5696975656
    
    1787	3193369	5706550403
    
    1788	3196944	5716135872
    
    1789	3200521	5725732069
    
    1790	3204100	5735339000
    
    1791	3207681	5744956671
    
    1792	3211264	5754585088
    
    1793	3214849	5764224257
    
    1794	3218436	5773874184
    
    1795	3222025	5783534875
    
    1796	3225616	5793206336
    
    1797	3229209	5802888573
    
    1798	3232804	5812581592
    
    1799	3236401	5822285399
    
    1800	3240000	5832000000
    
    1801	3243601	5841725401
    
    1802	3247204	5851461608
    
    1803	3250809	5861208627
    
    1804	3254416	5870966464
    
    1805	3258025	5880735125
    
    1806	3261636	5890514616
    
    1807	3265249	5900304943
    
    1808	3268864	5910106112
    
    1809	3272481	5919918129
    
    1810	3276100	5929741000
    
    1811	3279721	5939574731
    
    1812	3283344	5949419328
    
    1813	3286969	5959274797
    
    1814	3290596	5969141144
    
    1815	3294225	5979018375
    
    1816	3297856	5988906496
    
    1817	3301489	5998805513
    
    1818	3305124	6008715432
    
    1819	3308761	6018636259
    
    1820	3312400	6028568000
    
    1821	3316041	6038510661
    
    1822	3319684	6048464248
    
    1823	3323329	6058428767
    
    1824	3326976	6068404224
    
    1825	3330625	6078390625
    
    1826	3334276	6088387976
    
    1827	3337929	6098396283
    
    1828	3341584	6108415552
    
    1829	3345241	6118445789
    
    1830	3348900	6128487000
    
    1831	3352561	6138539191
    
    1832	3356224	6148602368
    
    1833	3359889	6158676537
    
    1834	3363556	6168761704
    
    1835	3367225	6178857875
    
    1836	3370896	6188965056
    
    1837	3374569	6199083253
    
    1838	3378244	6209212472
    
    1839	3381921	6219352719
    
    1840	3385600	6229504000
    
    1841	3389281	6239666321
    
    1842	3392964	6249839688
    
    1843	3396649	6260024107
    
    1844	3400336	6270219584
    
    1845	3404025	6280426125
    
    1846	3407716	6290643736
    
    1847	3411409	6300872423
    
    1848	3415104	6311112192
    
    1849	3418801	6321363049
    
    1850	3422500	6331625000
    
    1851	3426201	6341898051
    
    1852	3429904	6352182208
    
    1853	3433609	6362477477
    
    1854	3437316	6372783864
    
    1855	3441025	6383101375
    
    1856	3444736	6393430016
    
    1857	3448449	6403769793
    
    1858	3452164	6414120712
    
    1859	3455881	6424482779
    
    1860	3459600	6434856000
    
    1861	3463321	6445240381
    
    1862	3467044	6455635928
    
    1863	3470769	6466042647
    
    1864	3474496	6476460544
    
    1865	3478225	6486889625
    
    1866	3481956	6497329896
    
    1867	3485689	6507781363
    
    1868	3489424	6518244032
    
    1869	3493161	6528717909
    
    1870	3496900	6539203000
    
    1871	3500641	6549699311
    
    1872	3504384	6560206848
    
    1873	3508129	6570725617
    
    1874	3511876	6581255624
    
    1875	3515625	6591796875
    
    1876	3519376	6602349376
    
    1877	3523129	6612913133
    
    1878	3526884	6623488152
    
    1879	3530641	6634074439
    
    1880	3534400	6644672000
    
    1881	3538161	6655280841
    
    1882	3541924	6665900968
    
    1883	3545689	6676532387
    
    1884	3549456	6687175104
    
    1885	3553225	6697829125
    
    1886	3556996	6708494456
    
    1887	3560769	6719171103
    
    1888	3564544	6729859072
    
    1889	3568321	6740558369
    
    1890	3572100	6751269000
    
    1891	3575881	6761990971
    
    1892	3579664	6772724288
    
    1893	3583449	6783468957
    
    1894	3587236	6794224984
    
    1895	3591025	6804992375
    
    1896	3594816	6815771136
    
    1897	3598609	6826561273
    
    1898	3602404	6837362792
    
    1899	3606201	6848175699
    
    1900	3610000	6859000000
    
    1901	3613801	6869835701
    
    1902	3617604	6880682808
    
    1903	3621409	6891541327
    
    1904	3625216	6902411264
    
    1905	3629025	6913292625
    
    1906	3632836	6924185416
    
    1907	3636649	6935089643
    
    1908	3640464	6946005312
    
    1909	3644281	6956932429
    
    1910	3648100	6967871000
    
    1911	3651921	6978821031
    
    1912	3655744	6989782528
    
    1913	3659569	7000755497
    
    1914	3663396	7011739944
    
    1915	3667225	7022735875
    
    1916	3671056	7033743296
    
    1917	3674889	7044762213
    
    1918	3678724	7055792632
    
    1919	3682561	7066834559
    
    1920	3686400	7077888000
    
    1921	3690241	7088952961
    
    1922	3694084	7100029448
    
    1923	3697929	7111117467
    
    1924	3701776	7122217024
    
    1925	3705625	7133328125
    
    1926	3709476	7144450776
    
    1927	3713329	7155584983
    
    1928	3717184	7166730752
    
    1929	3721041	7177888089
    
    1930	3724900	7189057000
    
    1931	3728761	7200237491
    
    1932	3732624	7211429568
    
    1933	3736489	7222633237
    
    1934	3740356	7233848504
    
    1935	3744225	7245075375
    
    1936	3748096	7256313856
    
    1937	3751969	7267563953
    
    1938	3755844	7278825672
    
    1939	3759721	7290099019
    
    1940	3763600	7301384000
    
    1941	3767481	7312680621
    
    1942	3771364	7323988888
    
    1943	3775249	7335308807
    
    1944	3779136	7346640384
    
    1945	3783025	7357983625
    
    1946	3786916	7369338536
    
    1947	3790809	7380705123
    
    1948	3794704	7392083392
    
    1949	3798601	7403473349
    
    1950	3802500	7414875000
    
    1951	3806401	7426288351
    
    1952	3810304	7437713408
    
    1953	3814209	7449150177
    
    1954	3818116	7460598664
    
    1955	3822025	7472058875
    
    1956	3825936	7483530816
    
    1957	3829849	7495014493
    
    1958	3833764	7506509912
    
    1959	3837681	7518017079
    
    1960	3841600	7529536000
    
    1961	3845521	7541066681
    
    1962	3849444	7552609128
    
    1963	3853369	7564163347
    
    1964	3857296	7575729344
    
    1965	3861225	7587307125
    
    1966	3865156	7598896696
    
    1967	3869089	7610498063
    
    1968	3873024	7622111232
    
    1969	3876961	7633736209
    
    1970	3880900	7645373000
    
    1971	3884841	7657021611
    
    1972	3888784	7668682048
    
    1973	3892729	7680354317
    
    1974	3896676	7692038424
    
    1975	3900625	7703734375
    
    1976	3904576	7715442176
    
    1977	3908529	7727161833
    
    1978	3912484	7738893352
    
    1979	3916441	7750636739
    
    1980	3920400	7762392000
    
    1981	3924361	7774159141
    
    1982	3928324	7785938168
    
    1983	3932289	7797729087
    
    1984	3936256	7809531904
    
    1985	3940225	7821346625
    
    1986	3944196	7833173256
    
    1987	3948169	7845011803
    
    1988	3952144	7856862272
    
    1989	3956121	7868724669
    
    1990	3960100	7880599000
    
    1991	3964081	7892485271
    
    1992	3968064	7904383488
    
    1993	3972049	7916293657
    
    1994	3976036	7928215784
    
    1995	3980025	7940149875
    
    1996	3984016	7952095936
    
    1997	3988009	7964053973
    
    1998	3992004	7976023992
    
    1999	3996001	7988005999
    
    2000	4000000	8000000000
    
    2001	4004001	8012006001
    
    2002	4008004	8024024008
    
    2003	4012009	8036054027
    
    2004	4016016	8048096064
    
    2005	4020025	8060150125
    
    2006	4024036	8072216216
    
    2007	4028049	8084294343
    
    2008	4032064	8096384512
    
    2009	4036081	8108486729
    
    2010	4040100	8120601000
    
    2011	4044121	8132727331
    
    2012	4048144	8144865728
    
    2013	4052169	8157016197
    
    2014	4056196	8169178744
    
    2015	4060225	8181353375
    
    2016	4064256	8193540096
    
    2017	4068289	8205738913
    
    2018	4072324	8217949832
    
    2019	4076361	8230172859
    
    2020	4080400	8242408000
    
    2021	4084441	8254655261
    
    2022	4088484	8266914648
    
    2023	4092529	8279186167
    
    2024	4096576	8291469824
    
    2025	4100625	8303765625
    
    2026	4104676	8316073576
    
    2027	4108729	8328393683
    
    2028	4112784	8340725952
    
    2029	4116841	8353070389
    
    2030	4120900	8365427000
    
    2031	4124961	8377795791
    
    2032	4129024	8390176768
    
    2033	4133089	8402569937
    
    2034	4137156	8414975304
    
    2035	4141225	8427392875
    
    2036	4145296	8439822656
    
    2037	4149369	8452264653
    
    2038	4153444	8464718872
    
    2039	4157521	8477185319
    
    2040	4161600	8489664000
    
    2041	4165681	8502154921
    
    2042	4169764	8514658088
    
    2043	4173849	8527173507
    
    2044	4177936	8539701184
    
    2045	4182025	8552241125
    
    2046	4186116	8564793336
    
    2047	4190209	8577357823
    
    2048	4194304	8589934592
    
    2049	4198401	8602523649
    
    2050	4202500	8615125000
    
    2051	4206601	8627738651
    
    2052	4210704	8640364608
    
    2053	4214809	8653002877
    
    2054	4218916	8665653464
    
    2055	4223025	8678316375
    
    2056	4227136	8690991616
    
    2057	4231249	8703679193
    
    2058	4235364	8716379112
    
    2059	4239481	8729091379
    
    2060	4243600	8741816000
    
    2061	4247721	8754552981
    
    2062	4251844	8767302328
    
    2063	4255969	8780064047
    
    2064	4260096	8792838144
    
    2065	4264225	8805624625
    
    2066	4268356	8818423496
    
    2067	4272489	8831234763
    
    2068	4276624	8844058432
    
    2069	4280761	8856894509
    
    2070	4284900	8869743000
    
    2071	4289041	8882603911
    
    2072	4293184	8895477248
    
    2073	4297329	8908363017
    
    2074	4301476	8921261224
    
    2075	4305625	8934171875
    
    2076	4309776	8947094976
    
    2077	4313929	8960030533
    
    2078	4318084	8972978552
    
    2079	4322241	8985939039
    
    2080	4326400	8998912000
    
    2081	4330561	9011897441
    
    2082	4334724	9024895368
    
    2083	4338889	9037905787
    
    2084	4343056	9050928704
    
    2085	4347225	9063964125
    
    2086	4351396	9077012056
    
    2087	4355569	9090072503
    
    2088	4359744	9103145472
    
    2089	4363921	9116230969
    
    2090	4368100	9129329000
    
    2091	4372281	9142439571
    
    2092	4376464	9155562688
    
    2093	4380649	9168698357
    
    2094	4384836	9181846584
    
    2095	4389025	9195007375
    
    2096	4393216	9208180736
    
    2097	4397409	9221366673
    
    2098	4401604	9234565192
    
    2099	4405801	9247776299
    
    2100	4410000	9261000000
    
    2101	4414201	9274236301
    
    2102	4418404	9287485208
    
    2103	4422609	9300746727
    
    2104	4426816	9314020864
    
    2105	4431025	9327307625
    
    2106	4435236	9340607016
    
    2107	4439449	9353919043
    
    2108	4443664	9367243712
    
    2109	4447881	9380581029
    
    2110	4452100	9393931000
    
    2111	4456321	9407293631
    
    2112	4460544	9420668928
    
    2113	4464769	9434056897
    
    2114	4468996	9447457544
    
    2115	4473225	9460870875
    
    2116	4477456	9474296896
    
    2117	4481689	9487735613
    
    2118	4485924	9501187032
    
    2119	4490161	9514651159
    
    2120	4494400	9528128000
    
    2121	4498641	9541617561
    
    2122	4502884	9555119848
    
    2123	4507129	9568634867
    
    2124	4511376	9582162624
    
    2125	4515625	9595703125
    
    2126	4519876	9609256376
    
    2127	4524129	9622822383
    
    2128	4528384	9636401152
    
    2129	4532641	9649992689
    
    2130	4536900	9663597000
    
    2131	4541161	9677214091
    
    2132	4545424	9690843968
    
    2133	4549689	9704486637
    
    2134	4553956	9718142104
    
    2135	4558225	9731810375
    
    2136	4562496	9745491456
    
    2137	4566769	9759185353
    
    2138	4571044	9772892072
    
    2139	4575321	9786611619
    
    2140	4579600	9800344000
    
    2141	4583881	9814089221
    
    2142	4588164	9827847288
    
    2143	4592449	9841618207
    
    2144	4596736	9855401984
    
    2145	4601025	9869198625
    
    2146	4605316	9883008136
    
    2147	4609609	9896830523
    
    2148	4613904	9910665792
    
    2149	4618201	9924513949
    
    2150	4622500	9938375000
    
    2151	4626801	9952248951
    
    2152	4631104	9966135808
    
    2153	4635409	9980035577
    
    2154	4639716	9993948264
    
    2155	4644025	10007873875
    
    2156	4648336	10021812416
    
    2157	4652649	10035763893
    
    2158	4656964	10049728312
    
    2159	4661281	10063705679
    
    2160	4665600	10077696000
    
    2161	4669921	10091699281
    
    2162	4674244	10105715528
    
    2163	4678569	10119744747
    
    2164	4682896	10133786944
    
    2165	4687225	10147842125
    
    2166	4691556	10161910296
    
    2167	4695889	10175991463
    
    2168	4700224	10190085632
    
    2169	4704561	10204192809
    
    2170	4708900	10218313000
    
    2171	4713241	10232446211
    
    2172	4717584	10246592448
    
    2173	4721929	10260751717
    
    2174	4726276	10274924024
    
    2175	4730625	10289109375
    
    2176	4734976	10303307776
    
    2177	4739329	10317519233
    
    2178	4743684	10331743752
    
    2179	4748041	10345981339
    
    2180	4752400	10360232000
    
    2181	4756761	10374495741
    
    2182	4761124	10388772568
    
    2183	4765489	10403062487
    
    2184	4769856	10417365504
    
    2185	4774225	10431681625
    
    2186	4778596	10446010856
    
    2187	4782969	10460353203
    
    2188	4787344	10474708672
    
    2189	4791721	10489077269
    
    2190	4796100	10503459000
    
    2191	4800481	10517853871
    
    2192	4804864	10532261888
    
    2193	4809249	10546683057
    
    2194	4813636	10561117384
    
    2195	4818025	10575564875
    
    2196	4822416	10590025536
    
    2197	4826809	10604499373
    
    2198	4831204	10618986392
    
    2199	4835601	10633486599
    
    2200	4840000	10648000000
    
    2201	4844401	10662526601
    
    2202	4848804	10677066408
    
    2203	4853209	10691619427
    
    2204	4857616	10706185664
    
    2205	4862025	10720765125
    
    2206	4866436	10735357816
    
    2207	4870849	10749963743
    
    2208	4875264	10764582912
    
    2209	4879681	10779215329
    
    2210	4884100	10793861000
    
    2211	4888521	10808519931
    
    2212	4892944	10823192128
    
    2213	4897369	10837877597
    
    2214	4901796	10852576344
    
    2215	4906225	10867288375
    
    2216	4910656	10882013696
    
    2217	4915089	10896752313
    
    2218	4919524	10911504232
    
    2219	4923961	10926269459
    
    2220	4928400	10941048000
    
    2221	4932841	10955839861
    
    2222	4937284	10970645048
    
    2223	4941729	10985463567
    
    2224	4946176	11000295424
    
    2225	4950625	11015140625
    
    2226	4955076	11029999176
    
    2227	4959529	11044871083
    
    2228	4963984	11059756352
    
    2229	4968441	11074654989
    
    2230	4972900	11089567000
    
    2231	4977361	11104492391
    
    2232	4981824	11119431168
    
    2233	4986289	11134383337
    
    2234	4990756	11149348904
    
    2235	4995225	11164327875
    
    2236	4999696	11179320256
    
    2237	5004169	11194326053
    
    2238	5008644	11209345272
    
    2239	5013121	11224377919
    
    2240	5017600	11239424000
    
    2241	5022081	11254483521
    
    2242	5026564	11269556488
    
    2243	5031049	11284642907
    
    2244	5035536	11299742784
    
    2245	5040025	11314856125
    
    2246	5044516	11329982936
    
    2247	5049009	11345123223
    
    2248	5053504	11360276992
    
    2249	5058001	11375444249
    
    2250	5062500	11390625000
    
    2251	5067001	11405819251
    
    2252	5071504	11421027008
    
    2253	5076009	11436248277
    
    2254	5080516	11451483064
    
    2255	5085025	11466731375
    
    2256	5089536	11481993216
    
    2257	5094049	11497268593
    
    2258	5098564	11512557512
    
    2259	5103081	11527859979
    
    2260	5107600	11543176000
    
    2261	5112121	11558505581
    
    2262	5116644	11573848728
    
    2263	5121169	11589205447
    
    2264	5125696	11604575744
    
    2265	5130225	11619959625
    
    2266	5134756	11635357096
    
    2267	5139289	11650768163
    
    2268	5143824	11666192832
    
    2269	5148361	11681631109
    
    2270	5152900	11697083000
    
    2271	5157441	11712548511
    
    2272	5161984	11728027648
    
    2273	5166529	11743520417
    
    2274	5171076	11759026824
    
    2275	5175625	11774546875
    
    2276	5180176	11790080576
    
    2277	5184729	11805627933
    
    2278	5189284	11821188952
    
    2279	5193841	11836763639
    
    2280	5198400	11852352000
    
    2281	5202961	11867954041
    
    2282	5207524	11883569768
    
    2283	5212089	11899199187
    
    2284	5216656	11914842304
    
    2285	5221225	11930499125
    
    2286	5225796	11946169656
    
    2287	5230369	11961853903
    
    2288	5234944	11977551872
    
    2289	5239521	11993263569
    
    2290	5244100	12008989000
    
    2291	5248681	12024728171
    
    2292	5253264	12040481088
    
    2293	5257849	12056247757
    
    2294	5262436	12072028184
    
    2295	5267025	12087822375
    
    2296	5271616	12103630336
    
    2297	5276209	12119452073
    
    2298	5280804	12135287592
    
    2299	5285401	12151136899
    
    2300	5290000	12167000000
    
    2301	5294601	12182876901
    
    2302	5299204	12198767608
    
    2303	5303809	12214672127
    
    2304	5308416	12230590464
    
    2305	5313025	12246522625
    
    2306	5317636	12262468616
    
    2307	5322249	12278428443
    
    2308	5326864	12294402112
    
    2309	5331481	12310389629
    
    2310	5336100	12326391000
    
    2311	5340721	12342406231
    
    2312	5345344	12358435328
    
    2313	5349969	12374478297
    
    2314	5354596	12390535144
    
    2315	5359225	12406605875
    
    2316	5363856	12422690496
    
    2317	5368489	12438789013
    
    2318	5373124	12454901432
    
    2319	5377761	12471027759
    
    2320	5382400	12487168000
    
    2321	5387041	12503322161
    
    2322	5391684	12519490248
    
    2323	5396329	12535672267
    
    2324	5400976	12551868224
    
    2325	5405625	12568078125
    
    2326	5410276	12584301976
    
    2327	5414929	12600539783
    
    2328	5419584	12616791552
    
    2329	5424241	12633057289
    
    2330	5428900	12649337000
    
    2331	5433561	12665630691
    
    2332	5438224	12681938368
    
    2333	5442889	12698260037
    
    2334	5447556	12714595704
    
    2335	5452225	12730945375
    
    2336	5456896	12747309056
    
    2337	5461569	12763686753
    
    2338	5466244	12780078472
    
    2339	5470921	12796484219
    
    2340	5475600	12812904000
    
    2341	5480281	12829337821
    
    2342	5484964	12845785688
    
    2343	5489649	12862247607
    
    2344	5494336	12878723584
    
    2345	5499025	12895213625
    
    2346	5503716	12911717736
    
    2347	5508409	12928235923
    
    2348	5513104	12944768192
    
    2349	5517801	12961314549
    
    2350	5522500	12977875000
    
    2351	5527201	12994449551
    
    2352	5531904	13011038208
    
    2353	5536609	13027640977
    
    2354	5541316	13044257864
    
    2355	5546025	13060888875
    
    2356	5550736	13077534016
    
    2357	5555449	13094193293
    
    2358	5560164	13110866712
    
    2359	5564881	13127554279
    
    2360	5569600	13144256000
    
    2361	5574321	13160971881
    
    2362	5579044	13177701928
    
    2363	5583769	13194446147
    
    2364	5588496	13211204544
    
    2365	5593225	13227977125
    
    2366	5597956	13244763896
    
    2367	5602689	13261564863
    
    2368	5607424	13278380032
    
    2369	5612161	13295209409
    
    2370	5616900	13312053000
    
    2371	5621641	13328910811
    
    2372	5626384	13345782848
    
    2373	5631129	13362669117
    
    2374	5635876	13379569624
    
    2375	5640625	13396484375
    
    2376	5645376	13413413376
    
    2377	5650129	13430356633
    
    2378	5654884	13447314152
    
    2379	5659641	13464285939
    
    2380	5664400	13481272000
    
    2381	5669161	13498272341
    
    2382	5673924	13515286968
    
    2383	5678689	13532315887
    
    2384	5683456	13549359104
    
    2385	5688225	13566416625
    
    2386	5692996	13583488456
    
    2387	5697769	13600574603
    
    2388	5702544	13617675072
    
    2389	5707321	13634789869
    
    2390	5712100	13651919000
    
    2391	5716881	13669062471
    
    2392	5721664	13686220288
    
    2393	5726449	13703392457
    
    2394	5731236	13720578984
    
    2395	5736025	13737779875
    
    2396	5740816	13754995136
    
    2397	5745609	13772224773
    
    2398	5750404	13789468792
    
    2399	5755201	13806727199
    
    2400	5760000	13824000000
    
    2401	5764801	13841287201
    
    2402	5769604	13858588808
    
    2403	5774409	13875904827
    
    2404	5779216	13893235264
    
    2405	5784025	13910580125
    
    2406	5788836	13927939416
    
    2407	5793649	13945313143
    
    2408	5798464	13962701312
    
    2409	5803281	13980103929
    
    2410	5808100	13997521000
    
    2411	5812921	14014952531
    
    2412	5817744	14032398528
    
    2413	5822569	14049858997
    
    2414	5827396	14067333944
    
    2415	5832225	14084823375
    
    2416	5837056	14102327296
    
    2417	5841889	14119845713
    
    2418	5846724	14137378632
    
    2419	5851561	14154926059
    
    2420	5856400	14172488000
    
    2421	5861241	14190064461
    
    2422	5866084	14207655448
    
    2423	5870929	14225260967
    
    2424	5875776	14242881024
    
    2425	5880625	14260515625
    
    2426	5885476	14278164776
    
    2427	5890329	14295828483
    
    2428	5895184	14313506752
    
    2429	5900041	14331199589
    
    2430	5904900	14348907000
    
    2431	5909761	14366628991
    
    2432	5914624	14384365568
    
    2433	5919489	14402116737
    
    2434	5924356	14419882504
    
    2435	5929225	14437662875
    
    2436	5934096	14455457856
    
    2437	5938969	14473267453
    
    2438	5943844	14491091672
    
    2439	5948721	14508930519
    
    2440	5953600	14526784000
    
    2441	5958481	14544652121
    
    2442	5963364	14562534888
    
    2443	5968249	14580432307
    
    2444	5973136	14598344384
    
    2445	5978025	14616271125
    
    2446	5982916	14634212536
    
    2447	5987809	14652168623
    
    2448	5992704	14670139392
    
    2449	5997601	14688124849
    
    2450	6002500	14706125000
    
    2451	6007401	14724139851
    
    2452	6012304	14742169408
    
    2453	6017209	14760213677
    
    2454	6022116	14778272664
    
    2455	6027025	14796346375
    
    2456	6031936	14814434816
    
    2457	6036849	14832537993
    
    2458	6041764	14850655912
    
    2459	6046681	14868788579
    
    2460	6051600	14886936000
    
    2461	6056521	14905098181
    
    2462	6061444	14923275128
    
    2463	6066369	14941466847
    
    2464	6071296	14959673344
    
    2465	6076225	14977894625
    
    2466	6081156	14996130696
    
    2467	6086089	15014381563
    
    2468	6091024	15032647232
    
    2469	6095961	15050927709
    
    2470	6100900	15069223000
    
    2471	6105841	15087533111
    
    2472	6110784	15105858048
    
    2473	6115729	15124197817
    
    2474	6120676	15142552424
    
    2475	6125625	15160921875
    
    2476	6130576	15179306176
    
    2477	6135529	15197705333
    
    2478	6140484	15216119352
    
    2479	6145441	15234548239
    
    2480	6150400	15252992000
    
    2481	6155361	15271450641
    
    2482	6160324	15289924168
    
    2483	6165289	15308412587
    
    2484	6170256	15326915904
    
    2485	6175225	15345434125
    
    2486	6180196	15363967256
    
    2487	6185169	15382515303
    
    2488	6190144	15401078272
    
    2489	6195121	15419656169
    
    2490	6200100	15438249000
    
    2491	6205081	15456856771
    
    2492	6210064	15475479488
    
    2493	6215049	15494117157
    
    2494	6220036	15512769784
    
    2495	6225025	15531437375
    
    2496	6230016	15550119936
    
    2497	6235009	15568817473
    
    2498	6240004	15587529992
    
    2499	6245001	15606257499
    
    2500	6250000	15625000000
    
    2501	6255001	15643757501
    
    2502	6260004	15662530008
    
    2503	6265009	15681317527
    
    2504	6270016	15700120064
    
    2505	6275025	15718937625
    
    2506	6280036	15737770216
    
    2507	6285049	15756617843
    
    2508	6290064	15775480512
    
    2509	6295081	15794358229
    
    2510	6300100	15813251000
    
    2511	6305121	15832158831
    
    2512	6310144	15851081728
    
    2513	6315169	15870019697
    
    2514	6320196	15888972744
    
    2515	6325225	15907940875
    
    2516	6330256	15926924096
    
    2517	6335289	15945922413
    
    2518	6340324	15964935832
    
    2519	6345361	15983964359
    
    2520	6350400	16003008000
    
    2521	6355441	16022066761
    
    2522	6360484	16041140648
    
    2523	6365529	16060229667
    
    2524	6370576	16079333824
    
    2525	6375625	16098453125
    
    2526	6380676	16117587576
    
    2527	6385729	16136737183
    
    2528	6390784	16155901952
    
    2529	6395841	16175081889
    
    2530	6400900	16194277000
    
    2531	6405961	16213487291
    
    2532	6411024	16232712768
    
    2533	6416089	16251953437
    
    2534	6421156	16271209304
    
    2535	6426225	16290480375
    
    2536	6431296	16309766656
    
    2537	6436369	16329068153
    
    2538	6441444	16348384872
    
    2539	6446521	16367716819
    
    2540	6451600	16387064000
    
    2541	6456681	16406426421
    
    2542	6461764	16425804088
    
    2543	6466849	16445197007
    
    2544	6471936	16464605184
    
    2545	6477025	16484028625
    
    2546	6482116	16503467336
    
    2547	6487209	16522921323
    
    2548	6492304	16542390592
    
    2549	6497401	16561875149
    
    2550	6502500	16581375000
    
    2551	6507601	16600890151
    
    2552	6512704	16620420608
    
    2553	6517809	16639966377
    
    2554	6522916	16659527464
    
    2555	6528025	16679103875
    
    2556	6533136	16698695616
    
    2557	6538249	16718302693
    
    2558	6543364	16737925112
    
    2559	6548481	16757562879
    
    2560	6553600	16777216000
    
    2561	6558721	16796884481
    
    2562	6563844	16816568328
    
    2563	6568969	16836267547
    
    2564	6574096	16855982144
    
    2565	6579225	16875712125
    
    2566	6584356	16895457496
    
    2567	6589489	16915218263
    
    2568	6594624	16934994432
    
    2569	6599761	16954786009
    
    2570	6604900	16974593000
    
    2571	6610041	16994415411
    
    2572	6615184	17014253248
    
    2573	6620329	17034106517
    
    2574	6625476	17053975224
    
    2575	6630625	17073859375
    
    2576	6635776	17093758976
    
    2577	6640929	17113674033
    
    2578	6646084	17133604552
    
    2579	6651241	17153550539
    
    2580	6656400	17173512000
    
    2581	6661561	17193488941
    
    2582	6666724	17213481368
    
    2583	6671889	17233489287
    
    2584	6677056	17253512704
    
    2585	6682225	17273551625
    
    2586	6687396	17293606056
    
    2587	6692569	17313676003
    
    2588	6697744	17333761472
    
    2589	6702921	17353862469
    
    2590	6708100	17373979000
    
    2591	6713281	17394111071
    
    2592	6718464	17414258688
    
    2593	6723649	17434421857
    
    2594	6728836	17454600584
    
    2595	6734025	17474794875
    
    2596	6739216	17495004736
    
    2597	6744409	17515230173
    
    2598	6749604	17535471192
    
    2599	6754801	17555727799
    
    2600	6760000	17576000000
    
    2601	6765201	17596287801
    
    2602	6770404	17616591208
    
    2603	6775609	17636910227
    
    2604	6780816	17657244864
    
    2605	6786025	17677595125
    
    2606	6791236	17697961016
    
    2607	6796449	17718342543
    
    2608	6801664	17738739712
    
    2609	6806881	17759152529
    
    2610	6812100	17779581000
    
    2611	6817321	17800025131
    
    2612	6822544	17820484928
    
    2613	6827769	17840960397
    
    2614	6832996	17861451544
    
    2615	6838225	17881958375
    
    2616	6843456	17902480896
    
    2617	6848689	17923019113
    
    2618	6853924	17943573032
    
    2619	6859161	17964142659
    
    2620	6864400	17984728000
    
    2621	6869641	18005329061
    
    2622	6874884	18025945848
    
    2623	6880129	18046578367
    
    2624	6885376	18067226624
    
    2625	6890625	18087890625
    
    2626	6895876	18108570376
    
    2627	6901129	18129265883
    
    2628	6906384	18149977152
    
    2629	6911641	18170704189
    
    2630	6916900	18191447000
    
    2631	6922161	18212205591
    
    2632	6927424	18232979968
    
    2633	6932689	18253770137
    
    2634	6937956	18274576104
    
    2635	6943225	18295397875
    
    2636	6948496	18316235456
    
    2637	6953769	18337088853
    
    2638	6959044	18357958072
    
    2639	6964321	18378843119
    
    2640	6969600	18399744000
    
    2641	6974881	18420660721
    
    2642	6980164	18441593288
    
    2643	6985449	18462541707
    
    2644	6990736	18483505984
    
    2645	6996025	18504486125
    
    2646	7001316	18525482136
    
    2647	7006609	18546494023
    
    2648	7011904	18567521792
    
    2649	7017201	18588565449
    
    2650	7022500	18609625000
    
    2651	7027801	18630700451
    
    2652	7033104	18651791808
    
    2653	7038409	18672899077
    
    2654	7043716	18694022264
    
    2655	7049025	18715161375
    
    2656	7054336	18736316416
    
    2657	7059649	18757487393
    
    2658	7064964	18778674312
    
    2659	7070281	18799877179
    
    2660	7075600	18821096000
    
    2661	7080921	18842330781
    
    2662	7086244	18863581528
    
    2663	7091569	18884848247
    
    2664	7096896	18906130944
    
    2665	7102225	18927429625
    
    2666	7107556	18948744296
    
    2667	7112889	18970074963
    
    2668	7118224	18991421632
    
    2669	7123561	19012784309
    
    2670	7128900	19034163000
    
    2671	7134241	19055557711
    
    2672	7139584	19076968448
    
    2673	7144929	19098395217
    
    2674	7150276	19119838024
    
    2675	7155625	19141296875
    
    2676	7160976	19162771776
    
    2677	7166329	19184262733
    
    2678	7171684	19205769752
    
    2679	7177041	19227292839
    
    2680	7182400	19248832000
    
    2681	7187761	19270387241
    
    2682	7193124	19291958568
    
    2683	7198489	19313545987
    
    2684	7203856	19335149504
    
    2685	7209225	19356769125
    
    2686	7214596	19378404856
    
    2687	7219969	19400056703
    
    2688	7225344	19421724672
    
    2689	7230721	19443408769
    
    2690	7236100	19465109000
    
    2691	7241481	19486825371
    
    2692	7246864	19508557888
    
    2693	7252249	19530306557
    
    2694	7257636	19552071384
    
    2695	7263025	19573852375
    
    2696	7268416	19595649536
    
    2697	7273809	19617462873
    
    2698	7279204	19639292392
    
    2699	7284601	19661138099
    
    2700	7290000	19683000000
    
    2701	7295401	19704878101
    
    2702	7300804	19726772408
    
    2703	7306209	19748682927
    
    2704	7311616	19770609664
    
    2705	7317025	19792552625
    
    2706	7322436	19814511816
    
    2707	7327849	19836487243
    
    2708	7333264	19858478912
    
    2709	7338681	19880486829
    
    2710	7344100	19902511000
    
    2711	7349521	19924551431
    
    2712	7354944	19946608128
    
    2713	7360369	19968681097
    
    2714	7365796	19990770344
    
    2715	7371225	20012875875
    
    2716	7376656	20034997696
    
    2717	7382089	20057135813
    
    2718	7387524	20079290232
    
    2719	7392961	20101460959
    
    2720	7398400	20123648000
    
    2721	7403841	20145851361
    
    2722	7409284	20168071048
    
    2723	7414729	20190307067
    
    2724	7420176	20212559424
    
    2725	7425625	20234828125
    
    2726	7431076	20257113176
    
    2727	7436529	20279414583
    
    2728	7441984	20301732352
    
    2729	7447441	20324066489
    
    2730	7452900	20346417000
    
    2731	7458361	20368783891
    
    2732	7463824	20391167168
    
    2733	7469289	20413566837
    
    2734	7474756	20435982904
    
    2735	7480225	20458415375
    
    2736	7485696	20480864256
    
    2737	7491169	20503329553
    
    2738	7496644	20525811272
    
    2739	7502121	20548309419
    
    2740	7507600	20570824000
    
    2741	7513081	20593355021
    
    2742	7518564	20615902488
    
    2743	7524049	20638466407
    
    2744	7529536	20661046784
    
    2745	7535025	20683643625
    
    2746	7540516	20706256936
    
    2747	7546009	20728886723
    
    2748	7551504	20751532992
    
    2749	7557001	20774195749
    
    2750	7562500	20796875000
    
    2751	7568001	20819570751
    
    2752	7573504	20842283008
    
    2753	7579009	20865011777
    
    2754	7584516	20887757064
    
    2755	7590025	20910518875
    
    2756	7595536	20933297216
    
    2757	7601049	20956092093
    
    2758	7606564	20978903512
    
    2759	7612081	21001731479
    
    2760	7617600	21024576000
    
    2761	7623121	21047437081
    
    2762	7628644	21070314728
    
    2763	7634169	21093208947
    
    2764	7639696	21116119744
    
    2765	7645225	21139047125
    
    2766	7650756	21161991096
    
    2767	7656289	21184951663
    
    2768	7661824	21207928832
    
    2769	7667361	21230922609
    
    2770	7672900	21253933000
    
    2771	7678441	21276960011
    
    2772	7683984	21300003648
    
    2773	7689529	21323063917
    
    2774	7695076	21346140824
    
    2775	7700625	21369234375
    
    2776	7706176	21392344576
    
    2777	7711729	21415471433
    
    2778	7717284	21438614952
    
    2779	7722841	21461775139
    
    2780	7728400	21484952000
    
    2781	7733961	21508145541
    
    2782	7739524	21531355768
    
    2783	7745089	21554582687
    
    2784	7750656	21577826304
    
    2785	7756225	21601086625
    
    2786	7761796	21624363656
    
    2787	7767369	21647657403
    
    2788	7772944	21670967872
    
    2789	7778521	21694295069
    
    2790	7784100	21717639000
    
    2791	7789681	21740999671
    
    2792	7795264	21764377088
    
    2793	7800849	21787771257
    
    2794	7806436	21811182184
    
    2795	7812025	21834609875
    
    2796	7817616	21858054336
    
    2797	7823209	21881515573
    
    2798	7828804	21904993592
    
    2799	7834401	21928488399
    
    2800	7840000	21952000000
    
    2801	7845601	21975528401
    
    2802	7851204	21999073608
    
    2803	7856809	22022635627
    
    2804	7862416	22046214464
    
    2805	7868025	22069810125
    
    2806	7873636	22093422616
    
    2807	7879249	22117051943
    
    2808	7884864	22140698112
    
    2809	7890481	22164361129
    
    2810	7896100	22188041000
    
    2811	7901721	22211737731
    
    2812	7907344	22235451328
    
    2813	7912969	22259181797
    
    2814	7918596	22282929144
    
    2815	7924225	22306693375
    
    2816	7929856	22330474496
    
    2817	7935489	22354272513
    
    2818	7941124	22378087432
    
    2819	7946761	22401919259
    
    2820	7952400	22425768000
    
    2821	7958041	22449633661
    
    2822	7963684	22473516248
    
    2823	7969329	22497415767
    
    2824	7974976	22521332224
    
    2825	7980625	22545265625
    
    2826	7986276	22569215976
    
    2827	7991929	22593183283
    
    2828	7997584	22617167552
    
    2829	8003241	22641168789
    
    2830	8008900	22665187000
    
    2831	8014561	22689222191
    
    2832	8020224	22713274368
    
    2833	8025889	22737343537
    
    2834	8031556	22761429704
    
    2835	8037225	22785532875
    
    2836	8042896	22809653056
    
    2837	8048569	22833790253
    
    2838	8054244	22857944472
    
    2839	8059921	22882115719
    
    2840	8065600	22906304000
    
    2841	8071281	22930509321
    
    2842	8076964	22954731688
    
    2843	8082649	22978971107
    
    2844	8088336	23003227584
    
    2845	8094025	23027501125
    
    2846	8099716	23051791736
    
    2847	8105409	23076099423
    
    2848	8111104	23100424192
    
    2849	8116801	23124766049
    
    2850	8122500	23149125000
    
    2851	8128201	23173501051
    
    2852	8133904	23197894208
    
    2853	8139609	23222304477
    
    2854	8145316	23246731864
    
    2855	8151025	23271176375
    
    2856	8156736	23295638016
    
    2857	8162449	23320116793
    
    2858	8168164	23344612712
    
    2859	8173881	23369125779
    
    2860	8179600	23393656000
    
    2861	8185321	23418203381
    
    2862	8191044	23442767928
    
    2863	8196769	23467349647
    
    2864	8202496	23491948544
    
    2865	8208225	23516564625
    
    2866	8213956	23541197896
    
    2867	8219689	23565848363
    
    2868	8225424	23590516032
    
    2869	8231161	23615200909
    
    2870	8236900	23639903000
    
    2871	8242641	23664622311
    
    2872	8248384	23689358848
    
    2873	8254129	23714112617
    
    2874	8259876	23738883624
    
    2875	8265625	23763671875
    
    2876	8271376	23788477376
    
    2877	8277129	23813300133
    
    2878	8282884	23838140152
    
    2879	8288641	23862997439
    
    2880	8294400	23887872000
    
    2881	8300161	23912763841
    
    2882	8305924	23937672968
    
    2883	8311689	23962599387
    
    2884	8317456	23987543104
    
    2885	8323225	24012504125
    
    2886	8328996	24037482456
    
    2887	8334769	24062478103
    
    2888	8340544	24087491072
    
    2889	8346321	24112521369
    
    2890	8352100	24137569000
    
    2891	8357881	24162633971
    
    2892	8363664	24187716288
    
    2893	8369449	24212815957
    
    2894	8375236	24237932984
    
    2895	8381025	24263067375
    
    2896	8386816	24288219136
    
    2897	8392609	24313388273
    
    2898	8398404	24338574792
    
    2899	8404201	24363778699
    
    2900	8410000	24389000000
    
    2901	8415801	24414238701
    
    2902	8421604	24439494808
    
    2903	8427409	24464768327
    
    2904	8433216	24490059264
    
    2905	8439025	24515367625
    
    2906	8444836	24540693416
    
    2907	8450649	24566036643
    
    2908	8456464	24591397312
    
    2909	8462281	24616775429
    
    2910	8468100	24642171000
    
    2911	8473921	24667584031
    
    2912	8479744	24693014528
    
    2913	8485569	24718462497
    
    2914	8491396	24743927944
    
    2915	8497225	24769410875
    
    2916	8503056	24794911296
    
    2917	8508889	24820429213
    
    2918	8514724	24845964632
    
    2919	8520561	24871517559
    
    2920	8526400	24897088000
    
    2921	8532241	24922675961
    
    2922	8538084	24948281448
    
    2923	8543929	24973904467
    
    2924	8549776	24999545024
    
    2925	8555625	25025203125
    
    2926	8561476	25050878776
    
    2927	8567329	25076571983
    
    2928	8573184	25102282752
    
    2929	8579041	25128011089
    
    2930	8584900	25153757000
    
    2931	8590761	25179520491
    
    2932	8596624	25205301568
    
    2933	8602489	25231100237
    
    2934	8608356	25256916504
    
    2935	8614225	25282750375
    
    2936	8620096	25308601856
    
    2937	8625969	25334470953
    
    2938	8631844	25360357672
    
    2939	8637721	25386262019
    
    2940	8643600	25412184000
    
    2941	8649481	25438123621
    
    2942	8655364	25464080888
    
    2943	8661249	25490055807
    
    2944	8667136	25516048384
    
    2945	8673025	25542058625
    
    2946	8678916	25568086536
    
    2947	8684809	25594132123
    
    2948	8690704	25620195392
    
    2949	8696601	25646276349
    
    2950	8702500	25672375000
    
    2951	8708401	25698491351
    
    2952	8714304	25724625408
    
    2953	8720209	25750777177
    
    2954	8726116	25776946664
    
    2955	8732025	25803133875
    
    2956	8737936	25829338816
    
    2957	8743849	25855561493
    
    2958	8749764	25881801912
    
    2959	8755681	25908060079
    
    2960	8761600	25934336000
    
    2961	8767521	25960629681
    
    2962	8773444	25986941128
    
    2963	8779369	26013270347
    
    2964	8785296	26039617344
    
    2965	8791225	26065982125
    
    2966	8797156	26092364696
    
    2967	8803089	26118765063
    
    2968	8809024	26145183232
    
    2969	8814961	26171619209
    
    2970	8820900	26198073000
    
    2971	8826841	26224544611
    
    2972	8832784	26251034048
    
    2973	8838729	26277541317
    
    2974	8844676	26304066424
    
    2975	8850625	26330609375
    
    2976	8856576	26357170176
    
    2977	8862529	26383748833
    
    2978	8868484	26410345352
    
    2979	8874441	26436959739
    
    2980	8880400	26463592000
    
    2981	8886361	26490242141
    
    2982	8892324	26516910168
    
    2983	8898289	26543596087
    
    2984	8904256	26570299904
    
    2985	8910225	26597021625
    
    2986	8916196	26623761256
    
    2987	8922169	26650518803
    
    2988	8928144	26677294272
    
    2989	8934121	26704087669
    
    2990	8940100	26730899000
    
    2991	8946081	26757728271
    
    2992	8952064	26784575488
    
    2993	8958049	26811440657
    
    2994	8964036	26838323784
    
    2995	8970025	26865224875
    
    2996	8976016	26892143936
    
    2997	8982009	26919080973
    
    2998	8988004	26946035992
    
    2999	8994001	26973008999
    
    3000	9000000	27000000000
    
    3001	9006001	27027009001
    
    3002	9012004	27054036008
    
    3003	9018009	27081081027
    
    3004	9024016	27108144064
    
    3005	9030025	27135225125
    
    3006	9036036	27162324216
    
    3007	9042049	27189441343
    
    3008	9048064	27216576512
    
    3009	9054081	27243729729
    
    3010	9060100	27270901000
    
    3011	9066121	27298090331
    
    3012	9072144	27325297728
    
    3013	9078169	27352523197
    
    3014	9084196	27379766744
    
    3015	9090225	27407028375
    
    3016	9096256	27434308096
    
    3017	9102289	27461605913
    
    3018	9108324	27488921832
    
    3019	9114361	27516255859
    
    3020	9120400	27543608000
    
    3021	9126441	27570978261
    
    3022	9132484	27598366648
    
    3023	9138529	27625773167
    
    3024	9144576	27653197824
    
    3025	9150625	27680640625
    
    3026	9156676	27708101576
    
    3027	9162729	27735580683
    
    3028	9168784	27763077952
    
    3029	9174841	27790593389
    
    3030	9180900	27818127000
    
    3031	9186961	27845678791
    
    3032	9193024	27873248768
    
    3033	9199089	27900836937
    
    3034	9205156	27928443304
    
    3035	9211225	27956067875
    
    3036	9217296	27983710656
    
    3037	9223369	28011371653
    
    3038	9229444	28039050872
    
    3039	9235521	28066748319
    
    3040	9241600	28094464000
    
    3041	9247681	28122197921
    
    3042	9253764	28149950088
    
    3043	9259849	28177720507
    
    3044	9265936	28205509184
    
    3045	9272025	28233316125
    
    3046	9278116	28261141336
    
    3047	9284209	28288984823
    
    3048	9290304	28316846592
    
    3049	9296401	28344726649
    
    3050	9302500	28372625000
    
    3051	9308601	28400541651
    
    3052	9314704	28428476608
    
    3053	9320809	28456429877
    
    3054	9326916	28484401464
    
    3055	9333025	28512391375
    
    3056	9339136	28540399616
    
    3057	9345249	28568426193
    
    3058	9351364	28596471112
    
    3059	9357481	28624534379
    
    3060	9363600	28652616000
    
    3061	9369721	28680715981
    
    3062	9375844	28708834328
    
    3063	9381969	28736971047
    
    3064	9388096	28765126144
    
    3065	9394225	28793299625
    
    3066	9400356	28821491496
    
    3067	9406489	28849701763
    
    3068	9412624	28877930432
    
    3069	9418761	28906177509
    
    3070	9424900	28934443000
    
    3071	9431041	28962726911
    
    3072	9437184	28991029248
    
    3073	9443329	29019350017
    
    3074	9449476	29047689224
    
    3075	9455625	29076046875
    
    3076	9461776	29104422976
    
    3077	9467929	29132817533
    
    3078	9474084	29161230552
    
    3079	9480241	29189662039
    
    3080	9486400	29218112000
    
    3081	9492561	29246580441
    
    3082	9498724	29275067368
    
    3083	9504889	29303572787
    
    3084	9511056	29332096704
    
    3085	9517225	29360639125
    
    3086	9523396	29389200056
    
    3087	9529569	29417779503
    
    3088	9535744	29446377472
    
    3089	9541921	29474993969
    
    3090	9548100	29503629000
    
    3091	9554281	29532282571
    
    3092	9560464	29560954688
    
    3093	9566649	29589645357
    
    3094	9572836	29618354584
    
    3095	9579025	29647082375
    
    3096	9585216	29675828736
    
    3097	9591409	29704593673
    
    3098	9597604	29733377192
    
    3099	9603801	29762179299
    
    3100	9610000	29791000000
    
    3101	9616201	29819839301
    
    3102	9622404	29848697208
    
    3103	9628609	29877573727
    
    3104	9634816	29906468864
    
    3105	9641025	29935382625
    
    3106	9647236	29964315016
    
    3107	9653449	29993266043
    
    3108	9659664	30022235712
    
    3109	9665881	30051224029
    
    3110	9672100	30080231000
    
    3111	9678321	30109256631
    
    3112	9684544	30138300928
    
    3113	9690769	30167363897
    
    3114	9696996	30196445544
    
    3115	9703225	30225545875
    
    3116	9709456	30254664896
    
    3117	9715689	30283802613
    
    3118	9721924	30312959032
    
    3119	9728161	30342134159
    
    3120	9734400	30371328000
    
    3121	9740641	30400540561
    
    3122	9746884	30429771848
    
    3123	9753129	30459021867
    
    3124	9759376	30488290624
    
    3125	9765625	30517578125
    
    3126	9771876	30546884376
    
    3127	9778129	30576209383
    
    3128	9784384	30605553152
    
    3129	9790641	30634915689
    
    3130	9796900	30664297000
    
    3131	9803161	30693697091
    
    3132	9809424	30723115968
    
    3133	9815689	30752553637
    
    3134	9821956	30782010104
    
    3135	9828225	30811485375
    
    3136	9834496	30840979456
    
    3137	9840769	30870492353
    
    3138	9847044	30900024072
    
    3139	9853321	30929574619
    
    3140	9859600	30959144000
    
    3141	9865881	30988732221
    
    3142	9872164	31018339288
    
    3143	9878449	31047965207
    
    3144	9884736	31077609984
    
    3145	9891025	31107273625
    
    3146	9897316	31136956136
    
    3147	9903609	31166657523
    
    3148	9909904	31196377792
    
    3149	9916201	31226116949
    
    3150	9922500	31255875000
    
    3151	9928801	31285651951
    
    3152	9935104	31315447808
    
    3153	9941409	31345262577
    
    3154	9947716	31375096264
    
    3155	9954025	31404948875
    
    3156	9960336	31434820416
    
    3157	9966649	31464710893
    
    3158	9972964	31494620312
    
    3159	9979281	31524548679
    
    3160	9985600	31554496000
    
    3161	9991921	31584462281
    
    3162	9998244	31614447528
    
    3163	10004569	31644451747
    
    3164	10010896	31674474944
    
    3165	10017225	31704517125
    
    3166	10023556	31734578296
    
    3167	10029889	31764658463
    
    3168	10036224	31794757632
    
    3169	10042561	31824875809
    
    3170	10048900	31855013000
    
    3171	10055241	31885169211
    
    3172	10061584	31915344448
    
    3173	10067929	31945538717
    
    3174	10074276	31975752024
    
    3175	10080625	32005984375
    
    3176	10086976	32036235776
    
    3177	10093329	32066506233
    
    3178	10099684	32096795752
    
    3179	10106041	32127104339
    
    3180	10112400	32157432000
    
    3181	10118761	32187778741
    
    3182	10125124	32218144568
    
    3183	10131489	32248529487
    
    3184	10137856	32278933504
    
    3185	10144225	32309356625
    
    3186	10150596	32339798856
    
    3187	10156969	32370260203
    
    3188	10163344	32400740672
    
    3189	10169721	32431240269
    
    3190	10176100	32461759000
    
    3191	10182481	32492296871
    
    3192	10188864	32522853888
    
    3193	10195249	32553430057
    
    3194	10201636	32584025384
    
    3195	10208025	32614639875
    
    3196	10214416	32645273536
    
    3197	10220809	32675926373
    
    3198	10227204	32706598392
    
    3199	10233601	32737289599
    
    3200	10240000	32768000000
    
    3201	10246401	32798729601
    
    3202	10252804	32829478408
    
    3203	10259209	32860246427
    
    3204	10265616	32891033664
    
    3205	10272025	32921840125
    
    3206	10278436	32952665816
    
    3207	10284849	32983510743
    
    3208	10291264	33014374912
    
    3209	10297681	33045258329
    
    3210	10304100	33076161000
    
    3211	10310521	33107082931
    
    3212	10316944	33138024128
    
    3213	10323369	33168984597
    
    3214	10329796	33199964344
    
    3215	10336225	33230963375
    
    3216	10342656	33261981696
    
    3217	10349089	33293019313
    
    3218	10355524	33324076232
    
    3219	10361961	33355152459
    
    3220	10368400	33386248000
    
    3221	10374841	33417362861
    
    3222	10381284	33448497048
    
    3223	10387729	33479650567
    
    3224	10394176	33510823424
    
    3225	10400625	33542015625
    
    3226	10407076	33573227176
    
    3227	10413529	33604458083
    
    3228	10419984	33635708352
    
    3229	10426441	33666977989
    
    3230	10432900	33698267000
    
    3231	10439361	33729575391
    
    3232	10445824	33760903168
    
    3233	10452289	33792250337
    
    3234	10458756	33823616904
    
    3235	10465225	33855002875
    
    3236	10471696	33886408256
    
    3237	10478169	33917833053
    
    3238	10484644	33949277272
    
    3239	10491121	33980740919
    
    3240	10497600	34012224000
    
    3241	10504081	34043726521
    
    3242	10510564	34075248488
    
    3243	10517049	34106789907
    
    3244	10523536	34138350784
    
    3245	10530025	34169931125
    
    3246	10536516	34201530936
    
    3247	10543009	34233150223
    
    3248	10549504	34264788992
    
    3249	10556001	34296447249
    
    3250	10562500	34328125000
    
    3251	10569001	34359822251
    
    3252	10575504	34391539008
    
    3253	10582009	34423275277
    
    3254	10588516	34455031064
    
    3255	10595025	34486806375
    
    3256	10601536	34518601216
    
    3257	10608049	34550415593
    
    3258	10614564	34582249512
    
    3259	10621081	34614102979
    
    3260	10627600	34645976000
    
    3261	10634121	34677868581
    
    3262	10640644	34709780728
    
    3263	10647169	34741712447
    
    3264	10653696	34773663744
    
    3265	10660225	34805634625
    
    3266	10666756	34837625096
    
    3267	10673289	34869635163
    
    3268	10679824	34901664832
    
    3269	10686361	34933714109
    
    3270	10692900	34965783000
    
    3271	10699441	34997871511
    
    3272	10705984	35029979648
    
    3273	10712529	35062107417
    
    3274	10719076	35094254824
    
    3275	10725625	35126421875
    
    3276	10732176	35158608576
    
    3277	10738729	35190814933
    
    3278	10745284	35223040952
    
    3279	10751841	35255286639
    
    3280	10758400	35287552000
    
    3281	10764961	35319837041
    
    3282	10771524	35352141768
    
    3283	10778089	35384466187
    
    3284	10784656	35416810304
    
    3285	10791225	35449174125
    
    3286	10797796	35481557656
    
    3287	10804369	35513960903
    
    3288	10810944	35546383872
    
    3289	10817521	35578826569
    
    3290	10824100	35611289000
    
    3291	10830681	35643771171
    
    3292	10837264	35676273088
    
    3293	10843849	35708794757
    
    3294	10850436	35741336184
    
    3295	10857025	35773897375
    
    3296	10863616	35806478336
    
    3297	10870209	35839079073
    
    3298	10876804	35871699592
    
    3299	10883401	35904339899
    
    3300	10890000	35937000000
    
    3301	10896601	35969679901
    
    3302	10903204	36002379608
    
    3303	10909809	36035099127
    
    3304	10916416	36067838464
    
    3305	10923025	36100597625
    
    3306	10929636	36133376616
    
    3307	10936249	36166175443
    
    3308	10942864	36198994112
    
    3309	10949481	36231832629
    
    3310	10956100	36264691000
    
    3311	10962721	36297569231
    
    3312	10969344	36330467328
    
    3313	10975969	36363385297
    
    3314	10982596	36396323144
    
    3315	10989225	36429280875
    
    3316	10995856	36462258496
    
    3317	11002489	36495256013
    
    3318	11009124	36528273432
    
    3319	11015761	36561310759
    
    3320	11022400	36594368000
    
    3321	11029041	36627445161
    
    3322	11035684	36660542248
    
    3323	11042329	36693659267
    
    3324	11048976	36726796224
    
    3325	11055625	36759953125
    
    3326	11062276	36793129976
    
    3327	11068929	36826326783
    
    3328	11075584	36859543552
    
    3329	11082241	36892780289
    
    3330	11088900	36926037000
    
    3331	11095561	36959313691
    
    3332	11102224	36992610368
    
    3333	11108889	37025927037
    
    3334	11115556	37059263704
    
    3335	11122225	37092620375
    
    3336	11128896	37125997056
    
    3337	11135569	37159393753
    
    3338	11142244	37192810472
    
    3339	11148921	37226247219
    
    3340	11155600	37259704000
    
    3341	11162281	37293180821
    
    3342	11168964	37326677688
    
    3343	11175649	37360194607
    
    3344	11182336	37393731584
    
    3345	11189025	37427288625
    
    3346	11195716	37460865736
    
    3347	11202409	37494462923
    
    3348	11209104	37528080192
    
    3349	11215801	37561717549
    
    3350	11222500	37595375000
    
    3351	11229201	37629052551
    
    3352	11235904	37662750208
    
    3353	11242609	37696467977
    
    3354	11249316	37730205864
    
    3355	11256025	37763963875
    
    3356	11262736	37797742016
    
    3357	11269449	37831540293
    
    3358	11276164	37865358712
    
    3359	11282881	37899197279
    
    3360	11289600	37933056000
    
    3361	11296321	37966934881
    
    3362	11303044	38000833928
    
    3363	11309769	38034753147
    
    3364	11316496	38068692544
    
    3365	11323225	38102652125
    
    3366	11329956	38136631896
    
    3367	11336689	38170631863
    
    3368	11343424	38204652032
    
    3369	11350161	38238692409
    
    3370	11356900	38272753000
    
    3371	11363641	38306833811
    
    3372	11370384	38340934848
    
    3373	11377129	38375056117
    
    3374	11383876	38409197624
    
    3375	11390625	38443359375
    
    3376	11397376	38477541376
    
    3377	11404129	38511743633
    
    3378	11410884	38545966152
    
    3379	11417641	38580208939
    
    3380	11424400	38614472000
    
    3381	11431161	38648755341
    
    3382	11437924	38683058968
    
    3383	11444689	38717382887
    
    3384	11451456	38751727104
    
    3385	11458225	38786091625
    
    3386	11464996	38820476456
    
    3387	11471769	38854881603
    
    3388	11478544	38889307072
    
    3389	11485321	38923752869
    
    3390	11492100	38958219000
    
    3391	11498881	38992705471
    
    3392	11505664	39027212288
    
    3393	11512449	39061739457
    
    3394	11519236	39096286984
    
    3395	11526025	39130854875
    
    3396	11532816	39165443136
    
    3397	11539609	39200051773
    
    3398	11546404	39234680792
    
    3399	11553201	39269330199
    
    3400	11560000	39304000000
    
    3401	11566801	39338690201
    
    3402	11573604	39373400808
    
    3403	11580409	39408131827
    
    3404	11587216	39442883264
    
    3405	11594025	39477655125
    
    3406	11600836	39512447416
    
    3407	11607649	39547260143
    
    3408	11614464	39582093312
    
    3409	11621281	39616946929
    
    3410	11628100	39651821000
    
    3411	11634921	39686715531
    
    3412	11641744	39721630528
    
    3413	11648569	39756565997
    
    3414	11655396	39791521944
    
    3415	11662225	39826498375
    
    3416	11669056	39861495296
    
    3417	11675889	39896512713
    
    3418	11682724	39931550632
    
    3419	11689561	39966609059
    
    3420	11696400	40001688000
    
    3421	11703241	40036787461
    
    3422	11710084	40071907448
    
    3423	11716929	40107047967
    
    3424	11723776	40142209024
    
    3425	11730625	40177390625
    
    3426	11737476	40212592776
    
    3427	11744329	40247815483
    
    3428	11751184	40283058752
    
    3429	11758041	40318322589
    
    3430	11764900	40353607000
    
    3431	11771761	40388911991
    
    3432	11778624	40424237568
    
    3433	11785489	40459583737
    
    3434	11792356	40494950504
    
    3435	11799225	40530337875
    
    3436	11806096	40565745856
    
    3437	11812969	40601174453
    
    3438	11819844	40636623672
    
    3439	11826721	40672093519
    
    3440	11833600	40707584000
    
    3441	11840481	40743095121
    
    3442	11847364	40778626888
    
    3443	11854249	40814179307
    
    3444	11861136	40849752384
    
    3445	11868025	40885346125
    
    3446	11874916	40920960536
    
    3447	11881809	40956595623
    
    3448	11888704	40992251392
    
    3449	11895601	41027927849
    
    3450	11902500	41063625000
    
    3451	11909401	41099342851
    
    3452	11916304	41135081408
    
    3453	11923209	41170840677
    
    3454	11930116	41206620664
    
    3455	11937025	41242421375
    
    3456	11943936	41278242816
    
    3457	11950849	41314084993
    
    3458	11957764	41349947912
    
    3459	11964681	41385831579
    
    3460	11971600	41421736000
    
    3461	11978521	41457661181
    
    3462	11985444	41493607128
    
    3463	11992369	41529573847
    
    3464	11999296	41565561344
    
    3465	12006225	41601569625
    
    3466	12013156	41637598696
    
    3467	12020089	41673648563
    
    3468	12027024	41709719232
    
    3469	12033961	41745810709
    
    3470	12040900	41781923000
    
    3471	12047841	41818056111
    
    3472	12054784	41854210048
    
    3473	12061729	41890384817
    
    3474	12068676	41926580424
    
    3475	12075625	41962796875
    
    3476	12082576	41999034176
    
    3477	12089529	42035292333
    
    3478	12096484	42071571352
    
    3479	12103441	42107871239
    
    3480	12110400	42144192000
    
    3481	12117361	42180533641
    
    3482	12124324	42216896168
    
    3483	12131289	42253279587
    
    3484	12138256	42289683904
    
    3485	12145225	42326109125
    
    3486	12152196	42362555256
    
    3487	12159169	42399022303
    
    3488	12166144	42435510272
    
    3489	12173121	42472019169
    
    3490	12180100	42508549000
    
    3491	12187081	42545099771
    
    3492	12194064	42581671488
    
    3493	12201049	42618264157
    
    3494	12208036	42654877784
    
    3495	12215025	42691512375
    
    3496	12222016	42728167936
    
    3497	12229009	42764844473
    
    3498	12236004	42801541992
    
    3499	12243001	42838260499
    
    3500	12250000	42875000000
    
    3501	12257001	42911760501
    
    3502	12264004	42948542008
    
    3503	12271009	42985344527
    
    3504	12278016	43022168064
    
    3505	12285025	43059012625
    
    3506	12292036	43095878216
    
    3507	12299049	43132764843
    
    3508	12306064	43169672512
    
    3509	12313081	43206601229
    
    3510	12320100	43243551000
    
    3511	12327121	43280521831
    
    3512	12334144	43317513728
    
    3513	12341169	43354526697
    
    3514	12348196	43391560744
    
    3515	12355225	43428615875
    
    3516	12362256	43465692096
    
    3517	12369289	43502789413
    
    3518	12376324	43539907832
    
    3519	12383361	43577047359
    
    3520	12390400	43614208000
    
    3521	12397441	43651389761
    
    3522	12404484	43688592648
    
    3523	12411529	43725816667
    
    3524	12418576	43763061824
    
    3525	12425625	43800328125
    
    3526	12432676	43837615576
    
    3527	12439729	43874924183
    
    3528	12446784	43912253952
    
    3529	12453841	43949604889
    
    3530	12460900	43986977000
    
    3531	12467961	44024370291
    
    3532	12475024	44061784768
    
    3533	12482089	44099220437
    
    3534	12489156	44136677304
    
    3535	12496225	44174155375
    
    3536	12503296	44211654656
    
    3537	12510369	44249175153
    
    3538	12517444	44286716872
    
    3539	12524521	44324279819
    
    3540	12531600	44361864000
    
    3541	12538681	44399469421
    
    3542	12545764	44437096088
    
    3543	12552849	44474744007
    
    3544	12559936	44512413184
    
    3545	12567025	44550103625
    
    3546	12574116	44587815336
    
    3547	12581209	44625548323
    
    3548	12588304	44663302592
    
    3549	12595401	44701078149
    
    3550	12602500	44738875000
    
    3551	12609601	44776693151
    
    3552	12616704	44814532608
    
    3553	12623809	44852393377
    
    3554	12630916	44890275464
    
    3555	12638025	44928178875
    
    3556	12645136	44966103616
    
    3557	12652249	45004049693
    
    3558	12659364	45042017112
    
    3559	12666481	45080005879
    
    3560	12673600	45118016000
    
    3561	12680721	45156047481
    
    3562	12687844	45194100328
    
    3563	12694969	45232174547
    
    3564	12702096	45270270144
    
    3565	12709225	45308387125
    
    3566	12716356	45346525496
    
    3567	12723489	45384685263
    
    3568	12730624	45422866432
    
    3569	12737761	45461069009
    
    3570	12744900	45499293000
    
    3571	12752041	45537538411
    
    3572	12759184	45575805248
    
    3573	12766329	45614093517
    
    3574	12773476	45652403224
    
    3575	12780625	45690734375
    
    3576	12787776	45729086976
    
    3577	12794929	45767461033
    
    3578	12802084	45805856552
    
    3579	12809241	45844273539
    
    3580	12816400	45882712000
    
    3581	12823561	45921171941
    
    3582	12830724	45959653368
    
    3583	12837889	45998156287
    
    3584	12845056	46036680704
    
    3585	12852225	46075226625
    
    3586	12859396	46113794056
    
    3587	12866569	46152383003
    
    3588	12873744	46190993472
    
    3589	12880921	46229625469
    
    3590	12888100	46268279000
    
    3591	12895281	46306954071
    
    3592	12902464	46345650688
    
    3593	12909649	46384368857
    
    3594	12916836	46423108584
    
    3595	12924025	46461869875
    
    3596	12931216	46500652736
    
    3597	12938409	46539457173
    
    3598	12945604	46578283192
    
    3599	12952801	46617130799
    
    3600	12960000	46656000000
    
    3601	12967201	46694890801
    
    3602	12974404	46733803208
    
    3603	12981609	46772737227
    
    3604	12988816	46811692864
    
    3605	12996025	46850670125
    
    3606	13003236	46889669016
    
    3607	13010449	46928689543
    
    3608	13017664	46967731712
    
    3609	13024881	47006795529
    
    3610	13032100	47045881000
    
    3611	13039321	47084988131
    
    3612	13046544	47124116928
    
    3613	13053769	47163267397
    
    3614	13060996	47202439544
    
    3615	13068225	47241633375
    
    3616	13075456	47280848896
    
    3617	13082689	47320086113
    
    3618	13089924	47359345032
    
    3619	13097161	47398625659
    
    3620	13104400	47437928000
    
    3621	13111641	47477252061
    
    3622	13118884	47516597848
    
    3623	13126129	47555965367
    
    3624	13133376	47595354624
    
    3625	13140625	47634765625
    
    3626	13147876	47674198376
    
    3627	13155129	47713652883
    
    3628	13162384	47753129152
    
    3629	13169641	47792627189
    
    3630	13176900	47832147000
    
    3631	13184161	47871688591
    
    3632	13191424	47911251968
    
    3633	13198689	47950837137
    
    3634	13205956	47990444104
    
    3635	13213225	48030072875
    
    3636	13220496	48069723456
    
    3637	13227769	48109395853
    
    3638	13235044	48149090072
    
    3639	13242321	48188806119
    
    3640	13249600	48228544000
    
    3641	13256881	48268303721
    
    3642	13264164	48308085288
    
    3643	13271449	48347888707
    
    3644	13278736	48387713984
    
    3645	13286025	48427561125
    
    3646	13293316	48467430136
    
    3647	13300609	48507321023
    
    3648	13307904	48547233792
    
    3649	13315201	48587168449
    
    3650	13322500	48627125000
    
    3651	13329801	48667103451
    
    3652	13337104	48707103808
    
    3653	13344409	48747126077
    
    3654	13351716	48787170264
    
    3655	13359025	48827236375
    
    3656	13366336	48867324416
    
    3657	13373649	48907434393
    
    3658	13380964	48947566312
    
    3659	13388281	48987720179
    
    3660	13395600	49027896000
    
    3661	13402921	49068093781
    
    3662	13410244	49108313528
    
    3663	13417569	49148555247
    
    3664	13424896	49188818944
    
    3665	13432225	49229104625
    
    3666	13439556	49269412296
    
    3667	13446889	49309741963
    
    3668	13454224	49350093632
    
    3669	13461561	49390467309
    
    3670	13468900	49430863000
    
    3671	13476241	49471280711
    
    3672	13483584	49511720448
    
    3673	13490929	49552182217
    
    3674	13498276	49592666024
    
    3675	13505625	49633171875
    
    3676	13512976	49673699776
    
    3677	13520329	49714249733
    
    3678	13527684	49754821752
    
    3679	13535041	49795415839
    
    3680	13542400	49836032000
    
    3681	13549761	49876670241
    
    3682	13557124	49917330568
    
    3683	13564489	49958012987
    
    3684	13571856	49998717504
    
    3685	13579225	50039444125
    
    3686	13586596	50080192856
    
    3687	13593969	50120963703
    
    3688	13601344	50161756672
    
    3689	13608721	50202571769
    
    3690	13616100	50243409000
    
    3691	13623481	50284268371
    
    3692	13630864	50325149888
    
    3693	13638249	50366053557
    
    3694	13645636	50406979384
    
    3695	13653025	50447927375
    
    3696	13660416	50488897536
    
    3697	13667809	50529889873
    
    3698	13675204	50570904392
    
    3699	13682601	50611941099
    
    3700	13690000	50653000000
    
    3701	13697401	50694081101
    
    3702	13704804	50735184408
    
    3703	13712209	50776309927
    
    3704	13719616	50817457664
    
    3705	13727025	50858627625
    
    3706	13734436	50899819816
    
    3707	13741849	50941034243
    
    3708	13749264	50982270912
    
    3709	13756681	51023529829
    
    3710	13764100	51064811000
    
    3711	13771521	51106114431
    
    3712	13778944	51147440128
    
    3713	13786369	51188788097
    
    3714	13793796	51230158344
    
    3715	13801225	51271550875
    
    3716	13808656	51312965696
    
    3717	13816089	51354402813
    
    3718	13823524	51395862232
    
    3719	13830961	51437343959
    
    3720	13838400	51478848000
    
    3721	13845841	51520374361
    
    3722	13853284	51561923048
    
    3723	13860729	51603494067
    
    3724	13868176	51645087424
    
    3725	13875625	51686703125
    
    3726	13883076	51728341176
    
    3727	13890529	51770001583
    
    3728	13897984	51811684352
    
    3729	13905441	51853389489
    
    3730	13912900	51895117000
    
    3731	13920361	51936866891
    
    3732	13927824	51978639168
    
    3733	13935289	52020433837
    
    3734	13942756	52062250904
    
    3735	13950225	52104090375
    
    3736	13957696	52145952256
    
    3737	13965169	52187836553
    
    3738	13972644	52229743272
    
    3739	13980121	52271672419
    
    3740	13987600	52313624000
    
    3741	13995081	52355598021
    
    3742	14002564	52397594488
    
    3743	14010049	52439613407
    
    3744	14017536	52481654784
    
    3745	14025025	52523718625
    
    3746	14032516	52565804936
    
    3747	14040009	52607913723
    
    3748	14047504	52650044992
    
    3749	14055001	52692198749
    
    3750	14062500	52734375000
    
    3751	14070001	52776573751
    
    3752	14077504	52818795008
    
    3753	14085009	52861038777
    
    3754	14092516	52903305064
    
    3755	14100025	52945593875
    
    3756	14107536	52987905216
    
    3757	14115049	53030239093
    
    3758	14122564	53072595512
    
    3759	14130081	53114974479
    
    3760	14137600	53157376000
    
    3761	14145121	53199800081
    
    3762	14152644	53242246728
    
    3763	14160169	53284715947
    
    3764	14167696	53327207744
    
    3765	14175225	53369722125
    
    3766	14182756	53412259096
    
    3767	14190289	53454818663
    
    3768	14197824	53497400832
    
    3769	14205361	53540005609
    
    3770	14212900	53582633000
    
    3771	14220441	53625283011
    
    3772	14227984	53667955648
    
    3773	14235529	53710650917
    
    3774	14243076	53753368824
    
    3775	14250625	53796109375
    
    3776	14258176	53838872576
    
    3777	14265729	53881658433
    
    3778	14273284	53924466952
    
    3779	14280841	53967298139
    
    3780	14288400	54010152000
    
    3781	14295961	54053028541
    
    3782	14303524	54095927768
    
    3783	14311089	54138849687
    
    3784	14318656	54181794304
    
    3785	14326225	54224761625
    
    3786	14333796	54267751656
    
    3787	14341369	54310764403
    
    3788	14348944	54353799872
    
    3789	14356521	54396858069
    
    3790	14364100	54439939000
    
    3791	14371681	54483042671
    
    3792	14379264	54526169088
    
    3793	14386849	54569318257
    
    3794	14394436	54612490184
    
    3795	14402025	54655684875
    
    3796	14409616	54698902336
    
    3797	14417209	54742142573
    
    3798	14424804	54785405592
    
    3799	14432401	54828691399
    
    3800	14440000	54872000000
    
    3801	14447601	54915331401
    
    3802	14455204	54958685608
    
    3803	14462809	55002062627
    
    3804	14470416	55045462464
    
    3805	14478025	55088885125
    
    3806	14485636	55132330616
    
    3807	14493249	55175798943
    
    3808	14500864	55219290112
    
    3809	14508481	55262804129
    
    3810	14516100	55306341000
    
    3811	14523721	55349900731
    
    3812	14531344	55393483328
    
    3813	14538969	55437088797
    
    3814	14546596	55480717144
    
    3815	14554225	55524368375
    
    3816	14561856	55568042496
    
    3817	14569489	55611739513
    
    3818	14577124	55655459432
    
    3819	14584761	55699202259
    
    3820	14592400	55742968000
    
    3821	14600041	55786756661
    
    3822	14607684	55830568248
    
    3823	14615329	55874402767
    
    3824	14622976	55918260224
    
    3825	14630625	55962140625
    
    3826	14638276	56006043976
    
    3827	14645929	56049970283
    
    3828	14653584	56093919552
    
    3829	14661241	56137891789
    
    3830	14668900	56181887000
    
    3831	14676561	56225905191
    
    3832	14684224	56269946368
    
    3833	14691889	56314010537
    
    3834	14699556	56358097704
    
    3835	14707225	56402207875
    
    3836	14714896	56446341056
    
    3837	14722569	56490497253
    
    3838	14730244	56534676472
    
    3839	14737921	56578878719
    
    3840	14745600	56623104000
    
    3841	14753281	56667352321
    
    3842	14760964	56711623688
    
    3843	14768649	56755918107
    
    3844	14776336	56800235584
    
    3845	14784025	56844576125
    
    3846	14791716	56888939736
    
    3847	14799409	56933326423
    
    3848	14807104	56977736192
    
    3849	14814801	57022169049
    
    3850	14822500	57066625000
    
    3851	14830201	57111104051
    
    3852	14837904	57155606208
    
    3853	14845609	57200131477
    
    3854	14853316	57244679864
    
    3855	14861025	57289251375
    
    3856	14868736	57333846016
    
    3857	14876449	57378463793
    
    3858	14884164	57423104712
    
    3859	14891881	57467768779
    
    3860	14899600	57512456000
    
    3861	14907321	57557166381
    
    3862	14915044	57601899928
    
    3863	14922769	57646656647
    
    3864	14930496	57691436544
    
    3865	14938225	57736239625
    
    3866	14945956	57781065896
    
    3867	14953689	57825915363
    
    3868	14961424	57870788032
    
    3869	14969161	57915683909
    
    3870	14976900	57960603000
    
    3871	14984641	58005545311
    
    3872	14992384	58050510848
    
    3873	15000129	58095499617
    
    3874	15007876	58140511624
    
    3875	15015625	58185546875
    
    3876	15023376	58230605376
    
    3877	15031129	58275687133
    
    3878	15038884	58320792152
    
    3879	15046641	58365920439
    
    3880	15054400	58411072000
    
    3881	15062161	58456246841
    
    3882	15069924	58501444968
    
    3883	15077689	58546666387
    
    3884	15085456	58591911104
    
    3885	15093225	58637179125
    
    3886	15100996	58682470456
    
    3887	15108769	58727785103
    
    3888	15116544	58773123072
    
    3889	15124321	58818484369
    
    3890	15132100	58863869000
    
    3891	15139881	58909276971
    
    3892	15147664	58954708288
    
    3893	15155449	59000162957
    
    3894	15163236	59045640984
    
    3895	15171025	59091142375
    
    3896	15178816	59136667136
    
    3897	15186609	59182215273
    
    3898	15194404	59227786792
    
    3899	15202201	59273381699
    
    3900	15210000	59319000000
    
    3901	15217801	59364641701
    
    3902	15225604	59410306808
    
    3903	15233409	59455995327
    
    3904	15241216	59501707264
    
    3905	15249025	59547442625
    
    3906	15256836	59593201416
    
    3907	15264649	59638983643
    
    3908	15272464	59684789312
    
    3909	15280281	59730618429
    
    3910	15288100	59776471000
    
    3911	15295921	59822347031
    
    3912	15303744	59868246528
    
    3913	15311569	59914169497
    
    3914	15319396	59960115944
    
    3915	15327225	60006085875
    
    3916	15335056	60052079296
    
    3917	15342889	60098096213
    
    3918	15350724	60144136632
    
    3919	15358561	60190200559
    
    3920	15366400	60236288000
    
    3921	15374241	60282398961
    
    3922	15382084	60328533448
    
    3923	15389929	60374691467
    
    3924	15397776	60420873024
    
    3925	15405625	60467078125
    
    3926	15413476	60513306776
    
    3927	15421329	60559558983
    
    3928	15429184	60605834752
    
    3929	15437041	60652134089
    
    3930	15444900	60698457000
    
    3931	15452761	60744803491
    
    3932	15460624	60791173568
    
    3933	15468489	60837567237
    
    3934	15476356	60883984504
    
    3935	15484225	60930425375
    
    3936	15492096	60976889856
    
    3937	15499969	61023377953
    
    3938	15507844	61069889672
    
    3939	15515721	61116425019
    
    3940	15523600	61162984000
    
    3941	15531481	61209566621
    
    3942	15539364	61256172888
    
    3943	15547249	61302802807
    
    3944	15555136	61349456384
    
    3945	15563025	61396133625
    
    3946	15570916	61442834536
    
    3947	15578809	61489559123
    
    3948	15586704	61536307392
    
    3949	15594601	61583079349
    
    3950	15602500	61629875000
    
    3951	15610401	61676694351
    
    3952	15618304	61723537408
    
    3953	15626209	61770404177
    
    3954	15634116	61817294664
    
    3955	15642025	61864208875
    
    3956	15649936	61911146816
    
    3957	15657849	61958108493
    
    3958	15665764	62005093912
    
    3959	15673681	62052103079
    
    3960	15681600	62099136000
    
    3961	15689521	62146192681
    
    3962	15697444	62193273128
    
    3963	15705369	62240377347
    
    3964	15713296	62287505344
    
    3965	15721225	62334657125
    
    3966	15729156	62381832696
    
    3967	15737089	62429032063
    
    3968	15745024	62476255232
    
    3969	15752961	62523502209
    
    3970	15760900	62570773000
    
    3971	15768841	62618067611
    
    3972	15776784	62665386048
    
    3973	15784729	62712728317
    
    3974	15792676	62760094424
    
    3975	15800625	62807484375
    
    3976	15808576	62854898176
    
    3977	15816529	62902335833
    
    3978	15824484	62949797352
    
    3979	15832441	62997282739
    
    3980	15840400	63044792000
    
    3981	15848361	63092325141
    
    3982	15856324	63139882168
    
    3983	15864289	63187463087
    
    3984	15872256	63235067904
    
    3985	15880225	63282696625
    
    3986	15888196	63330349256
    
    3987	15896169	63378025803
    
    3988	15904144	63425726272
    
    3989	15912121	63473450669
    
    3990	15920100	63521199000
    
    3991	15928081	63568971271
    
    3992	15936064	63616767488
    
    3993	15944049	63664587657
    
    3994	15952036	63712431784
    
    3995	15960025	63760299875
    
    3996	15968016	63808191936
    
    3997	15976009	63856107973
    
    3998	15984004	63904047992
    
    3999	15992001	63952011999
    
    4000	16000000	64000000000
    
    4001	16008001	64048012001
    
    4002	16016004	64096048008
    
    4003	16024009	64144108027
    
    4004	16032016	64192192064
    
    4005	16040025	64240300125
    
    4006	16048036	64288432216
    
    4007	16056049	64336588343
    
    4008	16064064	64384768512
    
    4009	16072081	64432972729
    
    4010	16080100	64481201000
    
    4011	16088121	64529453331
    
    4012	16096144	64577729728
    
    4013	16104169	64626030197
    
    4014	16112196	64674354744
    
    4015	16120225	64722703375
    
    4016	16128256	64771076096
    
    4017	16136289	64819472913
    
    4018	16144324	64867893832
    
    4019	16152361	64916338859
    
    4020	16160400	64964808000
    
    4021	16168441	65013301261
    
    4022	16176484	65061818648
    
    4023	16184529	65110360167
    
    4024	16192576	65158925824
    
    4025	16200625	65207515625
    
    4026	16208676	65256129576
    
    4027	16216729	65304767683
    
    4028	16224784	65353429952
    
    4029	16232841	65402116389
    
    4030	16240900	65450827000
    
    4031	16248961	65499561791
    
    4032	16257024	65548320768
    
    4033	16265089	65597103937
    
    4034	16273156	65645911304
    
    4035	16281225	65694742875
    
    4036	16289296	65743598656
    
    4037	16297369	65792478653
    
    4038	16305444	65841382872
    
    4039	16313521	65890311319
    
    4040	16321600	65939264000
    
    4041	16329681	65988240921
    
    4042	16337764	66037242088
    
    4043	16345849	66086267507
    
    4044	16353936	66135317184
    
    4045	16362025	66184391125
    
    4046	16370116	66233489336
    
    4047	16378209	66282611823
    
    4048	16386304	66331758592
    
    4049	16394401	66380929649
    
    4050	16402500	66430125000
    
    4051	16410601	66479344651
    
    4052	16418704	66528588608
    
    4053	16426809	66577856877
    
    4054	16434916	66627149464
    
    4055	16443025	66676466375
    
    4056	16451136	66725807616
    
    4057	16459249	66775173193
    
    4058	16467364	66824563112
    
    4059	16475481	66873977379
    
    4060	16483600	66923416000
    
    4061	16491721	66972878981
    
    4062	16499844	67022366328
    
    4063	16507969	67071878047
    
    4064	16516096	67121414144
    
    4065	16524225	67170974625
    
    4066	16532356	67220559496
    
    4067	16540489	67270168763
    
    4068	16548624	67319802432
    
    4069	16556761	67369460509
    
    4070	16564900	67419143000
    
    4071	16573041	67468849911
    
    4072	16581184	67518581248
    
    4073	16589329	67568337017
    
    4074	16597476	67618117224
    
    4075	16605625	67667921875
    
    4076	16613776	67717750976
    
    4077	16621929	67767604533
    
    4078	16630084	67817482552
    
    4079	16638241	67867385039
    
    4080	16646400	67917312000
    
    4081	16654561	67967263441
    
    4082	16662724	68017239368
    
    4083	16670889	68067239787
    
    4084	16679056	68117264704
    
    4085	16687225	68167314125
    
    4086	16695396	68217388056
    
    4087	16703569	68267486503
    
    4088	16711744	68317609472
    
    4089	16719921	68367756969
    
    4090	16728100	68417929000
    
    4091	16736281	68468125571
    
    4092	16744464	68518346688
    
    4093	16752649	68568592357
    
    4094	16760836	68618862584
    
    4095	16769025	68669157375
    
    4096	16777216	68719476736
    
    4097	16785409	68769820673
    
    4098	16793604	68820189192
    
    4099	16801801	68870582299
    
    4100	16810000	68921000000
    
    4101	16818201	68971442301
    
    4102	16826404	69021909208
    
    4103	16834609	69072400727
    
    4104	16842816	69122916864
    
    4105	16851025	69173457625
    
    4106	16859236	69224023016
    
    4107	16867449	69274613043
    
    4108	16875664	69325227712
    
    4109	16883881	69375867029
    
    4110	16892100	69426531000
    
    4111	16900321	69477219631
    
    4112	16908544	69527932928
    
    4113	16916769	69578670897
    
    4114	16924996	69629433544
    
    4115	16933225	69680220875
    
    4116	16941456	69731032896
    
    4117	16949689	69781869613
    
    4118	16957924	69832731032
    
    4119	16966161	69883617159
    
    4120	16974400	69934528000
    
    4121	16982641	69985463561
    
    4122	16990884	70036423848
    
    4123	16999129	70087408867
    
    4124	17007376	70138418624
    
    4125	17015625	70189453125
    
    4126	17023876	70240512376
    
    4127	17032129	70291596383
    
    4128	17040384	70342705152
    
    4129	17048641	70393838689
    
    4130	17056900	70444997000
    
    4131	17065161	70496180091
    
    4132	17073424	70547387968
    
    4133	17081689	70598620637
    
    4134	17089956	70649878104
    
    4135	17098225	70701160375
    
    4136	17106496	70752467456
    
    4137	17114769	70803799353
    
    4138	17123044	70855156072
    
    4139	17131321	70906537619
    
    4140	17139600	70957944000
    
    4141	17147881	71009375221
    
    4142	17156164	71060831288
    
    4143	17164449	71112312207
    
    4144	17172736	71163817984
    
    4145	17181025	71215348625
    
    4146	17189316	71266904136
    
    4147	17197609	71318484523
    
    4148	17205904	71370089792
    
    4149	17214201	71421719949
    
    4150	17222500	71473375000
    
    4151	17230801	71525054951
    
    4152	17239104	71576759808
    
    4153	17247409	71628489577
    
    4154	17255716	71680244264
    
    4155	17264025	71732023875
    
    4156	17272336	71783828416
    
    4157	17280649	71835657893
    
    4158	17288964	71887512312
    
    4159	17297281	71939391679
    
    4160	17305600	71991296000
    
    4161	17313921	72043225281
    
    4162	17322244	72095179528
    
    4163	17330569	72147158747
    
    4164	17338896	72199162944
    
    4165	17347225	72251192125
    
    4166	17355556	72303246296
    
    4167	17363889	72355325463
    
    4168	17372224	72407429632
    
    4169	17380561	72459558809
    
    4170	17388900	72511713000
    
    4171	17397241	72563892211
    
    4172	17405584	72616096448
    
    4173	17413929	72668325717
    
    4174	17422276	72720580024
    
    4175	17430625	72772859375
    
    4176	17438976	72825163776
    
    4177	17447329	72877493233
    
    4178	17455684	72929847752
    
    4179	17464041	72982227339
    
    4180	17472400	73034632000
    
    4181	17480761	73087061741
    
    4182	17489124	73139516568
    
    4183	17497489	73191996487
    
    4184	17505856	73244501504
    
    4185	17514225	73297031625
    
    4186	17522596	73349586856
    
    4187	17530969	73402167203
    
    4188	17539344	73454772672
    
    4189	17547721	73507403269
    
    4190	17556100	73560059000
    
    4191	17564481	73612739871
    
    4192	17572864	73665445888
    
    4193	17581249	73718177057
    
    4194	17589636	73770933384
    
    4195	17598025	73823714875
    
    4196	17606416	73876521536
    
    4197	17614809	73929353373
    
    4198	17623204	73982210392
    
    4199	17631601	74035092599
    
    4200	17640000	74088000000
    
    4201	17648401	74140932601
    
    4202	17656804	74193890408
    
    4203	17665209	74246873427
    
    4204	17673616	74299881664
    
    4205	17682025	74352915125
    
    4206	17690436	74405973816
    
    4207	17698849	74459057743
    
    4208	17707264	74512166912
    
    4209	17715681	74565301329
    
    4210	17724100	74618461000
    
    4211	17732521	74671645931
    
    4212	17740944	74724856128
    
    4213	17749369	74778091597
    
    4214	17757796	74831352344
    
    4215	17766225	74884638375
    
    4216	17774656	74937949696
    
    4217	17783089	74991286313
    
    4218	17791524	75044648232
    
    4219	17799961	75098035459
    
    4220	17808400	75151448000
    
    4221	17816841	75204885861
    
    4222	17825284	75258349048
    
    4223	17833729	75311837567
    
    4224	17842176	75365351424
    
    4225	17850625	75418890625
    
    4226	17859076	75472455176
    
    4227	17867529	75526045083
    
    4228	17875984	75579660352
    
    4229	17884441	75633300989
    
    4230	17892900	75686967000
    
    4231	17901361	75740658391
    
    4232	17909824	75794375168
    
    4233	17918289	75848117337
    
    4234	17926756	75901884904
    
    4235	17935225	75955677875
    
    4236	17943696	76009496256
    
    4237	17952169	76063340053
    
    4238	17960644	76117209272
    
    4239	17969121	76171103919
    
    4240	17977600	76225024000
    
    4241	17986081	76278969521
    
    4242	17994564	76332940488
    
    4243	18003049	76386936907
    
    4244	18011536	76440958784
    
    4245	18020025	76495006125
    
    4246	18028516	76549078936
    
    4247	18037009	76603177223
    
    4248	18045504	76657300992
    
    4249	18054001	76711450249
    
    4250	18062500	76765625000
    
    4251	18071001	76819825251
    
    4252	18079504	76874051008
    
    4253	18088009	76928302277
    
    4254	18096516	76982579064
    
    4255	18105025	77036881375
    
    4256	18113536	77091209216
    
    4257	18122049	77145562593
    
    4258	18130564	77199941512
    
    4259	18139081	77254345979
    
    4260	18147600	77308776000
    
    4261	18156121	77363231581
    
    4262	18164644	77417712728
    
    4263	18173169	77472219447
    
    4264	18181696	77526751744
    
    4265	18190225	77581309625
    
    4266	18198756	77635893096
    
    4267	18207289	77690502163
    
    4268	18215824	77745136832
    
    4269	18224361	77799797109
    
    4270	18232900	77854483000
    
    4271	18241441	77909194511
    
    4272	18249984	77963931648
    
    4273	18258529	78018694417
    
    4274	18267076	78073482824
    
    4275	18275625	78128296875
    
    4276	18284176	78183136576
    
    4277	18292729	78238001933
    
    4278	18301284	78292892952
    
    4279	18309841	78347809639
    
    4280	18318400	78402752000
    
    4281	18326961	78457720041
    
    4282	18335524	78512713768
    
    4283	18344089	78567733187
    
    4284	18352656	78622778304
    
    4285	18361225	78677849125
    
    4286	18369796	78732945656
    
    4287	18378369	78788067903
    
    4288	18386944	78843215872
    
    4289	18395521	78898389569
    
    4290	18404100	78953589000
    
    4291	18412681	79008814171
    
    4292	18421264	79064065088
    
    4293	18429849	79119341757
    
    4294	18438436	79174644184
    
    4295	18447025	79229972375
    
    4296	18455616	79285326336
    
    4297	18464209	79340706073
    
    4298	18472804	79396111592
    
    4299	18481401	79451542899
    
    4300	18490000	79507000000
    
    4301	18498601	79562482901
    
    4302	18507204	79617991608
    
    4303	18515809	79673526127
    
    4304	18524416	79729086464
    
    4305	18533025	79784672625
    
    4306	18541636	79840284616
    
    4307	18550249	79895922443
    
    4308	18558864	79951586112
    
    4309	18567481	80007275629
    
    4310	18576100	80062991000
    
    4311	18584721	80118732231
    
    4312	18593344	80174499328
    
    4313	18601969	80230292297
    
    4314	18610596	80286111144
    
    4315	18619225	80341955875
    
    4316	18627856	80397826496
    
    4317	18636489	80453723013
    
    4318	18645124	80509645432
    
    4319	18653761	80565593759
    
    4320	18662400	80621568000
    
    4321	18671041	80677568161
    
    4322	18679684	80733594248
    
    4323	18688329	80789646267
    
    4324	18696976	80845724224
    
    4325	18705625	80901828125
    
    4326	18714276	80957957976
    
    4327	18722929	81014113783
    
    4328	18731584	81070295552
    
    4329	18740241	81126503289
    
    4330	18748900	81182737000
    
    4331	18757561	81238996691
    
    4332	18766224	81295282368
    
    4333	18774889	81351594037
    
    4334	18783556	81407931704
    
    4335	18792225	81464295375
    
    4336	18800896	81520685056
    
    4337	18809569	81577100753
    
    4338	18818244	81633542472
    
    4339	18826921	81690010219
    
    4340	18835600	81746504000
    
    4341	18844281	81803023821
    
    4342	18852964	81859569688
    
    4343	18861649	81916141607
    
    4344	18870336	81972739584
    
    4345	18879025	82029363625
    
    4346	18887716	82086013736
    
    4347	18896409	82142689923
    
    4348	18905104	82199392192
    
    4349	18913801	82256120549
    
    4350	18922500	82312875000
    
    4351	18931201	82369655551
    
    4352	18939904	82426462208
    
    4353	18948609	82483294977
    
    4354	18957316	82540153864
    
    4355	18966025	82597038875
    
    4356	18974736	82653950016
    
    4357	18983449	82710887293
    
    4358	18992164	82767850712
    
    4359	19000881	82824840279
    
    4360	19009600	82881856000
    
    4361	19018321	82938897881
    
    4362	19027044	82995965928
    
    4363	19035769	83053060147
    
    4364	19044496	83110180544
    
    4365	19053225	83167327125
    
    4366	19061956	83224499896
    
    4367	19070689	83281698863
    
    4368	19079424	83338924032
    
    4369	19088161	83396175409
    
    4370	19096900	83453453000
    
    4371	19105641	83510756811
    
    4372	19114384	83568086848
    
    4373	19123129	83625443117
    
    4374	19131876	83682825624
    
    4375	19140625	83740234375
    
    4376	19149376	83797669376
    
    4377	19158129	83855130633
    
    4378	19166884	83912618152
    
    4379	19175641	83970131939
    
    4380	19184400	84027672000
    
    4381	19193161	84085238341
    
    4382	19201924	84142830968
    
    4383	19210689	84200449887
    
    4384	19219456	84258095104
    
    4385	19228225	84315766625
    
    4386	19236996	84373464456
    
    4387	19245769	84431188603
    
    4388	19254544	84488939072
    
    4389	19263321	84546715869
    
    4390	19272100	84604519000
    
    4391	19280881	84662348471
    
    4392	19289664	84720204288
    
    4393	19298449	84778086457
    
    4394	19307236	84835994984
    
    4395	19316025	84893929875
    
    4396	19324816	84951891136
    
    4397	19333609	85009878773
    
    4398	19342404	85067892792
    
    4399	19351201	85125933199
    
    4400	19360000	85184000000
    
    4401	19368801	85242093201
    
    4402	19377604	85300212808
    
    4403	19386409	85358358827
    
    4404	19395216	85416531264
    
    4405	19404025	85474730125
    
    4406	19412836	85532955416
    
    4407	19421649	85591207143
    
    4408	19430464	85649485312
    
    4409	19439281	85707789929
    
    4410	19448100	85766121000
    
    4411	19456921	85824478531
    
    4412	19465744	85882862528
    
    4413	19474569	85941272997
    
    4414	19483396	85999709944
    
    4415	19492225	86058173375
    
    4416	19501056	86116663296
    
    4417	19509889	86175179713
    
    4418	19518724	86233722632
    
    4419	19527561	86292292059
    
    4420	19536400	86350888000
    
    4421	19545241	86409510461
    
    4422	19554084	86468159448
    
    4423	19562929	86526834967
    
    4424	19571776	86585537024
    
    4425	19580625	86644265625
    
    4426	19589476	86703020776
    
    4427	19598329	86761802483
    
    4428	19607184	86820610752
    
    4429	19616041	86879445589
    
    4430	19624900	86938307000
    
    4431	19633761	86997194991
    
    4432	19642624	87056109568
    
    4433	19651489	87115050737
    
    4434	19660356	87174018504
    
    4435	19669225	87233012875
    
    4436	19678096	87292033856
    
    4437	19686969	87351081453
    
    4438	19695844	87410155672
    
    4439	19704721	87469256519
    
    4440	19713600	87528384000
    
    4441	19722481	87587538121
    
    4442	19731364	87646718888
    
    4443	19740249	87705926307
    
    4444	19749136	87765160384
    
    4445	19758025	87824421125
    
    4446	19766916	87883708536
    
    4447	19775809	87943022623
    
    4448	19784704	88002363392
    
    4449	19793601	88061730849
    
    4450	19802500	88121125000
    
    4451	19811401	88180545851
    
    4452	19820304	88239993408
    
    4453	19829209	88299467677
    
    4454	19838116	88358968664
    
    4455	19847025	88418496375
    
    4456	19855936	88478050816
    
    4457	19864849	88537631993
    
    4458	19873764	88597239912
    
    4459	19882681	88656874579
    
    4460	19891600	88716536000
    
    4461	19900521	88776224181
    
    4462	19909444	88835939128
    
    4463	19918369	88895680847
    
    4464	19927296	88955449344
    
    4465	19936225	89015244625
    
    4466	19945156	89075066696
    
    4467	19954089	89134915563
    
    4468	19963024	89194791232
    
    4469	19971961	89254693709
    
    4470	19980900	89314623000
    
    4471	19989841	89374579111
    
    4472	19998784	89434562048
    
    4473	20007729	89494571817
    
    4474	20016676	89554608424
    
    4475	20025625	89614671875
    
    4476	20034576	89674762176
    
    4477	20043529	89734879333
    
    4478	20052484	89795023352
    
    4479	20061441	89855194239
    
    4480	20070400	89915392000
    
    4481	20079361	89975616641
    
    4482	20088324	90035868168
    
    4483	20097289	90096146587
    
    4484	20106256	90156451904
    
    4485	20115225	90216784125
    
    4486	20124196	90277143256
    
    4487	20133169	90337529303
    
    4488	20142144	90397942272
    
    4489	20151121	90458382169
    
    4490	20160100	90518849000
    
    4491	20169081	90579342771
    
    4492	20178064	90639863488
    
    4493	20187049	90700411157
    
    4494	20196036	90760985784
    
    4495	20205025	90821587375
    
    4496	20214016	90882215936
    
    4497	20223009	90942871473
    
    4498	20232004	91003553992
    
    4499	20241001	91064263499
    
    4500	20250000	91125000000
    
    4501	20259001	91185763501
    
    4502	20268004	91246554008
    
    4503	20277009	91307371527
    
    4504	20286016	91368216064
    
    4505	20295025	91429087625
    
    4506	20304036	91489986216
    
    4507	20313049	91550911843
    
    4508	20322064	91611864512
    
    4509	20331081	91672844229
    
    4510	20340100	91733851000
    
    4511	20349121	91794884831
    
    4512	20358144	91855945728
    
    4513	20367169	91917033697
    
    4514	20376196	91978148744
    
    4515	20385225	92039290875
    
    4516	20394256	92100460096
    
    4517	20403289	92161656413
    
    4518	20412324	92222879832
    
    4519	20421361	92284130359
    
    4520	20430400	92345408000
    
    4521	20439441	92406712761
    
    4522	20448484	92468044648
    
    4523	20457529	92529403667
    
    4524	20466576	92590789824
    
    4525	20475625	92652203125
    
    4526	20484676	92713643576
    
    4527	20493729	92775111183
    
    4528	20502784	92836605952
    
    4529	20511841	92898127889
    
    4530	20520900	92959677000
    
    4531	20529961	93021253291
    
    4532	20539024	93082856768
    
    4533	20548089	93144487437
    
    4534	20557156	93206145304
    
    4535	20566225	93267830375
    
    4536	20575296	93329542656
    
    4537	20584369	93391282153
    
    4538	20593444	93453048872
    
    4539	20602521	93514842819
    
    4540	20611600	93576664000
    
    4541	20620681	93638512421
    
    4542	20629764	93700388088
    
    4543	20638849	93762291007
    
    4544	20647936	93824221184
    
    4545	20657025	93886178625
    
    4546	20666116	93948163336
    
    4547	20675209	94010175323
    
    4548	20684304	94072214592
    
    4549	20693401	94134281149
    
    4550	20702500	94196375000
    
    4551	20711601	94258496151
    
    4552	20720704	94320644608
    
    4553	20729809	94382820377
    
    4554	20738916	94445023464
    
    4555	20748025	94507253875
    
    4556	20757136	94569511616
    
    4557	20766249	94631796693
    
    4558	20775364	94694109112
    
    4559	20784481	94756448879
    
    4560	20793600	94818816000
    
    4561	20802721	94881210481
    
    4562	20811844	94943632328
    
    4563	20820969	95006081547
    
    4564	20830096	95068558144
    
    4565	20839225	95131062125
    
    4566	20848356	95193593496
    
    4567	20857489	95256152263
    
    4568	20866624	95318738432
    
    4569	20875761	95381352009
    
    4570	20884900	95443993000
    
    4571	20894041	95506661411
    
    4572	20903184	95569357248
    
    4573	20912329	95632080517
    
    4574	20921476	95694831224
    
    4575	20930625	95757609375
    
    4576	20939776	95820414976
    
    4577	20948929	95883248033
    
    4578	20958084	95946108552
    
    4579	20967241	96008996539
    
    4580	20976400	96071912000
    
    4581	20985561	96134854941
    
    4582	20994724	96197825368
    
    4583	21003889	96260823287
    
    4584	21013056	96323848704
    
    4585	21022225	96386901625
    
    4586	21031396	96449982056
    
    4587	21040569	96513090003
    
    4588	21049744	96576225472
    
    4589	21058921	96639388469
    
    4590	21068100	96702579000
    
    4591	21077281	96765797071
    
    4592	21086464	96829042688
    
    4593	21095649	96892315857
    
    4594	21104836	96955616584
    
    4595	21114025	97018944875
    
    4596	21123216	97082300736
    
    4597	21132409	97145684173
    
    4598	21141604	97209095192
    
    4599	21150801	97272533799
    
    4600	21160000	97336000000
    
    4601	21169201	97399493801
    
    4602	21178404	97463015208
    
    4603	21187609	97526564227
    
    4604	21196816	97590140864
    
    4605	21206025	97653745125
    
    4606	21215236	97717377016
    
    4607	21224449	97781036543
    
    4608	21233664	97844723712
    
    4609	21242881	97908438529
    
    4610	21252100	97972181000
    
    4611	21261321	98035951131
    
    4612	21270544	98099748928
    
    4613	21279769	98163574397
    
    4614	21288996	98227427544
    
    4615	21298225	98291308375
    
    4616	21307456	98355216896
    
    4617	21316689	98419153113
    
    4618	21325924	98483117032
    
    4619	21335161	98547108659
    
    4620	21344400	98611128000
    
    4621	21353641	98675175061
    
    4622	21362884	98739249848
    
    4623	21372129	98803352367
    
    4624	21381376	98867482624
    
    4625	21390625	98931640625
    
    4626	21399876	98995826376
    
    4627	21409129	99060039883
    
    4628	21418384	99124281152
    
    4629	21427641	99188550189
    
    4630	21436900	99252847000
    
    4631	21446161	99317171591
    
    4632	21455424	99381523968
    
    4633	21464689	99445904137
    
    4634	21473956	99510312104
    
    4635	21483225	99574747875
    
    4636	21492496	99639211456
    
    4637	21501769	99703702853
    
    4638	21511044	99768222072
    
    4639	21520321	99832769119
    
    4640	21529600	99897344000
    
    4641	21538881	99961946721
    
    4642	21548164	100026577288
    
    4643	21557449	100091235707
    
    4644	21566736	100155921984
    
    4645	21576025	100220636125
    
    4646	21585316	100285378136
    
    4647	21594609	100350148023
    
    4648	21603904	100414945792
    
    4649	21613201	100479771449
    
    4650	21622500	100544625000
    
    4651	21631801	100609506451
    
    4652	21641104	100674415808
    
    4653	21650409	100739353077
    
    4654	21659716	100804318264
    
    4655	21669025	100869311375
    
    4656	21678336	100934332416
    
    4657	21687649	100999381393
    
    4658	21696964	101064458312
    
    4659	21706281	101129563179
    
    4660	21715600	101194696000
    
    4661	21724921	101259856781
    
    4662	21734244	101325045528
    
    4663	21743569	101390262247
    
    4664	21752896	101455506944
    
    4665	21762225	101520779625
    
    4666	21771556	101586080296
    
    4667	21780889	101651408963
    
    4668	21790224	101716765632
    
    4669	21799561	101782150309
    
    4670	21808900	101847563000
    
    4671	21818241	101913003711
    
    4672	21827584	101978472448
    
    4673	21836929	102043969217
    
    4674	21846276	102109494024
    
    4675	21855625	102175046875
    
    4676	21864976	102240627776
    
    4677	21874329	102306236733
    
    4678	21883684	102371873752
    
    4679	21893041	102437538839
    
    4680	21902400	102503232000
    
    4681	21911761	102568953241
    
    4682	21921124	102634702568
    
    4683	21930489	102700479987
    
    4684	21939856	102766285504
    
    4685	21949225	102832119125
    
    4686	21958596	102897980856
    
    4687	21967969	102963870703
    
    4688	21977344	103029788672
    
    4689	21986721	103095734769
    
    4690	21996100	103161709000
    
    4691	22005481	103227711371
    
    4692	22014864	103293741888
    
    4693	22024249	103359800557
    
    4694	22033636	103425887384
    
    4695	22043025	103492002375
    
    4696	22052416	103558145536
    
    4697	22061809	103624316873
    
    4698	22071204	103690516392
    
    4699	22080601	103756744099
    
    4700	22090000	103823000000
    
    4701	22099401	103889284101
    
    4702	22108804	103955596408
    
    4703	22118209	104021936927
    
    4704	22127616	104088305664
    
    4705	22137025	104154702625
    
    4706	22146436	104221127816
    
    4707	22155849	104287581243
    
    4708	22165264	104354062912
    
    4709	22174681	104420572829
    
    4710	22184100	104487111000
    
    4711	22193521	104553677431
    
    4712	22202944	104620272128
    
    4713	22212369	104686895097
    
    4714	22221796	104753546344
    
    4715	22231225	104820225875
    
    4716	22240656	104886933696
    
    4717	22250089	104953669813
    
    4718	22259524	105020434232
    
    4719	22268961	105087226959
    
    4720	22278400	105154048000
    
    4721	22287841	105220897361
    
    4722	22297284	105287775048
    
    4723	22306729	105354681067
    
    4724	22316176	105421615424
    
    4725	22325625	105488578125
    
    4726	22335076	105555569176
    
    4727	22344529	105622588583
    
    4728	22353984	105689636352
    
    4729	22363441	105756712489
    
    4730	22372900	105823817000
    
    4731	22382361	105890949891
    
    4732	22391824	105958111168
    
    4733	22401289	106025300837
    
    4734	22410756	106092518904
    
    4735	22420225	106159765375
    
    4736	22429696	106227040256
    
    4737	22439169	106294343553
    
    4738	22448644	106361675272
    
    4739	22458121	106429035419
    
    4740	22467600	106496424000
    
    4741	22477081	106563841021
    
    4742	22486564	106631286488
    
    4743	22496049	106698760407
    
    4744	22505536	106766262784
    
    4745	22515025	106833793625
    
    4746	22524516	106901352936
    
    4747	22534009	106968940723
    
    4748	22543504	107036556992
    
    4749	22553001	107104201749
    
    4750	22562500	107171875000
    
    4751	22572001	107239576751
    
    4752	22581504	107307307008
    
    4753	22591009	107375065777
    
    4754	22600516	107442853064
    
    4755	22610025	107510668875
    
    4756	22619536	107578513216
    
    4757	22629049	107646386093
    
    4758	22638564	107714287512
    
    4759	22648081	107782217479
    
    4760	22657600	107850176000
    
    4761	22667121	107918163081
    
    4762	22676644	107986178728
    
    4763	22686169	108054222947
    
    4764	22695696	108122295744
    
    4765	22705225	108190397125
    
    4766	22714756	108258527096
    
    4767	22724289	108326685663
    
    4768	22733824	108394872832
    
    4769	22743361	108463088609
    
    4770	22752900	108531333000
    
    4771	22762441	108599606011
    
    4772	22771984	108667907648
    
    4773	22781529	108736237917
    
    4774	22791076	108804596824
    
    4775	22800625	108872984375
    
    4776	22810176	108941400576
    
    4777	22819729	109009845433
    
    4778	22829284	109078318952
    
    4779	22838841	109146821139
    
    4780	22848400	109215352000
    
    4781	22857961	109283911541
    
    4782	22867524	109352499768
    
    4783	22877089	109421116687
    
    4784	22886656	109489762304
    
    4785	22896225	109558436625
    
    4786	22905796	109627139656
    
    4787	22915369	109695871403
    
    4788	22924944	109764631872
    
    4789	22934521	109833421069
    
    4790	22944100	109902239000
    
    4791	22953681	109971085671
    
    4792	22963264	110039961088
    
    4793	22972849	110108865257
    
    4794	22982436	110177798184
    
    4795	22992025	110246759875
    
    4796	23001616	110315750336
    
    4797	23011209	110384769573
    
    4798	23020804	110453817592
    
    4799	23030401	110522894399
    
    4800	23040000	110592000000
    
    4801	23049601	110661134401
    
    4802	23059204	110730297608
    
    4803	23068809	110799489627
    
    4804	23078416	110868710464
    
    4805	23088025	110937960125
    
    4806	23097636	111007238616
    
    4807	23107249	111076545943
    
    4808	23116864	111145882112
    
    4809	23126481	111215247129
    
    4810	23136100	111284641000
    
    4811	23145721	111354063731
    
    4812	23155344	111423515328
    
    4813	23164969	111492995797
    
    4814	23174596	111562505144
    
    4815	23184225	111632043375
    
    4816	23193856	111701610496
    
    4817	23203489	111771206513
    
    4818	23213124	111840831432
    
    4819	23222761	111910485259
    
    4820	23232400	111980168000
    
    4821	23242041	112049879661
    
    4822	23251684	112119620248
    
    4823	23261329	112189389767
    
    4824	23270976	112259188224
    
    4825	23280625	112329015625
    
    4826	23290276	112398871976
    
    4827	23299929	112468757283
    
    4828	23309584	112538671552
    
    4829	23319241	112608614789
    
    4830	23328900	112678587000
    
    4831	23338561	112748588191
    
    4832	23348224	112818618368
    
    4833	23357889	112888677537
    
    4834	23367556	112958765704
    
    4835	23377225	113028882875
    
    4836	23386896	113099029056
    
    4837	23396569	113169204253
    
    4838	23406244	113239408472
    
    4839	23415921	113309641719
    
    4840	23425600	113379904000
    
    4841	23435281	113450195321
    
    4842	23444964	113520515688
    
    4843	23454649	113590865107
    
    4844	23464336	113661243584
    
    4845	23474025	113731651125
    
    4846	23483716	113802087736
    
    4847	23493409	113872553423
    
    4848	23503104	113943048192
    
    4849	23512801	114013572049
    
    4850	23522500	114084125000
    
    4851	23532201	114154707051
    
    4852	23541904	114225318208
    
    4853	23551609	114295958477
    
    4854	23561316	114366627864
    
    4855	23571025	114437326375
    
    4856	23580736	114508054016
    
    4857	23590449	114578810793
    
    4858	23600164	114649596712
    
    4859	23609881	114720411779
    
    4860	23619600	114791256000
    
    4861	23629321	114862129381
    
    4862	23639044	114933031928
    
    4863	23648769	115003963647
    
    4864	23658496	115074924544
    
    4865	23668225	115145914625
    
    4866	23677956	115216933896
    
    4867	23687689	115287982363
    
    4868	23697424	115359060032
    
    4869	23707161	115430166909
    
    4870	23716900	115501303000
    
    4871	23726641	115572468311
    
    4872	23736384	115643662848
    
    4873	23746129	115714886617
    
    4874	23755876	115786139624
    
    4875	23765625	115857421875
    
    4876	23775376	115928733376
    
    4877	23785129	116000074133
    
    4878	23794884	116071444152
    
    4879	23804641	116142843439
    
    4880	23814400	116214272000
    
    4881	23824161	116285729841
    
    4882	23833924	116357216968
    
    4883	23843689	116428733387
    
    4884	23853456	116500279104
    
    4885	23863225	116571854125
    
    4886	23872996	116643458456
    
    4887	23882769	116715092103
    
    4888	23892544	116786755072
    
    4889	23902321	116858447369
    
    4890	23912100	116930169000
    
    4891	23921881	117001919971
    
    4892	23931664	117073700288
    
    4893	23941449	117145509957
    
    4894	23951236	117217348984
    
    4895	23961025	117289217375
    
    4896	23970816	117361115136
    
    4897	23980609	117433042273
    
    4898	23990404	117504998792
    
    4899	24000201	117576984699
    
    4900	24010000	117649000000
    
    4901	24019801	117721044701
    
    4902	24029604	117793118808
    
    4903	24039409	117865222327
    
    4904	24049216	117937355264
    
    4905	24059025	118009517625
    
    4906	24068836	118081709416
    
    4907	24078649	118153930643
    
    4908	24088464	118226181312
    
    4909	24098281	118298461429
    
    4910	24108100	118370771000
    
    4911	24117921	118443110031
    
    4912	24127744	118515478528
    
    4913	24137569	118587876497
    
    4914	24147396	118660303944
    
    4915	24157225	118732760875
    
    4916	24167056	118805247296
    
    4917	24176889	118877763213
    
    4918	24186724	118950308632
    
    4919	24196561	119022883559
    
    4920	24206400	119095488000
    
    4921	24216241	119168121961
    
    4922	24226084	119240785448
    
    4923	24235929	119313478467
    
    4924	24245776	119386201024
    
    4925	24255625	119458953125
    
    4926	24265476	119531734776
    
    4927	24275329	119604545983
    
    4928	24285184	119677386752
    
    4929	24295041	119750257089
    
    4930	24304900	119823157000
    
    4931	24314761	119896086491
    
    4932	24324624	119969045568
    
    4933	24334489	120042034237
    
    4934	24344356	120115052504
    
    4935	24354225	120188100375
    
    4936	24364096	120261177856
    
    4937	24373969	120334284953
    
    4938	24383844	120407421672
    
    4939	24393721	120480588019
    
    4940	24403600	120553784000
    
    4941	24413481	120627009621
    
    4942	24423364	120700264888
    
    4943	24433249	120773549807
    
    4944	24443136	120846864384
    
    4945	24453025	120920208625
    
    4946	24462916	120993582536
    
    4947	24472809	121066986123
    
    4948	24482704	121140419392
    
    4949	24492601	121213882349
    
    4950	24502500	121287375000
    
    4951	24512401	121360897351
    
    4952	24522304	121434449408
    
    4953	24532209	121508031177
    
    4954	24542116	121581642664
    
    4955	24552025	121655283875
    
    4956	24561936	121728954816
    
    4957	24571849	121802655493
    
    4958	24581764	121876385912
    
    4959	24591681	121950146079
    
    4960	24601600	122023936000
    
    4961	24611521	122097755681
    
    4962	24621444	122171605128
    
    4963	24631369	122245484347
    
    4964	24641296	122319393344
    
    4965	24651225	122393332125
    
    4966	24661156	122467300696
    
    4967	24671089	122541299063
    
    4968	24681024	122615327232
    
    4969	24690961	122689385209
    
    4970	24700900	122763473000
    
    4971	24710841	122837590611
    
    4972	24720784	122911738048
    
    4973	24730729	122985915317
    
    4974	24740676	123060122424
    
    4975	24750625	123134359375
    
    4976	24760576	123208626176
    
    4977	24770529	123282922833
    
    4978	24780484	123357249352
    
    4979	24790441	123431605739
    
    4980	24800400	123505992000
    
    4981	24810361	123580408141
    
    4982	24820324	123654854168
    
    4983	24830289	123729330087
    
    4984	24840256	123803835904
    
    4985	24850225	123878371625
    
    4986	24860196	123952937256
    
    4987	24870169	124027532803
    
    4988	24880144	124102158272
    
    4989	24890121	124176813669
    
    4990	24900100	124251499000
    
    4991	24910081	124326214271
    
    4992	24920064	124400959488
    
    4993	24930049	124475734657
    
    4994	24940036	124550539784
    
    4995	24950025	124625374875
    
    4996	24960016	124700239936
    
    4997	24970009	124775134973
    
    4998	24980004	124850059992
    
    4999	24990001	124925014999
    
    5000	25000000	125000000000
    
    5001	25010001	125075015001
    
    5002	25020004	125150060008
    
    5003	25030009	125225135027
    
    5004	25040016	125300240064
    
    5005	25050025	125375375125
    
    5006	25060036	125450540216
    
    5007	25070049	125525735343
    
    5008	25080064	125600960512
    
    5009	25090081	125676215729
    
    5010	25100100	125751501000
    
    5011	25110121	125826816331
    
    5012	25120144	125902161728
    
    5013	25130169	125977537197
    
    5014	25140196	126052942744
    
    5015	25150225	126128378375
    
    5016	25160256	126203844096
    
    5017	25170289	126279339913
    
    5018	25180324	126354865832
    
    5019	25190361	126430421859
    
    5020	25200400	126506008000
    
    5021	25210441	126581624261
    
    5022	25220484	126657270648
    
    5023	25230529	126732947167
    
    5024	25240576	126808653824
    
    5025	25250625	126884390625
    
    5026	25260676	126960157576
    
    5027	25270729	127035954683
    
    5028	25280784	127111781952
    
    5029	25290841	127187639389
    
    5030	25300900	127263527000
    
    5031	25310961	127339444791
    
    5032	25321024	127415392768
    
    5033	25331089	127491370937
    
    5034	25341156	127567379304
    
    5035	25351225	127643417875
    
    5036	25361296	127719486656
    
    5037	25371369	127795585653
    
    5038	25381444	127871714872
    
    5039	25391521	127947874319
    
    5040	25401600	128024064000
    
    5041	25411681	128100283921
    
    5042	25421764	128176534088
    
    5043	25431849	128252814507
    
    5044	25441936	128329125184
    
    5045	25452025	128405466125
    
    5046	25462116	128481837336
    
    5047	25472209	128558238823
    
    5048	25482304	128634670592
    
    5049	25492401	128711132649
    
    5050	25502500	128787625000
    
    5051	25512601	128864147651
    
    5052	25522704	128940700608
    
    5053	25532809	129017283877
    
    5054	25542916	129093897464
    
    5055	25553025	129170541375
    
    5056	25563136	129247215616
    
    5057	25573249	129323920193
    
    5058	25583364	129400655112
    
    5059	25593481	129477420379
    
    5060	25603600	129554216000
    
    5061	25613721	129631041981
    
    5062	25623844	129707898328
    
    5063	25633969	129784785047
    
    5064	25644096	129861702144
    
    5065	25654225	129938649625
    
    5066	25664356	130015627496
    
    5067	25674489	130092635763
    
    5068	25684624	130169674432
    
    5069	25694761	130246743509
    
    5070	25704900	130323843000
    
    5071	25715041	130400972911
    
    5072	25725184	130478133248
    
    5073	25735329	130555324017
    
    5074	25745476	130632545224
    
    5075	25755625	130709796875
    
    5076	25765776	130787078976
    
    5077	25775929	130864391533
    
    5078	25786084	130941734552
    
    5079	25796241	131019108039
    
    5080	25806400	131096512000
    
    5081	25816561	131173946441
    
    5082	25826724	131251411368
    
    5083	25836889	131328906787
    
    5084	25847056	131406432704
    
    5085	25857225	131483989125
    
    5086	25867396	131561576056
    
    5087	25877569	131639193503
    
    5088	25887744	131716841472
    
    5089	25897921	131794519969
    
    5090	25908100	131872229000
    
    5091	25918281	131949968571
    
    5092	25928464	132027738688
    
    5093	25938649	132105539357
    
    5094	25948836	132183370584
    
    5095	25959025	132261232375
    
    5096	25969216	132339124736
    
    5097	25979409	132417047673
    
    5098	25989604	132495001192
    
    5099	25999801	132572985299
    
    5100	26010000	132651000000
    
    5101	26020201	132729045301
    
    5102	26030404	132807121208
    
    5103	26040609	132885227727
    
    5104	26050816	132963364864
    
    5105	26061025	133041532625
    
    5106	26071236	133119731016
    
    5107	26081449	133197960043
    
    5108	26091664	133276219712
    
    5109	26101881	133354510029
    
    5110	26112100	133432831000
    
    5111	26122321	133511182631
    
    5112	26132544	133589564928
    
    5113	26142769	133667977897
    
    5114	26152996	133746421544
    
    5115	26163225	133824895875
    
    5116	26173456	133903400896
    
    5117	26183689	133981936613
    
    5118	26193924	134060503032
    
    5119	26204161	134139100159
    
    5120	26214400	134217728000
    
    5121	26224641	134296386561
    
    5122	26234884	134375075848
    
    5123	26245129	134453795867
    
    5124	26255376	134532546624
    
    5125	26265625	134611328125
    
    5126	26275876	134690140376
    
    5127	26286129	134768983383
    
    5128	26296384	134847857152
    
    5129	26306641	134926761689
    
    5130	26316900	135005697000
    
    5131	26327161	135084663091
    
    5132	26337424	135163659968
    
    5133	26347689	135242687637
    
    5134	26357956	135321746104
    
    5135	26368225	135400835375
    
    5136	26378496	135479955456
    
    5137	26388769	135559106353
    
    5138	26399044	135638288072
    
    5139	26409321	135717500619
    
    5140	26419600	135796744000
    
    5141	26429881	135876018221
    
    5142	26440164	135955323288
    
    5143	26450449	136034659207
    
    5144	26460736	136114025984
    
    5145	26471025	136193423625
    
    5146	26481316	136272852136
    
    5147	26491609	136352311523
    
    5148	26501904	136431801792
    
    5149	26512201	136511322949
    
    5150	26522500	136590875000
    
    5151	26532801	136670457951
    
    5152	26543104	136750071808
    
    5153	26553409	136829716577
    
    5154	26563716	136909392264
    
    5155	26574025	136989098875
    
    5156	26584336	137068836416
    
    5157	26594649	137148604893
    
    5158	26604964	137228404312
    
    5159	26615281	137308234679
    
    5160	26625600	137388096000
    
    5161	26635921	137467988281
    
    5162	26646244	137547911528
    
    5163	26656569	137627865747
    
    5164	26666896	137707850944
    
    5165	26677225	137787867125
    
    5166	26687556	137867914296
    
    5167	26697889	137947992463
    
    5168	26708224	138028101632
    
    5169	26718561	138108241809
    
    5170	26728900	138188413000
    
    5171	26739241	138268615211
    
    5172	26749584	138348848448
    
    5173	26759929	138429112717
    
    5174	26770276	138509408024
    
    5175	26780625	138589734375
    
    5176	26790976	138670091776
    
    5177	26801329	138750480233
    
    5178	26811684	138830899752
    
    5179	26822041	138911350339
    
    5180	26832400	138991832000
    
    5181	26842761	139072344741
    
    5182	26853124	139152888568
    
    5183	26863489	139233463487
    
    5184	26873856	139314069504
    
    5185	26884225	139394706625
    
    5186	26894596	139475374856
    
    5187	26904969	139556074203
    
    5188	26915344	139636804672
    
    5189	26925721	139717566269
    
    5190	26936100	139798359000
    
    5191	26946481	139879182871
    
    5192	26956864	139960037888
    
    5193	26967249	140040924057
    
    5194	26977636	140121841384
    
    5195	26988025	140202789875
    
    5196	26998416	140283769536
    
    5197	27008809	140364780373
    
    5198	27019204	140445822392
    
    5199	27029601	140526895599
    
    5200	27040000	140608000000
    
    5201	27050401	140689135601
    
    5202	27060804	140770302408
    
    5203	27071209	140851500427
    
    5204	27081616	140932729664
    
    5205	27092025	141013990125
    
    5206	27102436	141095281816
    
    5207	27112849	141176604743
    
    5208	27123264	141257958912
    
    5209	27133681	141339344329
    
    5210	27144100	141420761000
    
    5211	27154521	141502208931
    
    5212	27164944	141583688128
    
    5213	27175369	141665198597
    
    5214	27185796	141746740344
    
    5215	27196225	141828313375
    
    5216	27206656	141909917696
    
    5217	27217089	141991553313
    
    5218	27227524	142073220232
    
    5219	27237961	142154918459
    
    5220	27248400	142236648000
    
    5221	27258841	142318408861
    
    5222	27269284	142400201048
    
    5223	27279729	142482024567
    
    5224	27290176	142563879424
    
    5225	27300625	142645765625
    
    5226	27311076	142727683176
    
    5227	27321529	142809632083
    
    5228	27331984	142891612352
    
    5229	27342441	142973623989
    
    5230	27352900	143055667000
    
    5231	27363361	143137741391
    
    5232	27373824	143219847168
    
    5233	27384289	143301984337
    
    5234	27394756	143384152904
    
    5235	27405225	143466352875
    
    5236	27415696	143548584256
    
    5237	27426169	143630847053
    
    5238	27436644	143713141272
    
    5239	27447121	143795466919
    
    5240	27457600	143877824000
    
    5241	27468081	143960212521
    
    5242	27478564	144042632488
    
    5243	27489049	144125083907
    
    5244	27499536	144207566784
    
    5245	27510025	144290081125
    
    5246	27520516	144372626936
    
    5247	27531009	144455204223
    
    5248	27541504	144537812992
    
    5249	27552001	144620453249
    
    5250	27562500	144703125000
    
    5251	27573001	144785828251
    
    5252	27583504	144868563008
    
    5253	27594009	144951329277
    
    5254	27604516	145034127064
    
    5255	27615025	145116956375
    
    5256	27625536	145199817216
    
    5257	27636049	145282709593
    
    5258	27646564	145365633512
    
    5259	27657081	145448588979
    
    5260	27667600	145531576000
    
    5261	27678121	145614594581
    
    5262	27688644	145697644728
    
    5263	27699169	145780726447
    
    5264	27709696	145863839744
    
    5265	27720225	145946984625
    
    5266	27730756	146030161096
    
    5267	27741289	146113369163
    
    5268	27751824	146196608832
    
    5269	27762361	146279880109
    
    5270	27772900	146363183000
    
    5271	27783441	146446517511
    
    5272	27793984	146529883648
    
    5273	27804529	146613281417
    
    5274	27815076	146696710824
    
    5275	27825625	146780171875
    
    5276	27836176	146863664576
    
    5277	27846729	146947188933
    
    5278	27857284	147030744952
    
    5279	27867841	147114332639
    
    5280	27878400	147197952000
    
    5281	27888961	147281603041
    
    5282	27899524	147365285768
    
    5283	27910089	147449000187
    
    5284	27920656	147532746304
    
    5285	27931225	147616524125
    
    5286	27941796	147700333656
    
    5287	27952369	147784174903
    
    5288	27962944	147868047872
    
    5289	27973521	147951952569
    
    5290	27984100	148035889000
    
    5291	27994681	148119857171
    
    5292	28005264	148203857088
    
    5293	28015849	148287888757
    
    5294	28026436	148371952184
    
    5295	28037025	148456047375
    
    5296	28047616	148540174336
    
    5297	28058209	148624333073
    
    5298	28068804	148708523592
    
    5299	28079401	148792745899
    
    5300	28090000	148877000000
    
    5301	28100601	148961285901
    
    5302	28111204	149045603608
    
    5303	28121809	149129953127
    
    5304	28132416	149214334464
    
    5305	28143025	149298747625
    
    5306	28153636	149383192616
    
    5307	28164249	149467669443
    
    5308	28174864	149552178112
    
    5309	28185481	149636718629
    
    5310	28196100	149721291000
    
    5311	28206721	149805895231
    
    5312	28217344	149890531328
    
    5313	28227969	149975199297
    
    5314	28238596	150059899144
    
    5315	28249225	150144630875
    
    5316	28259856	150229394496
    
    5317	28270489	150314190013
    
    5318	28281124	150399017432
    
    5319	28291761	150483876759
    
    5320	28302400	150568768000
    
    5321	28313041	150653691161
    
    5322	28323684	150738646248
    
    5323	28334329	150823633267
    
    5324	28344976	150908652224
    
    5325	28355625	150993703125
    
    5326	28366276	151078785976
    
    5327	28376929	151163900783
    
    5328	28387584	151249047552
    
    5329	28398241	151334226289
    
    5330	28408900	151419437000
    
    5331	28419561	151504679691
    
    5332	28430224	151589954368
    
    5333	28440889	151675261037
    
    5334	28451556	151760599704
    
    5335	28462225	151845970375
    
    5336	28472896	151931373056
    
    5337	28483569	152016807753
    
    5338	28494244	152102274472
    
    5339	28504921	152187773219
    
    5340	28515600	152273304000
    
    5341	28526281	152358866821
    
    5342	28536964	152444461688
    
    5343	28547649	152530088607
    
    5344	28558336	152615747584
    
    5345	28569025	152701438625
    
    5346	28579716	152787161736
    
    5347	28590409	152872916923
    
    5348	28601104	152958704192
    
    5349	28611801	153044523549
    
    5350	28622500	153130375000
    
    5351	28633201	153216258551
    
    5352	28643904	153302174208
    
    5353	28654609	153388121977
    
    5354	28665316	153474101864
    
    5355	28676025	153560113875
    
    5356	28686736	153646158016
    
    5357	28697449	153732234293
    
    5358	28708164	153818342712
    
    5359	28718881	153904483279
    
    5360	28729600	153990656000
    
    5361	28740321	154076860881
    
    5362	28751044	154163097928
    
    5363	28761769	154249367147
    
    5364	28772496	154335668544
    
    5365	28783225	154422002125
    
    5366	28793956	154508367896
    
    5367	28804689	154594765863
    
    5368	28815424	154681196032
    
    5369	28826161	154767658409
    
    5370	28836900	154854153000
    
    5371	28847641	154940679811
    
    5372	28858384	155027238848
    
    5373	28869129	155113830117
    
    5374	28879876	155200453624
    
    5375	28890625	155287109375
    
    5376	28901376	155373797376
    
    5377	28912129	155460517633
    
    5378	28922884	155547270152
    
    5379	28933641	155634054939
    
    5380	28944400	155720872000
    
    5381	28955161	155807721341
    
    5382	28965924	155894602968
    
    5383	28976689	155981516887
    
    5384	28987456	156068463104
    
    5385	28998225	156155441625
    
    5386	29008996	156242452456
    
    5387	29019769	156329495603
    
    5388	29030544	156416571072
    
    5389	29041321	156503678869
    
    5390	29052100	156590819000
    
    5391	29062881	156677991471
    
    5392	29073664	156765196288
    
    5393	29084449	156852433457
    
    5394	29095236	156939702984
    
    5395	29106025	157027004875
    
    5396	29116816	157114339136
    
    5397	29127609	157201705773
    
    5398	29138404	157289104792
    
    5399	29149201	157376536199
    
    5400	29160000	157464000000
    
    5401	29170801	157551496201
    
    5402	29181604	157639024808
    
    5403	29192409	157726585827
    
    5404	29203216	157814179264
    
    5405	29214025	157901805125
    
    5406	29224836	157989463416
    
    5407	29235649	158077154143
    
    5408	29246464	158164877312
    
    5409	29257281	158252632929
    
    5410	29268100	158340421000
    
    5411	29278921	158428241531
    
    5412	29289744	158516094528
    
    5413	29300569	158603979997
    
    5414	29311396	158691897944
    
    5415	29322225	158779848375
    
    5416	29333056	158867831296
    
    5417	29343889	158955846713
    
    5418	29354724	159043894632
    
    5419	29365561	159131975059
    
    5420	29376400	159220088000
    
    5421	29387241	159308233461
    
    5422	29398084	159396411448
    
    5423	29408929	159484621967
    
    5424	29419776	159572865024
    
    5425	29430625	159661140625
    
    5426	29441476	159749448776
    
    5427	29452329	159837789483
    
    5428	29463184	159926162752
    
    5429	29474041	160014568589
    
    5430	29484900	160103007000
    
    5431	29495761	160191477991
    
    5432	29506624	160279981568
    
    5433	29517489	160368517737
    
    5434	29528356	160457086504
    
    5435	29539225	160545687875
    
    5436	29550096	160634321856
    
    5437	29560969	160722988453
    
    5438	29571844	160811687672
    
    5439	29582721	160900419519
    
    5440	29593600	160989184000
    
    5441	29604481	161077981121
    
    5442	29615364	161166810888
    
    5443	29626249	161255673307
    
    5444	29637136	161344568384
    
    5445	29648025	161433496125
    
    5446	29658916	161522456536
    
    5447	29669809	161611449623
    
    5448	29680704	161700475392
    
    5449	29691601	161789533849
    
    5450	29702500	161878625000
    
    5451	29713401	161967748851
    
    5452	29724304	162056905408
    
    5453	29735209	162146094677
    
    5454	29746116	162235316664
    
    5455	29757025	162324571375
    
    5456	29767936	162413858816
    
    5457	29778849	162503178993
    
    5458	29789764	162592531912
    
    5459	29800681	162681917579
    
    5460	29811600	162771336000
    
    5461	29822521	162860787181
    
    5462	29833444	162950271128
    
    5463	29844369	163039787847
    
    5464	29855296	163129337344
    
    5465	29866225	163218919625
    
    5466	29877156	163308534696
    
    5467	29888089	163398182563
    
    5468	29899024	163487863232
    
    5469	29909961	163577576709
    
    5470	29920900	163667323000
    
    5471	29931841	163757102111
    
    5472	29942784	163846914048
    
    5473	29953729	163936758817
    
    5474	29964676	164026636424
    
    5475	29975625	164116546875
    
    5476	29986576	164206490176
    
    5477	29997529	164296466333
    
    5478	30008484	164386475352
    
    5479	30019441	164476517239
    
    5480	30030400	164566592000
    
    5481	30041361	164656699641
    
    5482	30052324	164746840168
    
    5483	30063289	164837013587
    
    5484	30074256	164927219904
    
    5485	30085225	165017459125
    
    5486	30096196	165107731256
    
    5487	30107169	165198036303
    
    5488	30118144	165288374272
    
    5489	30129121	165378745169
    
    5490	30140100	165469149000
    
    5491	30151081	165559585771
    
    5492	30162064	165650055488
    
    5493	30173049	165740558157
    
    5494	30184036	165831093784
    
    5495	30195025	165921662375
    
    5496	30206016	166012263936
    
    5497	30217009	166102898473
    
    5498	30228004	166193565992
    
    5499	30239001	166284266499
    
    5500	30250000	166375000000
    
    5501	30261001	166465766501
    
    5502	30272004	166556566008
    
    5503	30283009	166647398527
    
    5504	30294016	166738264064
    
    5505	30305025	166829162625
    
    5506	30316036	166920094216
    
    5507	30327049	167011058843
    
    5508	30338064	167102056512
    
    5509	30349081	167193087229
    
    5510	30360100	167284151000
    
    5511	30371121	167375247831
    
    5512	30382144	167466377728
    
    5513	30393169	167557540697
    
    5514	30404196	167648736744
    
    5515	30415225	167739965875
    
    5516	30426256	167831228096
    
    5517	30437289	167922523413
    
    5518	30448324	168013851832
    
    5519	30459361	168105213359
    
    5520	30470400	168196608000
    
    5521	30481441	168288035761
    
    5522	30492484	168379496648
    
    5523	30503529	168470990667
    
    5524	30514576	168562517824
    
    5525	30525625	168654078125
    
    5526	30536676	168745671576
    
    5527	30547729	168837298183
    
    5528	30558784	168928957952
    
    5529	30569841	169020650889
    
    5530	30580900	169112377000
    
    5531	30591961	169204136291
    
    5532	30603024	169295928768
    
    5533	30614089	169387754437
    
    5534	30625156	169479613304
    
    5535	30636225	169571505375
    
    5536	30647296	169663430656
    
    5537	30658369	169755389153
    
    5538	30669444	169847380872
    
    5539	30680521	169939405819
    
    5540	30691600	170031464000
    
    5541	30702681	170123555421
    
    5542	30713764	170215680088
    
    5543	30724849	170307838007
    
    5544	30735936	170400029184
    
    5545	30747025	170492253625
    
    5546	30758116	170584511336
    
    5547	30769209	170676802323
    
    5548	30780304	170769126592
    
    5549	30791401	170861484149
    
    5550	30802500	170953875000
    
    5551	30813601	171046299151
    
    5552	30824704	171138756608
    
    5553	30835809	171231247377
    
    5554	30846916	171323771464
    
    5555	30858025	171416328875
    
    5556	30869136	171508919616
    
    5557	30880249	171601543693
    
    5558	30891364	171694201112
    
    5559	30902481	171786891879
    
    5560	30913600	171879616000
    
    5561	30924721	171972373481
    
    5562	30935844	172065164328
    
    5563	30946969	172157988547
    
    5564	30958096	172250846144
    
    5565	30969225	172343737125
    
    5566	30980356	172436661496
    
    5567	30991489	172529619263
    
    5568	31002624	172622610432
    
    5569	31013761	172715635009
    
    5570	31024900	172808693000
    
    5571	31036041	172901784411
    
    5572	31047184	172994909248
    
    5573	31058329	173088067517
    
    5574	31069476	173181259224
    
    5575	31080625	173274484375
    
    5576	31091776	173367742976
    
    5577	31102929	173461035033
    
    5578	31114084	173554360552
    
    5579	31125241	173647719539
    
    5580	31136400	173741112000
    
    5581	31147561	173834537941
    
    5582	31158724	173927997368
    
    5583	31169889	174021490287
    
    5584	31181056	174115016704
    
    5585	31192225	174208576625
    
    5586	31203396	174302170056
    
    5587	31214569	174395797003
    
    5588	31225744	174489457472
    
    5589	31236921	174583151469
    
    5590	31248100	174676879000
    
    5591	31259281	174770640071
    
    5592	31270464	174864434688
    
    5593	31281649	174958262857
    
    5594	31292836	175052124584
    
    5595	31304025	175146019875
    
    5596	31315216	175239948736
    
    5597	31326409	175333911173
    
    5598	31337604	175427907192
    
    5599	31348801	175521936799
    
    5600	31360000	175616000000
    
    5601	31371201	175710096801
    
    5602	31382404	175804227208
    
    5603	31393609	175898391227
    
    5604	31404816	175992588864
    
    5605	31416025	176086820125
    
    5606	31427236	176181085016
    
    5607	31438449	176275383543
    
    5608	31449664	176369715712
    
    5609	31460881	176464081529
    
    5610	31472100	176558481000
    
    5611	31483321	176652914131
    
    5612	31494544	176747380928
    
    5613	31505769	176841881397
    
    5614	31516996	176936415544
    
    5615	31528225	177030983375
    
    5616	31539456	177125584896
    
    5617	31550689	177220220113
    
    5618	31561924	177314889032
    
    5619	31573161	177409591659
    
    5620	31584400	177504328000
    
    5621	31595641	177599098061
    
    5622	31606884	177693901848
    
    5623	31618129	177788739367
    
    5624	31629376	177883610624
    
    5625	31640625	177978515625
    
    5626	31651876	178073454376
    
    5627	31663129	178168426883
    
    5628	31674384	178263433152
    
    5629	31685641	178358473189
    
    5630	31696900	178453547000
    
    5631	31708161	178548654591
    
    5632	31719424	178643795968
    
    5633	31730689	178738971137
    
    5634	31741956	178834180104
    
    5635	31753225	178929422875
    
    5636	31764496	179024699456
    
    5637	31775769	179120009853
    
    5638	31787044	179215354072
    
    5639	31798321	179310732119
    
    5640	31809600	179406144000
    
    5641	31820881	179501589721
    
    5642	31832164	179597069288
    
    5643	31843449	179692582707
    
    5644	31854736	179788129984
    
    5645	31866025	179883711125
    
    5646	31877316	179979326136
    
    5647	31888609	180074975023
    
    5648	31899904	180170657792
    
    5649	31911201	180266374449
    
    5650	31922500	180362125000
    
    5651	31933801	180457909451
    
    5652	31945104	180553727808
    
    5653	31956409	180649580077
    
    5654	31967716	180745466264
    
    5655	31979025	180841386375
    
    5656	31990336	180937340416
    
    5657	32001649	181033328393
    
    5658	32012964	181129350312
    
    5659	32024281	181225406179
    
    5660	32035600	181321496000
    
    5661	32046921	181417619781
    
    5662	32058244	181513777528
    
    5663	32069569	181609969247
    
    5664	32080896	181706194944
    
    5665	32092225	181802454625
    
    5666	32103556	181898748296
    
    5667	32114889	181995075963
    
    5668	32126224	182091437632
    
    5669	32137561	182187833309
    
    5670	32148900	182284263000
    
    5671	32160241	182380726711
    
    5672	32171584	182477224448
    
    5673	32182929	182573756217
    
    5674	32194276	182670322024
    
    5675	32205625	182766921875
    
    5676	32216976	182863555776
    
    5677	32228329	182960223733
    
    5678	32239684	183056925752
    
    5679	32251041	183153661839
    
    5680	32262400	183250432000
    
    5681	32273761	183347236241
    
    5682	32285124	183444074568
    
    5683	32296489	183540946987
    
    5684	32307856	183637853504
    
    5685	32319225	183734794125
    
    5686	32330596	183831768856
    
    5687	32341969	183928777703
    
    5688	32353344	184025820672
    
    5689	32364721	184122897769
    
    5690	32376100	184220009000
    
    5691	32387481	184317154371
    
    5692	32398864	184414333888
    
    5693	32410249	184511547557
    
    5694	32421636	184608795384
    
    5695	32433025	184706077375
    
    5696	32444416	184803393536
    
    5697	32455809	184900743873
    
    5698	32467204	184998128392
    
    5699	32478601	185095547099
    
    5700	32490000	185193000000
    
    5701	32501401	185290487101
    
    5702	32512804	185388008408
    
    5703	32524209	185485563927
    
    5704	32535616	185583153664
    
    5705	32547025	185680777625
    
    5706	32558436	185778435816
    
    5707	32569849	185876128243
    
    5708	32581264	185973854912
    
    5709	32592681	186071615829
    
    5710	32604100	186169411000
    
    5711	32615521	186267240431
    
    5712	32626944	186365104128
    
    5713	32638369	186463002097
    
    5714	32649796	186560934344
    
    5715	32661225	186658900875
    
    5716	32672656	186756901696
    
    5717	32684089	186854936813
    
    5718	32695524	186953006232
    
    5719	32706961	187051109959
    
    5720	32718400	187149248000
    
    5721	32729841	187247420361
    
    5722	32741284	187345627048
    
    5723	32752729	187443868067
    
    5724	32764176	187542143424
    
    5725	32775625	187640453125
    
    5726	32787076	187738797176
    
    5727	32798529	187837175583
    
    5728	32809984	187935588352
    
    5729	32821441	188034035489
    
    5730	32832900	188132517000
    
    5731	32844361	188231032891
    
    5732	32855824	188329583168
    
    5733	32867289	188428167837
    
    5734	32878756	188526786904
    
    5735	32890225	188625440375
    
    5736	32901696	188724128256
    
    5737	32913169	188822850553
    
    5738	32924644	188921607272
    
    5739	32936121	189020398419
    
    5740	32947600	189119224000
    
    5741	32959081	189218084021
    
    5742	32970564	189316978488
    
    5743	32982049	189415907407
    
    5744	32993536	189514870784
    
    5745	33005025	189613868625
    
    5746	33016516	189712900936
    
    5747	33028009	189811967723
    
    5748	33039504	189911068992
    
    5749	33051001	190010204749
    
    5750	33062500	190109375000
    
    5751	33074001	190208579751
    
    5752	33085504	190307819008
    
    5753	33097009	190407092777
    
    5754	33108516	190506401064
    
    5755	33120025	190605743875
    
    5756	33131536	190705121216
    
    5757	33143049	190804533093
    
    5758	33154564	190903979512
    
    5759	33166081	191003460479
    
    5760	33177600	191102976000
    
    5761	33189121	191202526081
    
    5762	33200644	191302110728
    
    5763	33212169	191401729947
    
    5764	33223696	191501383744
    
    5765	33235225	191601072125
    
    5766	33246756	191700795096
    
    5767	33258289	191800552663
    
    5768	33269824	191900344832
    
    5769	33281361	192000171609
    
    5770	33292900	192100033000
    
    5771	33304441	192199929011
    
    5772	33315984	192299859648
    
    5773	33327529	192399824917
    
    5774	33339076	192499824824
    
    5775	33350625	192599859375
    
    5776	33362176	192699928576
    
    5777	33373729	192800032433
    
    5778	33385284	192900170952
    
    5779	33396841	193000344139
    
    5780	33408400	193100552000
    
    5781	33419961	193200794541
    
    5782	33431524	193301071768
    
    5783	33443089	193401383687
    
    5784	33454656	193501730304
    
    5785	33466225	193602111625
    
    5786	33477796	193702527656
    
    5787	33489369	193802978403
    
    5788	33500944	193903463872
    
    5789	33512521	194003984069
    
    5790	33524100	194104539000
    
    5791	33535681	194205128671
    
    5792	33547264	194305753088
    
    5793	33558849	194406412257
    
    5794	33570436	194507106184
    
    5795	33582025	194607834875
    
    5796	33593616	194708598336
    
    5797	33605209	194809396573
    
    5798	33616804	194910229592
    
    5799	33628401	195011097399
    
    5800	33640000	195112000000
    
    5801	33651601	195212937401
    
    5802	33663204	195313909608
    
    5803	33674809	195414916627
    
    5804	33686416	195515958464
    
    5805	33698025	195617035125
    
    5806	33709636	195718146616
    
    5807	33721249	195819292943
    
    5808	33732864	195920474112
    
    5809	33744481	196021690129
    
    5810	33756100	196122941000
    
    5811	33767721	196224226731
    
    5812	33779344	196325547328
    
    5813	33790969	196426902797
    
    5814	33802596	196528293144
    
    5815	33814225	196629718375
    
    5816	33825856	196731178496
    
    5817	33837489	196832673513
    
    5818	33849124	196934203432
    
    5819	33860761	197035768259
    
    5820	33872400	197137368000
    
    5821	33884041	197239002661
    
    5822	33895684	197340672248
    
    5823	33907329	197442376767
    
    5824	33918976	197544116224
    
    5825	33930625	197645890625
    
    5826	33942276	197747699976
    
    5827	33953929	197849544283
    
    5828	33965584	197951423552
    
    5829	33977241	198053337789
    
    5830	33988900	198155287000
    
    5831	34000561	198257271191
    
    5832	34012224	198359290368
    
    5833	34023889	198461344537
    
    5834	34035556	198563433704
    
    5835	34047225	198665557875
    
    5836	34058896	198767717056
    
    5837	34070569	198869911253
    
    5838	34082244	198972140472
    
    5839	34093921	199074404719
    
    5840	34105600	199176704000
    
    5841	34117281	199279038321
    
    5842	34128964	199381407688
    
    5843	34140649	199483812107
    
    5844	34152336	199586251584
    
    5845	34164025	199688726125
    
    5846	34175716	199791235736
    
    5847	34187409	199893780423
    
    5848	34199104	199996360192
    
    5849	34210801	200098975049
    
    5850	34222500	200201625000
    
    5851	34234201	200304310051
    
    5852	34245904	200407030208
    
    5853	34257609	200509785477
    
    5854	34269316	200612575864
    
    5855	34281025	200715401375
    
    5856	34292736	200818262016
    
    5857	34304449	200921157793
    
    5858	34316164	201024088712
    
    5859	34327881	201127054779
    
    5860	34339600	201230056000
    
    5861	34351321	201333092381
    
    5862	34363044	201436163928
    
    5863	34374769	201539270647
    
    5864	34386496	201642412544
    
    5865	34398225	201745589625
    
    5866	34409956	201848801896
    
    5867	34421689	201952049363
    
    5868	34433424	202055332032
    
    5869	34445161	202158649909
    
    5870	34456900	202262003000
    
    5871	34468641	202365391311
    
    5872	34480384	202468814848
    
    5873	34492129	202572273617
    
    5874	34503876	202675767624
    
    5875	34515625	202779296875
    
    5876	34527376	202882861376
    
    5877	34539129	202986461133
    
    5878	34550884	203090096152
    
    5879	34562641	203193766439
    
    5880	34574400	203297472000
    
    5881	34586161	203401212841
    
    5882	34597924	203504988968
    
    5883	34609689	203608800387
    
    5884	34621456	203712647104
    
    5885	34633225	203816529125
    
    5886	34644996	203920446456
    
    5887	34656769	204024399103
    
    5888	34668544	204128387072
    
    5889	34680321	204232410369
    
    5890	34692100	204336469000
    
    5891	34703881	204440562971
    
    5892	34715664	204544692288
    
    5893	34727449	204648856957
    
    5894	34739236	204753056984
    
    5895	34751025	204857292375
    
    5896	34762816	204961563136
    
    5897	34774609	205065869273
    
    5898	34786404	205170210792
    
    5899	34798201	205274587699
    
    5900	34810000	205379000000
    
    5901	34821801	205483447701
    
    5902	34833604	205587930808
    
    5903	34845409	205692449327
    
    5904	34857216	205797003264
    
    5905	34869025	205901592625
    
    5906	34880836	206006217416
    
    5907	34892649	206110877643
    
    5908	34904464	206215573312
    
    5909	34916281	206320304429
    
    5910	34928100	206425071000
    
    5911	34939921	206529873031
    
    5912	34951744	206634710528
    
    5913	34963569	206739583497
    
    5914	34975396	206844491944
    
    5915	34987225	206949435875
    
    5916	34999056	207054415296
    
    5917	35010889	207159430213
    
    5918	35022724	207264480632
    
    5919	35034561	207369566559
    
    5920	35046400	207474688000
    
    5921	35058241	207579844961
    
    5922	35070084	207685037448
    
    5923	35081929	207790265467
    
    5924	35093776	207895529024
    
    5925	35105625	208000828125
    
    5926	35117476	208106162776
    
    5927	35129329	208211532983
    
    5928	35141184	208316938752
    
    5929	35153041	208422380089
    
    5930	35164900	208527857000
    
    5931	35176761	208633369491
    
    5932	35188624	208738917568
    
    5933	35200489	208844501237
    
    5934	35212356	208950120504
    
    5935	35224225	209055775375
    
    5936	35236096	209161465856
    
    5937	35247969	209267191953
    
    5938	35259844	209372953672
    
    5939	35271721	209478751019
    
    5940	35283600	209584584000
    
    5941	35295481	209690452621
    
    5942	35307364	209796356888
    
    5943	35319249	209902296807
    
    5944	35331136	210008272384
    
    5945	35343025	210114283625
    
    5946	35354916	210220330536
    
    5947	35366809	210326413123
    
    5948	35378704	210432531392
    
    5949	35390601	210538685349
    
    5950	35402500	210644875000
    
    5951	35414401	210751100351
    
    5952	35426304	210857361408
    
    5953	35438209	210963658177
    
    5954	35450116	211069990664
    
    5955	35462025	211176358875
    
    5956	35473936	211282762816
    
    5957	35485849	211389202493
    
    5958	35497764	211495677912
    
    5959	35509681	211602189079
    
    5960	35521600	211708736000
    
    5961	35533521	211815318681
    
    5962	35545444	211921937128
    
    5963	35557369	212028591347
    
    5964	35569296	212135281344
    
    5965	35581225	212242007125
    
    5966	35593156	212348768696
    
    5967	35605089	212455566063
    
    5968	35617024	212562399232
    
    5969	35628961	212669268209
    
    5970	35640900	212776173000
    
    5971	35652841	212883113611
    
    5972	35664784	212990090048
    
    5973	35676729	213097102317
    
    5974	35688676	213204150424
    
    5975	35700625	213311234375
    
    5976	35712576	213418354176
    
    5977	35724529	213525509833
    
    5978	35736484	213632701352
    
    5979	35748441	213739928739
    
    5980	35760400	213847192000
    
    5981	35772361	213954491141
    
    5982	35784324	214061826168
    
    5983	35796289	214169197087
    
    5984	35808256	214276603904
    
    5985	35820225	214384046625
    
    5986	35832196	214491525256
    
    5987	35844169	214599039803
    
    5988	35856144	214706590272
    
    5989	35868121	214814176669
    
    5990	35880100	214921799000
    
    5991	35892081	215029457271
    
    5992	35904064	215137151488
    
    5993	35916049	215244881657
    
    5994	35928036	215352647784
    
    5995	35940025	215460449875
    
    5996	35952016	215568287936
    
    5997	35964009	215676161973
    
    5998	35976004	215784071992
    
    5999	35988001	215892017999
    
    6000	36000000	216000000000
    
    6001	36012001	216108018001
    
    6002	36024004	216216072008
    
    6003	36036009	216324162027
    
    6004	36048016	216432288064
    
    6005	36060025	216540450125
    
    6006	36072036	216648648216
    
    6007	36084049	216756882343
    
    6008	36096064	216865152512
    
    6009	36108081	216973458729
    
    6010	36120100	217081801000
    
    6011	36132121	217190179331
    
    6012	36144144	217298593728
    
    6013	36156169	217407044197
    
    6014	36168196	217515530744
    
    6015	36180225	217624053375
    
    6016	36192256	217732612096
    
    6017	36204289	217841206913
    
    6018	36216324	217949837832
    
    6019	36228361	218058504859
    
    6020	36240400	218167208000
    
    6021	36252441	218275947261
    
    6022	36264484	218384722648
    
    6023	36276529	218493534167
    
    6024	36288576	218602381824
    
    6025	36300625	218711265625
    
    6026	36312676	218820185576
    
    6027	36324729	218929141683
    
    6028	36336784	219038133952
    
    6029	36348841	219147162389
    
    6030	36360900	219256227000
    
    6031	36372961	219365327791
    
    6032	36385024	219474464768
    
    6033	36397089	219583637937
    
    6034	36409156	219692847304
    
    6035	36421225	219802092875
    
    6036	36433296	219911374656
    
    6037	36445369	220020692653
    
    6038	36457444	220130046872
    
    6039	36469521	220239437319
    
    6040	36481600	220348864000
    
    6041	36493681	220458326921
    
    6042	36505764	220567826088
    
    6043	36517849	220677361507
    
    6044	36529936	220786933184
    
    6045	36542025	220896541125
    
    6046	36554116	221006185336
    
    6047	36566209	221115865823
    
    6048	36578304	221225582592
    
    6049	36590401	221335335649
    
    6050	36602500	221445125000
    
    6051	36614601	221554950651
    
    6052	36626704	221664812608
    
    6053	36638809	221774710877
    
    6054	36650916	221884645464
    
    6055	36663025	221994616375
    
    6056	36675136	222104623616
    
    6057	36687249	222214667193
    
    6058	36699364	222324747112
    
    6059	36711481	222434863379
    
    6060	36723600	222545016000
    
    6061	36735721	222655204981
    
    6062	36747844	222765430328
    
    6063	36759969	222875692047
    
    6064	36772096	222985990144
    
    6065	36784225	223096324625
    
    6066	36796356	223206695496
    
    6067	36808489	223317102763
    
    6068	36820624	223427546432
    
    6069	36832761	223538026509
    
    6070	36844900	223648543000
    
    6071	36857041	223759095911
    
    6072	36869184	223869685248
    
    6073	36881329	223980311017
    
    6074	36893476	224090973224
    
    6075	36905625	224201671875
    
    6076	36917776	224312406976
    
    6077	36929929	224423178533
    
    6078	36942084	224533986552
    
    6079	36954241	224644831039
    
    6080	36966400	224755712000
    
    6081	36978561	224866629441
    
    6082	36990724	224977583368
    
    6083	37002889	225088573787
    
    6084	37015056	225199600704
    
    6085	37027225	225310664125
    
    6086	37039396	225421764056
    
    6087	37051569	225532900503
    
    6088	37063744	225644073472
    
    6089	37075921	225755282969
    
    6090	37088100	225866529000
    
    6091	37100281	225977811571
    
    6092	37112464	226089130688
    
    6093	37124649	226200486357
    
    6094	37136836	226311878584
    
    6095	37149025	226423307375
    
    6096	37161216	226534772736
    
    6097	37173409	226646274673
    
    6098	37185604	226757813192
    
    6099	37197801	226869388299
    
    6100	37210000	226981000000
    
    6101	37222201	227092648301
    
    6102	37234404	227204333208
    
    6103	37246609	227316054727
    
    6104	37258816	227427812864
    
    6105	37271025	227539607625
    
    6106	37283236	227651439016
    
    6107	37295449	227763307043
    
    6108	37307664	227875211712
    
    6109	37319881	227987153029
    
    6110	37332100	228099131000
    
    6111	37344321	228211145631
    
    6112	37356544	228323196928
    
    6113	37368769	228435284897
    
    6114	37380996	228547409544
    
    6115	37393225	228659570875
    
    6116	37405456	228771768896
    
    6117	37417689	228884003613
    
    6118	37429924	228996275032
    
    6119	37442161	229108583159
    
    6120	37454400	229220928000
    
    6121	37466641	229333309561
    
    6122	37478884	229445727848
    
    6123	37491129	229558182867
    
    6124	37503376	229670674624
    
    6125	37515625	229783203125
    
    6126	37527876	229895768376
    
    6127	37540129	230008370383
    
    6128	37552384	230121009152
    
    6129	37564641	230233684689
    
    6130	37576900	230346397000
    
    6131	37589161	230459146091
    
    6132	37601424	230571931968
    
    6133	37613689	230684754637
    
    6134	37625956	230797614104
    
    6135	37638225	230910510375
    
    6136	37650496	231023443456
    
    6137	37662769	231136413353
    
    6138	37675044	231249420072
    
    6139	37687321	231362463619
    
    6140	37699600	231475544000
    
    6141	37711881	231588661221
    
    6142	37724164	231701815288
    
    6143	37736449	231815006207
    
    6144	37748736	231928233984
    
    6145	37761025	232041498625
    
    6146	37773316	232154800136
    
    6147	37785609	232268138523
    
    6148	37797904	232381513792
    
    6149	37810201	232494925949
    
    6150	37822500	232608375000
    
    6151	37834801	232721860951
    
    6152	37847104	232835383808
    
    6153	37859409	232948943577
    
    6154	37871716	233062540264
    
    6155	37884025	233176173875
    
    6156	37896336	233289844416
    
    6157	37908649	233403551893
    
    6158	37920964	233517296312
    
    6159	37933281	233631077679
    
    6160	37945600	233744896000
    
    6161	37957921	233858751281
    
    6162	37970244	233972643528
    
    6163	37982569	234086572747
    
    6164	37994896	234200538944
    
    6165	38007225	234314542125
    
    6166	38019556	234428582296
    
    6167	38031889	234542659463
    
    6168	38044224	234656773632
    
    6169	38056561	234770924809
    
    6170	38068900	234885113000
    
    6171	38081241	234999338211
    
    6172	38093584	235113600448
    
    6173	38105929	235227899717
    
    6174	38118276	235342236024
    
    6175	38130625	235456609375
    
    6176	38142976	235571019776
    
    6177	38155329	235685467233
    
    6178	38167684	235799951752
    
    6179	38180041	235914473339
    
    6180	38192400	236029032000
    
    6181	38204761	236143627741
    
    6182	38217124	236258260568
    
    6183	38229489	236372930487
    
    6184	38241856	236487637504
    
    6185	38254225	236602381625
    
    6186	38266596	236717162856
    
    6187	38278969	236831981203
    
    6188	38291344	236946836672
    
    6189	38303721	237061729269
    
    6190	38316100	237176659000
    
    6191	38328481	237291625871
    
    6192	38340864	237406629888
    
    6193	38353249	237521671057
    
    6194	38365636	237636749384
    
    6195	38378025	237751864875
    
    6196	38390416	237867017536
    
    6197	38402809	237982207373
    
    6198	38415204	238097434392
    
    6199	38427601	238212698599
    
    6200	38440000	238328000000
    
    6201	38452401	238443338601
    
    6202	38464804	238558714408
    
    6203	38477209	238674127427
    
    6204	38489616	238789577664
    
    6205	38502025	238905065125
    
    6206	38514436	239020589816
    
    6207	38526849	239136151743
    
    6208	38539264	239251750912
    
    6209	38551681	239367387329
    
    6210	38564100	239483061000
    
    6211	38576521	239598771931
    
    6212	38588944	239714520128
    
    6213	38601369	239830305597
    
    6214	38613796	239946128344
    
    6215	38626225	240061988375
    
    6216	38638656	240177885696
    
    6217	38651089	240293820313
    
    6218	38663524	240409792232
    
    6219	38675961	240525801459
    
    6220	38688400	240641848000
    
    6221	38700841	240757931861
    
    6222	38713284	240874053048
    
    6223	38725729	240990211567
    
    6224	38738176	241106407424
    
    6225	38750625	241222640625
    
    6226	38763076	241338911176
    
    6227	38775529	241455219083
    
    6228	38787984	241571564352
    
    6229	38800441	241687946989
    
    6230	38812900	241804367000
    
    6231	38825361	241920824391
    
    6232	38837824	242037319168
    
    6233	38850289	242153851337
    
    6234	38862756	242270420904
    
    6235	38875225	242387027875
    
    6236	38887696	242503672256
    
    6237	38900169	242620354053
    
    6238	38912644	242737073272
    
    6239	38925121	242853829919
    
    6240	38937600	242970624000
    
    6241	38950081	243087455521
    
    6242	38962564	243204324488
    
    6243	38975049	243321230907
    
    6244	38987536	243438174784
    
    6245	39000025	243555156125
    
    6246	39012516	243672174936
    
    6247	39025009	243789231223
    
    6248	39037504	243906324992
    
    6249	39050001	244023456249
    
    6250	39062500	244140625000
    
    6251	39075001	244257831251
    
    6252	39087504	244375075008
    
    6253	39100009	244492356277
    
    6254	39112516	244609675064
    
    6255	39125025	244727031375
    
    6256	39137536	244844425216
    
    6257	39150049	244961856593
    
    6258	39162564	245079325512
    
    6259	39175081	245196831979
    
    6260	39187600	245314376000
    
    6261	39200121	245431957581
    
    6262	39212644	245549576728
    
    6263	39225169	245667233447
    
    6264	39237696	245784927744
    
    6265	39250225	245902659625
    
    6266	39262756	246020429096
    
    6267	39275289	246138236163
    
    6268	39287824	246256080832
    
    6269	39300361	246373963109
    
    6270	39312900	246491883000
    
    6271	39325441	246609840511
    
    6272	39337984	246727835648
    
    6273	39350529	246845868417
    
    6274	39363076	246963938824
    
    6275	39375625	247082046875
    
    6276	39388176	247200192576
    
    6277	39400729	247318375933
    
    6278	39413284	247436596952
    
    6279	39425841	247554855639
    
    6280	39438400	247673152000
    
    6281	39450961	247791486041
    
    6282	39463524	247909857768
    
    6283	39476089	248028267187
    
    6284	39488656	248146714304
    
    6285	39501225	248265199125
    
    6286	39513796	248383721656
    
    6287	39526369	248502281903
    
    6288	39538944	248620879872
    
    6289	39551521	248739515569
    
    6290	39564100	248858189000
    
    6291	39576681	248976900171
    
    6292	39589264	249095649088
    
    6293	39601849	249214435757
    
    6294	39614436	249333260184
    
    6295	39627025	249452122375
    
    6296	39639616	249571022336
    
    6297	39652209	249689960073
    
    6298	39664804	249808935592
    
    6299	39677401	249927948899
    
    6300	39690000	250047000000
    
    6301	39702601	250166088901
    
    6302	39715204	250285215608
    
    6303	39727809	250404380127
    
    6304	39740416	250523582464
    
    6305	39753025	250642822625
    
    6306	39765636	250762100616
    
    6307	39778249	250881416443
    
    6308	39790864	251000770112
    
    6309	39803481	251120161629
    
    6310	39816100	251239591000
    
    6311	39828721	251359058231
    
    6312	39841344	251478563328
    
    6313	39853969	251598106297
    
    6314	39866596	251717687144
    
    6315	39879225	251837305875
    
    6316	39891856	251956962496
    
    6317	39904489	252076657013
    
    6318	39917124	252196389432
    
    6319	39929761	252316159759
    
    6320	39942400	252435968000
    
    6321	39955041	252555814161
    
    6322	39967684	252675698248
    
    6323	39980329	252795620267
    
    6324	39992976	252915580224
    
    6325	40005625	253035578125
    
    6326	40018276	253155613976
    
    6327	40030929	253275687783
    
    6328	40043584	253395799552
    
    6329	40056241	253515949289
    
    6330	40068900	253636137000
    
    6331	40081561	253756362691
    
    6332	40094224	253876626368
    
    6333	40106889	253996928037
    
    6334	40119556	254117267704
    
    6335	40132225	254237645375
    
    6336	40144896	254358061056
    
    6337	40157569	254478514753
    
    6338	40170244	254599006472
    
    6339	40182921	254719536219
    
    6340	40195600	254840104000
    
    6341	40208281	254960709821
    
    6342	40220964	255081353688
    
    6343	40233649	255202035607
    
    6344	40246336	255322755584
    
    6345	40259025	255443513625
    
    6346	40271716	255564309736
    
    6347	40284409	255685143923
    
    6348	40297104	255806016192
    
    6349	40309801	255926926549
    
    6350	40322500	256047875000
    
    6351	40335201	256168861551
    
    6352	40347904	256289886208
    
    6353	40360609	256410948977
    
    6354	40373316	256532049864
    
    6355	40386025	256653188875
    
    6356	40398736	256774366016
    
    6357	40411449	256895581293
    
    6358	40424164	257016834712
    
    6359	40436881	257138126279
    
    6360	40449600	257259456000
    
    6361	40462321	257380823881
    
    6362	40475044	257502229928
    
    6363	40487769	257623674147
    
    6364	40500496	257745156544
    
    6365	40513225	257866677125
    
    6366	40525956	257988235896
    
    6367	40538689	258109832863
    
    6368	40551424	258231468032
    
    6369	40564161	258353141409
    
    6370	40576900	258474853000
    
    6371	40589641	258596602811
    
    6372	40602384	258718390848
    
    6373	40615129	258840217117
    
    6374	40627876	258962081624
    
    6375	40640625	259083984375
    
    6376	40653376	259205925376
    
    6377	40666129	259327904633
    
    6378	40678884	259449922152
    
    6379	40691641	259571977939
    
    6380	40704400	259694072000
    
    6381	40717161	259816204341
    
    6382	40729924	259938374968
    
    6383	40742689	260060583887
    
    6384	40755456	260182831104
    
    6385	40768225	260305116625
    
    6386	40780996	260427440456
    
    6387	40793769	260549802603
    
    6388	40806544	260672203072
    
    6389	40819321	260794641869
    
    6390	40832100	260917119000
    
    6391	40844881	261039634471
    
    6392	40857664	261162188288
    
    6393	40870449	261284780457
    
    6394	40883236	261407410984
    
    6395	40896025	261530079875
    
    6396	40908816	261652787136
    
    6397	40921609	261775532773
    
    6398	40934404	261898316792
    
    6399	40947201	262021139199
    
    6400	40960000	262144000000
    
    6401	40972801	262266899201
    
    6402	40985604	262389836808
    
    6403	40998409	262512812827
    
    6404	41011216	262635827264
    
    6405	41024025	262758880125
    
    6406	41036836	262881971416
    
    6407	41049649	263005101143
    
    6408	41062464	263128269312
    
    6409	41075281	263251475929
    
    6410	41088100	263374721000
    
    6411	41100921	263498004531
    
    6412	41113744	263621326528
    
    6413	41126569	263744686997
    
    6414	41139396	263868085944
    
    6415	41152225	263991523375
    
    6416	41165056	264114999296
    
    6417	41177889	264238513713
    
    6418	41190724	264362066632
    
    6419	41203561	264485658059
    
    6420	41216400	264609288000
    
    6421	41229241	264732956461
    
    6422	41242084	264856663448
    
    6423	41254929	264980408967
    
    6424	41267776	265104193024
    
    6425	41280625	265228015625
    
    6426	41293476	265351876776
    
    6427	41306329	265475776483
    
    6428	41319184	265599714752
    
    6429	41332041	265723691589
    
    6430	41344900	265847707000
    
    6431	41357761	265971760991
    
    6432	41370624	266095853568
    
    6433	41383489	266219984737
    
    6434	41396356	266344154504
    
    6435	41409225	266468362875
    
    6436	41422096	266592609856
    
    6437	41434969	266716895453
    
    6438	41447844	266841219672
    
    6439	41460721	266965582519
    
    6440	41473600	267089984000
    
    6441	41486481	267214424121
    
    6442	41499364	267338902888
    
    6443	41512249	267463420307
    
    6444	41525136	267587976384
    
    6445	41538025	267712571125
    
    6446	41550916	267837204536
    
    6447	41563809	267961876623
    
    6448	41576704	268086587392
    
    6449	41589601	268211336849
    
    6450	41602500	268336125000
    
    6451	41615401	268460951851
    
    6452	41628304	268585817408
    
    6453	41641209	268710721677
    
    6454	41654116	268835664664
    
    6455	41667025	268960646375
    
    6456	41679936	269085666816
    
    6457	41692849	269210725993
    
    6458	41705764	269335823912
    
    6459	41718681	269460960579
    
    6460	41731600	269586136000
    
    6461	41744521	269711350181
    
    6462	41757444	269836603128
    
    6463	41770369	269961894847
    
    6464	41783296	270087225344
    
    6465	41796225	270212594625
    
    6466	41809156	270338002696
    
    6467	41822089	270463449563
    
    6468	41835024	270588935232
    
    6469	41847961	270714459709
    
    6470	41860900	270840023000
    
    6471	41873841	270965625111
    
    6472	41886784	271091266048
    
    6473	41899729	271216945817
    
    6474	41912676	271342664424
    
    6475	41925625	271468421875
    
    6476	41938576	271594218176
    
    6477	41951529	271720053333
    
    6478	41964484	271845927352
    
    6479	41977441	271971840239
    
    6480	41990400	272097792000
    
    6481	42003361	272223782641
    
    6482	42016324	272349812168
    
    6483	42029289	272475880587
    
    6484	42042256	272601987904
    
    6485	42055225	272728134125
    
    6486	42068196	272854319256
    
    6487	42081169	272980543303
    
    6488	42094144	273106806272
    
    6489	42107121	273233108169
    
    6490	42120100	273359449000
    
    6491	42133081	273485828771
    
    6492	42146064	273612247488
    
    6493	42159049	273738705157
    
    6494	42172036	273865201784
    
    6495	42185025	273991737375
    
    6496	42198016	274118311936
    
    6497	42211009	274244925473
    
    6498	42224004	274371577992
    
    6499	42237001	274498269499
    
    6500	42250000	274625000000
    
    6501	42263001	274751769501
    
    6502	42276004	274878578008
    
    6503	42289009	275005425527
    
    6504	42302016	275132312064
    
    6505	42315025	275259237625
    
    6506	42328036	275386202216
    
    6507	42341049	275513205843
    
    6508	42354064	275640248512
    
    6509	42367081	275767330229
    
    6510	42380100	275894451000
    
    6511	42393121	276021610831
    
    6512	42406144	276148809728
    
    6513	42419169	276276047697
    
    6514	42432196	276403324744
    
    6515	42445225	276530640875
    
    6516	42458256	276657996096
    
    6517	42471289	276785390413
    
    6518	42484324	276912823832
    
    6519	42497361	277040296359
    
    6520	42510400	277167808000
    
    6521	42523441	277295358761
    
    6522	42536484	277422948648
    
    6523	42549529	277550577667
    
    6524	42562576	277678245824
    
    6525	42575625	277805953125
    
    6526	42588676	277933699576
    
    6527	42601729	278061485183
    
    6528	42614784	278189309952
    
    6529	42627841	278317173889
    
    6530	42640900	278445077000
    
    6531	42653961	278573019291
    
    6532	42667024	278701000768
    
    6533	42680089	278829021437
    
    6534	42693156	278957081304
    
    6535	42706225	279085180375
    
    6536	42719296	279213318656
    
    6537	42732369	279341496153
    
    6538	42745444	279469712872
    
    6539	42758521	279597968819
    
    6540	42771600	279726264000
    
    6541	42784681	279854598421
    
    6542	42797764	279982972088
    
    6543	42810849	280111385007
    
    6544	42823936	280239837184
    
    6545	42837025	280368328625
    
    6546	42850116	280496859336
    
    6547	42863209	280625429323
    
    6548	42876304	280754038592
    
    6549	42889401	280882687149
    
    6550	42902500	281011375000
    
    6551	42915601	281140102151
    
    6552	42928704	281268868608
    
    6553	42941809	281397674377
    
    6554	42954916	281526519464
    
    6555	42968025	281655403875
    
    6556	42981136	281784327616
    
    6557	42994249	281913290693
    
    6558	43007364	282042293112
    
    6559	43020481	282171334879
    
    6560	43033600	282300416000
    
    6561	43046721	282429536481
    
    6562	43059844	282558696328
    
    6563	43072969	282687895547
    
    6564	43086096	282817134144
    
    6565	43099225	282946412125
    
    6566	43112356	283075729496
    
    6567	43125489	283205086263
    
    6568	43138624	283334482432
    
    6569	43151761	283463918009
    
    6570	43164900	283593393000
    
    6571	43178041	283722907411
    
    6572	43191184	283852461248
    
    6573	43204329	283982054517
    
    6574	43217476	284111687224
    
    6575	43230625	284241359375
    
    6576	43243776	284371070976
    
    6577	43256929	284500822033
    
    6578	43270084	284630612552
    
    6579	43283241	284760442539
    
    6580	43296400	284890312000
    
    6581	43309561	285020220941
    
    6582	43322724	285150169368
    
    6583	43335889	285280157287
    
    6584	43349056	285410184704
    
    6585	43362225	285540251625
    
    6586	43375396	285670358056
    
    6587	43388569	285800504003
    
    6588	43401744	285930689472
    
    6589	43414921	286060914469
    
    6590	43428100	286191179000
    
    6591	43441281	286321483071
    
    6592	43454464	286451826688
    
    6593	43467649	286582209857
    
    6594	43480836	286712632584
    
    6595	43494025	286843094875
    
    6596	43507216	286973596736
    
    6597	43520409	287104138173
    
    6598	43533604	287234719192
    
    6599	43546801	287365339799
    
    6600	43560000	287496000000
    
    6601	43573201	287626699801
    
    6602	43586404	287757439208
    
    6603	43599609	287888218227
    
    6604	43612816	288019036864
    
    6605	43626025	288149895125
    
    6606	43639236	288280793016
    
    6607	43652449	288411730543
    
    6608	43665664	288542707712
    
    6609	43678881	288673724529
    
    6610	43692100	288804781000
    
    6611	43705321	288935877131
    
    6612	43718544	289067012928
    
    6613	43731769	289198188397
    
    6614	43744996	289329403544
    
    6615	43758225	289460658375
    
    6616	43771456	289591952896
    
    6617	43784689	289723287113
    
    6618	43797924	289854661032
    
    6619	43811161	289986074659
    
    6620	43824400	290117528000
    
    6621	43837641	290249021061
    
    6622	43850884	290380553848
    
    6623	43864129	290512126367
    
    6624	43877376	290643738624
    
    6625	43890625	290775390625
    
    6626	43903876	290907082376
    
    6627	43917129	291038813883
    
    6628	43930384	291170585152
    
    6629	43943641	291302396189
    
    6630	43956900	291434247000
    
    6631	43970161	291566137591
    
    6632	43983424	291698067968
    
    6633	43996689	291830038137
    
    6634	44009956	291962048104
    
    6635	44023225	292094097875
    
    6636	44036496	292226187456
    
    6637	44049769	292358316853
    
    6638	44063044	292490486072
    
    6639	44076321	292622695119
    
    6640	44089600	292754944000
    
    6641	44102881	292887232721
    
    6642	44116164	293019561288
    
    6643	44129449	293151929707
    
    6644	44142736	293284337984
    
    6645	44156025	293416786125
    
    6646	44169316	293549274136
    
    6647	44182609	293681802023
    
    6648	44195904	293814369792
    
    6649	44209201	293946977449
    
    6650	44222500	294079625000
    
    6651	44235801	294212312451
    
    6652	44249104	294345039808
    
    6653	44262409	294477807077
    
    6654	44275716	294610614264
    
    6655	44289025	294743461375
    
    6656	44302336	294876348416
    
    6657	44315649	295009275393
    
    6658	44328964	295142242312
    
    6659	44342281	295275249179
    
    6660	44355600	295408296000
    
    6661	44368921	295541382781
    
    6662	44382244	295674509528
    
    6663	44395569	295807676247
    
    6664	44408896	295940882944
    
    6665	44422225	296074129625
    
    6666	44435556	296207416296
    
    6667	44448889	296340742963
    
    6668	44462224	296474109632
    
    6669	44475561	296607516309
    
    6670	44488900	296740963000
    
    6671	44502241	296874449711
    
    6672	44515584	297007976448
    
    6673	44528929	297141543217
    
    6674	44542276	297275150024
    
    6675	44555625	297408796875
    
    6676	44568976	297542483776
    
    6677	44582329	297676210733
    
    6678	44595684	297809977752
    
    6679	44609041	297943784839
    
    6680	44622400	298077632000
    
    6681	44635761	298211519241
    
    6682	44649124	298345446568
    
    6683	44662489	298479413987
    
    6684	44675856	298613421504
    
    6685	44689225	298747469125
    
    6686	44702596	298881556856
    
    6687	44715969	299015684703
    
    6688	44729344	299149852672
    
    6689	44742721	299284060769
    
    6690	44756100	299418309000
    
    6691	44769481	299552597371
    
    6692	44782864	299686925888
    
    6693	44796249	299821294557
    
    6694	44809636	299955703384
    
    6695	44823025	300090152375
    
    6696	44836416	300224641536
    
    6697	44849809	300359170873
    
    6698	44863204	300493740392
    
    6699	44876601	300628350099
    
    6700	44890000	300763000000
    
    6701	44903401	300897690101
    
    6702	44916804	301032420408
    
    6703	44930209	301167190927
    
    6704	44943616	301302001664
    
    6705	44957025	301436852625
    
    6706	44970436	301571743816
    
    6707	44983849	301706675243
    
    6708	44997264	301841646912
    
    6709	45010681	301976658829
    
    6710	45024100	302111711000
    
    6711	45037521	302246803431
    
    6712	45050944	302381936128
    
    6713	45064369	302517109097
    
    6714	45077796	302652322344
    
    6715	45091225	302787575875
    
    6716	45104656	302922869696
    
    6717	45118089	303058203813
    
    6718	45131524	303193578232
    
    6719	45144961	303328992959
    
    6720	45158400	303464448000
    
    6721	45171841	303599943361
    
    6722	45185284	303735479048
    
    6723	45198729	303871055067
    
    6724	45212176	304006671424
    
    6725	45225625	304142328125
    
    6726	45239076	304278025176
    
    6727	45252529	304413762583
    
    6728	45265984	304549540352
    
    6729	45279441	304685358489
    
    6730	45292900	304821217000
    
    6731	45306361	304957115891
    
    6732	45319824	305093055168
    
    6733	45333289	305229034837
    
    6734	45346756	305365054904
    
    6735	45360225	305501115375
    
    6736	45373696	305637216256
    
    6737	45387169	305773357553
    
    6738	45400644	305909539272
    
    6739	45414121	306045761419
    
    6740	45427600	306182024000
    
    6741	45441081	306318327021
    
    6742	45454564	306454670488
    
    6743	45468049	306591054407
    
    6744	45481536	306727478784
    
    6745	45495025	306863943625
    
    6746	45508516	307000448936
    
    6747	45522009	307136994723
    
    6748	45535504	307273580992
    
    6749	45549001	307410207749
    
    6750	45562500	307546875000
    
    6751	45576001	307683582751
    
    6752	45589504	307820331008
    
    6753	45603009	307957119777
    
    6754	45616516	308093949064
    
    6755	45630025	308230818875
    
    6756	45643536	308367729216
    
    6757	45657049	308504680093
    
    6758	45670564	308641671512
    
    6759	45684081	308778703479
    
    6760	45697600	308915776000
    
    6761	45711121	309052889081
    
    6762	45724644	309190042728
    
    6763	45738169	309327236947
    
    6764	45751696	309464471744
    
    6765	45765225	309601747125
    
    6766	45778756	309739063096
    
    6767	45792289	309876419663
    
    6768	45805824	310013816832
    
    6769	45819361	310151254609
    
    6770	45832900	310288733000
    
    6771	45846441	310426252011
    
    6772	45859984	310563811648
    
    6773	45873529	310701411917
    
    6774	45887076	310839052824
    
    6775	45900625	310976734375
    
    6776	45914176	311114456576
    
    6777	45927729	311252219433
    
    6778	45941284	311390022952
    
    6779	45954841	311527867139
    
    6780	45968400	311665752000
    
    6781	45981961	311803677541
    
    6782	45995524	311941643768
    
    6783	46009089	312079650687
    
    6784	46022656	312217698304
    
    6785	46036225	312355786625
    
    6786	46049796	312493915656
    
    6787	46063369	312632085403
    
    6788	46076944	312770295872
    
    6789	46090521	312908547069
    
    6790	46104100	313046839000
    
    6791	46117681	313185171671
    
    6792	46131264	313323545088
    
    6793	46144849	313461959257
    
    6794	46158436	313600414184
    
    6795	46172025	313738909875
    
    6796	46185616	313877446336
    
    6797	46199209	314016023573
    
    6798	46212804	314154641592
    
    6799	46226401	314293300399
    
    6800	46240000	314432000000
    
    6801	46253601	314570740401
    
    6802	46267204	314709521608
    
    6803	46280809	314848343627
    
    6804	46294416	314987206464
    
    6805	46308025	315126110125
    
    6806	46321636	315265054616
    
    6807	46335249	315404039943
    
    6808	46348864	315543066112
    
    6809	46362481	315682133129
    
    6810	46376100	315821241000
    
    6811	46389721	315960389731
    
    6812	46403344	316099579328
    
    6813	46416969	316238809797
    
    6814	46430596	316378081144
    
    6815	46444225	316517393375
    
    6816	46457856	316656746496
    
    6817	46471489	316796140513
    
    6818	46485124	316935575432
    
    6819	46498761	317075051259
    
    6820	46512400	317214568000
    
    6821	46526041	317354125661
    
    6822	46539684	317493724248
    
    6823	46553329	317633363767
    
    6824	46566976	317773044224
    
    6825	46580625	317912765625
    
    6826	46594276	318052527976
    
    6827	46607929	318192331283
    
    6828	46621584	318332175552
    
    6829	46635241	318472060789
    
    6830	46648900	318611987000
    
    6831	46662561	318751954191
    
    6832	46676224	318891962368
    
    6833	46689889	319032011537
    
    6834	46703556	319172101704
    
    6835	46717225	319312232875
    
    6836	46730896	319452405056
    
    6837	46744569	319592618253
    
    6838	46758244	319732872472
    
    6839	46771921	319873167719
    
    6840	46785600	320013504000
    
    6841	46799281	320153881321
    
    6842	46812964	320294299688
    
    6843	46826649	320434759107
    
    6844	46840336	320575259584
    
    6845	46854025	320715801125
    
    6846	46867716	320856383736
    
    6847	46881409	320997007423
    
    6848	46895104	321137672192
    
    6849	46908801	321278378049
    
    6850	46922500	321419125000
    
    6851	46936201	321559913051
    
    6852	46949904	321700742208
    
    6853	46963609	321841612477
    
    6854	46977316	321982523864
    
    6855	46991025	322123476375
    
    6856	47004736	322264470016
    
    6857	47018449	322405504793
    
    6858	47032164	322546580712
    
    6859	47045881	322687697779
    
    6860	47059600	322828856000
    
    6861	47073321	322970055381
    
    6862	47087044	323111295928
    
    6863	47100769	323252577647
    
    6864	47114496	323393900544
    
    6865	47128225	323535264625
    
    6866	47141956	323676669896
    
    6867	47155689	323818116363
    
    6868	47169424	323959604032
    
    6869	47183161	324101132909
    
    6870	47196900	324242703000
    
    6871	47210641	324384314311
    
    6872	47224384	324525966848
    
    6873	47238129	324667660617
    
    6874	47251876	324809395624
    
    6875	47265625	324951171875
    
    6876	47279376	325092989376
    
    6877	47293129	325234848133
    
    6878	47306884	325376748152
    
    6879	47320641	325518689439
    
    6880	47334400	325660672000
    
    6881	47348161	325802695841
    
    6882	47361924	325944760968
    
    6883	47375689	326086867387
    
    6884	47389456	326229015104
    
    6885	47403225	326371204125
    
    6886	47416996	326513434456
    
    6887	47430769	326655706103
    
    6888	47444544	326798019072
    
    6889	47458321	326940373369
    
    6890	47472100	327082769000
    
    6891	47485881	327225205971
    
    6892	47499664	327367684288
    
    6893	47513449	327510203957
    
    6894	47527236	327652764984
    
    6895	47541025	327795367375
    
    6896	47554816	327938011136
    
    6897	47568609	328080696273
    
    6898	47582404	328223422792
    
    6899	47596201	328366190699
    
    6900	47610000	328509000000
    
    6901	47623801	328651850701
    
    6902	47637604	328794742808
    
    6903	47651409	328937676327
    
    6904	47665216	329080651264
    
    6905	47679025	329223667625
    
    6906	47692836	329366725416
    
    6907	47706649	329509824643
    
    6908	47720464	329652965312
    
    6909	47734281	329796147429
    
    6910	47748100	329939371000
    
    6911	47761921	330082636031
    
    6912	47775744	330225942528
    
    6913	47789569	330369290497
    
    6914	47803396	330512679944
    
    6915	47817225	330656110875
    
    6916	47831056	330799583296
    
    6917	47844889	330943097213
    
    6918	47858724	331086652632
    
    6919	47872561	331230249559
    
    6920	47886400	331373888000
    
    6921	47900241	331517567961
    
    6922	47914084	331661289448
    
    6923	47927929	331805052467
    
    6924	47941776	331948857024
    
    6925	47955625	332092703125
    
    6926	47969476	332236590776
    
    6927	47983329	332380519983
    
    6928	47997184	332524490752
    
    6929	48011041	332668503089
    
    6930	48024900	332812557000
    
    6931	48038761	332956652491
    
    6932	48052624	333100789568
    
    6933	48066489	333244968237
    
    6934	48080356	333389188504
    
    6935	48094225	333533450375
    
    6936	48108096	333677753856
    
    6937	48121969	333822098953
    
    6938	48135844	333966485672
    
    6939	48149721	334110914019
    
    6940	48163600	334255384000
    
    6941	48177481	334399895621
    
    6942	48191364	334544448888
    
    6943	48205249	334689043807
    
    6944	48219136	334833680384
    
    6945	48233025	334978358625
    
    6946	48246916	335123078536
    
    6947	48260809	335267840123
    
    6948	48274704	335412643392
    
    6949	48288601	335557488349
    
    6950	48302500	335702375000
    
    6951	48316401	335847303351
    
    6952	48330304	335992273408
    
    6953	48344209	336137285177
    
    6954	48358116	336282338664
    
    6955	48372025	336427433875
    
    6956	48385936	336572570816
    
    6957	48399849	336717749493
    
    6958	48413764	336862969912
    
    6959	48427681	337008232079
    
    6960	48441600	337153536000
    
    6961	48455521	337298881681
    
    6962	48469444	337444269128
    
    6963	48483369	337589698347
    
    6964	48497296	337735169344
    
    6965	48511225	337880682125
    
    6966	48525156	338026236696
    
    6967	48539089	338171833063
    
    6968	48553024	338317471232
    
    6969	48566961	338463151209
    
    6970	48580900	338608873000
    
    6971	48594841	338754636611
    
    6972	48608784	338900442048
    
    6973	48622729	339046289317
    
    6974	48636676	339192178424
    
    6975	48650625	339338109375
    
    6976	48664576	339484082176
    
    6977	48678529	339630096833
    
    6978	48692484	339776153352
    
    6979	48706441	339922251739
    
    6980	48720400	340068392000
    
    6981	48734361	340214574141
    
    6982	48748324	340360798168
    
    6983	48762289	340507064087
    
    6984	48776256	340653371904
    
    6985	48790225	340799721625
    
    6986	48804196	340946113256
    
    6987	48818169	341092546803
    
    6988	48832144	341239022272
    
    6989	48846121	341385539669
    
    6990	48860100	341532099000
    
    6991	48874081	341678700271
    
    6992	48888064	341825343488
    
    6993	48902049	341972028657
    
    6994	48916036	342118755784
    
    6995	48930025	342265524875
    
    6996	48944016	342412335936
    
    6997	48958009	342559188973
    
    6998	48972004	342706083992
    
    6999	48986001	342853020999
    
    7000	49000000	343000000000
    
    7001	49014001	343147021001
    
    7002	49028004	343294084008
    
    7003	49042009	343441189027
    
    7004	49056016	343588336064
    
    7005	49070025	343735525125
    
    7006	49084036	343882756216
    
    7007	49098049	344030029343
    
    7008	49112064	344177344512
    
    7009	49126081	344324701729
    
    7010	49140100	344472101000
    
    7011	49154121	344619542331
    
    7012	49168144	344767025728
    
    7013	49182169	344914551197
    
    7014	49196196	345062118744
    
    7015	49210225	345209728375
    
    7016	49224256	345357380096
    
    7017	49238289	345505073913
    
    7018	49252324	345652809832
    
    7019	49266361	345800587859
    
    7020	49280400	345948408000
    
    7021	49294441	346096270261
    
    7022	49308484	346244174648
    
    7023	49322529	346392121167
    
    7024	49336576	346540109824
    
    7025	49350625	346688140625
    
    7026	49364676	346836213576
    
    7027	49378729	346984328683
    
    7028	49392784	347132485952
    
    7029	49406841	347280685389
    
    7030	49420900	347428927000
    
    7031	49434961	347577210791
    
    7032	49449024	347725536768
    
    7033	49463089	347873904937
    
    7034	49477156	348022315304
    
    7035	49491225	348170767875
    
    7036	49505296	348319262656
    
    7037	49519369	348467799653
    
    7038	49533444	348616378872
    
    7039	49547521	348765000319
    
    7040	49561600	348913664000
    
    7041	49575681	349062369921
    
    7042	49589764	349211118088
    
    7043	49603849	349359908507
    
    7044	49617936	349508741184
    
    7045	49632025	349657616125
    
    7046	49646116	349806533336
    
    7047	49660209	349955492823
    
    7048	49674304	350104494592
    
    7049	49688401	350253538649
    
    7050	49702500	350402625000
    
    7051	49716601	350551753651
    
    7052	49730704	350700924608
    
    7053	49744809	350850137877
    
    7054	49758916	350999393464
    
    7055	49773025	351148691375
    
    7056	49787136	351298031616
    
    7057	49801249	351447414193
    
    7058	49815364	351596839112
    
    7059	49829481	351746306379
    
    7060	49843600	351895816000
    
    7061	49857721	352045367981
    
    7062	49871844	352194962328
    
    7063	49885969	352344599047
    
    7064	49900096	352494278144
    
    7065	49914225	352643999625
    
    7066	49928356	352793763496
    
    7067	49942489	352943569763
    
    7068	49956624	353093418432
    
    7069	49970761	353243309509
    
    7070	49984900	353393243000
    
    7071	49999041	353543218911
    
    7072	50013184	353693237248
    
    7073	50027329	353843298017
    
    7074	50041476	353993401224
    
    7075	50055625	354143546875
    
    7076	50069776	354293734976
    
    7077	50083929	354443965533
    
    7078	50098084	354594238552
    
    7079	50112241	354744554039
    
    7080	50126400	354894912000
    
    7081	50140561	355045312441
    
    7082	50154724	355195755368
    
    7083	50168889	355346240787
    
    7084	50183056	355496768704
    
    7085	50197225	355647339125
    
    7086	50211396	355797952056
    
    7087	50225569	355948607503
    
    7088	50239744	356099305472
    
    7089	50253921	356250045969
    
    7090	50268100	356400829000
    
    7091	50282281	356551654571
    
    7092	50296464	356702522688
    
    7093	50310649	356853433357
    
    7094	50324836	357004386584
    
    7095	50339025	357155382375
    
    7096	50353216	357306420736
    
    7097	50367409	357457501673
    
    7098	50381604	357608625192
    
    7099	50395801	357759791299
    
    7100	50410000	357911000000
    
    7101	50424201	358062251301
    
    7102	50438404	358213545208
    
    7103	50452609	358364881727
    
    7104	50466816	358516260864
    
    7105	50481025	358667682625
    
    7106	50495236	358819147016
    
    7107	50509449	358970654043
    
    7108	50523664	359122203712
    
    7109	50537881	359273796029
    
    7110	50552100	359425431000
    
    7111	50566321	359577108631
    
    7112	50580544	359728828928
    
    7113	50594769	359880591897
    
    7114	50608996	360032397544
    
    7115	50623225	360184245875
    
    7116	50637456	360336136896
    
    7117	50651689	360488070613
    
    7118	50665924	360640047032
    
    7119	50680161	360792066159
    
    7120	50694400	360944128000
    
    7121	50708641	361096232561
    
    7122	50722884	361248379848
    
    7123	50737129	361400569867
    
    7124	50751376	361552802624
    
    7125	50765625	361705078125
    
    7126	50779876	361857396376
    
    7127	50794129	362009757383
    
    7128	50808384	362162161152
    
    7129	50822641	362314607689
    
    7130	50836900	362467097000
    
    7131	50851161	362619629091
    
    7132	50865424	362772203968
    
    7133	50879689	362924821637
    
    7134	50893956	363077482104
    
    7135	50908225	363230185375
    
    7136	50922496	363382931456
    
    7137	50936769	363535720353
    
    7138	50951044	363688552072
    
    7139	50965321	363841426619
    
    7140	50979600	363994344000
    
    7141	50993881	364147304221
    
    7142	51008164	364300307288
    
    7143	51022449	364453353207
    
    7144	51036736	364606441984
    
    7145	51051025	364759573625
    
    7146	51065316	364912748136
    
    7147	51079609	365065965523
    
    7148	51093904	365219225792
    
    7149	51108201	365372528949
    
    7150	51122500	365525875000
    
    7151	51136801	365679263951
    
    7152	51151104	365832695808
    
    7153	51165409	365986170577
    
    7154	51179716	366139688264
    
    7155	51194025	366293248875
    
    7156	51208336	366446852416
    
    7157	51222649	366600498893
    
    7158	51236964	366754188312
    
    7159	51251281	366907920679
    
    7160	51265600	367061696000
    
    7161	51279921	367215514281
    
    7162	51294244	367369375528
    
    7163	51308569	367523279747
    
    7164	51322896	367677226944
    
    7165	51337225	367831217125
    
    7166	51351556	367985250296
    
    7167	51365889	368139326463
    
    7168	51380224	368293445632
    
    7169	51394561	368447607809
    
    7170	51408900	368601813000
    
    7171	51423241	368756061211
    
    7172	51437584	368910352448
    
    7173	51451929	369064686717
    
    7174	51466276	369219064024
    
    7175	51480625	369373484375
    
    7176	51494976	369527947776
    
    7177	51509329	369682454233
    
    7178	51523684	369837003752
    
    7179	51538041	369991596339
    
    7180	51552400	370146232000
    
    7181	51566761	370300910741
    
    7182	51581124	370455632568
    
    7183	51595489	370610397487
    
    7184	51609856	370765205504
    
    7185	51624225	370920056625
    
    7186	51638596	371074950856
    
    7187	51652969	371229888203
    
    7188	51667344	371384868672
    
    7189	51681721	371539892269
    
    7190	51696100	371694959000
    
    7191	51710481	371850068871
    
    7192	51724864	372005221888
    
    7193	51739249	372160418057
    
    7194	51753636	372315657384
    
    7195	51768025	372470939875
    
    7196	51782416	372626265536
    
    7197	51796809	372781634373
    
    7198	51811204	372937046392
    
    7199	51825601	373092501599
    
    7200	51840000	373248000000
    
    7201	51854401	373403541601
    
    7202	51868804	373559126408
    
    7203	51883209	373714754427
    
    7204	51897616	373870425664
    
    7205	51912025	374026140125
    
    7206	51926436	374181897816
    
    7207	51940849	374337698743
    
    7208	51955264	374493542912
    
    7209	51969681	374649430329
    
    7210	51984100	374805361000
    
    7211	51998521	374961334931
    
    7212	52012944	375117352128
    
    7213	52027369	375273412597
    
    7214	52041796	375429516344
    
    7215	52056225	375585663375
    
    7216	52070656	375741853696
    
    7217	52085089	375898087313
    
    7218	52099524	376054364232
    
    7219	52113961	376210684459
    
    7220	52128400	376367048000
    
    7221	52142841	376523454861
    
    7222	52157284	376679905048
    
    7223	52171729	376836398567
    
    7224	52186176	376992935424
    
    7225	52200625	377149515625
    
    7226	52215076	377306139176
    
    7227	52229529	377462806083
    
    7228	52243984	377619516352
    
    7229	52258441	377776269989
    
    7230	52272900	377933067000
    
    7231	52287361	378089907391
    
    7232	52301824	378246791168
    
    7233	52316289	378403718337
    
    7234	52330756	378560688904
    
    7235	52345225	378717702875
    
    7236	52359696	378874760256
    
    7237	52374169	379031861053
    
    7238	52388644	379189005272
    
    7239	52403121	379346192919
    
    7240	52417600	379503424000
    
    7241	52432081	379660698521
    
    7242	52446564	379818016488
    
    7243	52461049	379975377907
    
    7244	52475536	380132782784
    
    7245	52490025	380290231125
    
    7246	52504516	380447722936
    
    7247	52519009	380605258223
    
    7248	52533504	380762836992
    
    7249	52548001	380920459249
    
    7250	52562500	381078125000
    
    7251	52577001	381235834251
    
    7252	52591504	381393587008
    
    7253	52606009	381551383277
    
    7254	52620516	381709223064
    
    7255	52635025	381867106375
    
    7256	52649536	382025033216
    
    7257	52664049	382183003593
    
    7258	52678564	382341017512
    
    7259	52693081	382499074979
    
    7260	52707600	382657176000
    
    7261	52722121	382815320581
    
    7262	52736644	382973508728
    
    7263	52751169	383131740447
    
    7264	52765696	383290015744
    
    7265	52780225	383448334625
    
    7266	52794756	383606697096
    
    7267	52809289	383765103163
    
    7268	52823824	383923552832
    
    7269	52838361	384082046109
    
    7270	52852900	384240583000
    
    7271	52867441	384399163511
    
    7272	52881984	384557787648
    
    7273	52896529	384716455417
    
    7274	52911076	384875166824
    
    7275	52925625	385033921875
    
    7276	52940176	385192720576
    
    7277	52954729	385351562933
    
    7278	52969284	385510448952
    
    7279	52983841	385669378639
    
    7280	52998400	385828352000
    
    7281	53012961	385987369041
    
    7282	53027524	386146429768
    
    7283	53042089	386305534187
    
    7284	53056656	386464682304
    
    7285	53071225	386623874125
    
    7286	53085796	386783109656
    
    7287	53100369	386942388903
    
    7288	53114944	387101711872
    
    7289	53129521	387261078569
    
    7290	53144100	387420489000
    
    7291	53158681	387579943171
    
    7292	53173264	387739441088
    
    7293	53187849	387898982757
    
    7294	53202436	388058568184
    
    7295	53217025	388218197375
    
    7296	53231616	388377870336
    
    7297	53246209	388537587073
    
    7298	53260804	388697347592
    
    7299	53275401	388857151899
    
    7300	53290000	389017000000
    
    7301	53304601	389176891901
    
    7302	53319204	389336827608
    
    7303	53333809	389496807127
    
    7304	53348416	389656830464
    
    7305	53363025	389816897625
    
    7306	53377636	389977008616
    
    7307	53392249	390137163443
    
    7308	53406864	390297362112
    
    7309	53421481	390457604629
    
    7310	53436100	390617891000
    
    7311	53450721	390778221231
    
    7312	53465344	390938595328
    
    7313	53479969	391099013297
    
    7314	53494596	391259475144
    
    7315	53509225	391419980875
    
    7316	53523856	391580530496
    
    7317	53538489	391741124013
    
    7318	53553124	391901761432
    
    7319	53567761	392062442759
    
    7320	53582400	392223168000
    
    7321	53597041	392383937161
    
    7322	53611684	392544750248
    
    7323	53626329	392705607267
    
    7324	53640976	392866508224
    
    7325	53655625	393027453125
    
    7326	53670276	393188441976
    
    7327	53684929	393349474783
    
    7328	53699584	393510551552
    
    7329	53714241	393671672289
    
    7330	53728900	393832837000
    
    7331	53743561	393994045691
    
    7332	53758224	394155298368
    
    7333	53772889	394316595037
    
    7334	53787556	394477935704
    
    7335	53802225	394639320375
    
    7336	53816896	394800749056
    
    7337	53831569	394962221753
    
    7338	53846244	395123738472
    
    7339	53860921	395285299219
    
    7340	53875600	395446904000
    
    7341	53890281	395608552821
    
    7342	53904964	395770245688
    
    7343	53919649	395931982607
    
    7344	53934336	396093763584
    
    7345	53949025	396255588625
    
    7346	53963716	396417457736
    
    7347	53978409	396579370923
    
    7348	53993104	396741328192
    
    7349	54007801	396903329549
    
    7350	54022500	397065375000
    
    7351	54037201	397227464551
    
    7352	54051904	397389598208
    
    7353	54066609	397551775977
    
    7354	54081316	397713997864
    
    7355	54096025	397876263875
    
    7356	54110736	398038574016
    
    7357	54125449	398200928293
    
    7358	54140164	398363326712
    
    7359	54154881	398525769279
    
    7360	54169600	398688256000
    
    7361	54184321	398850786881
    
    7362	54199044	399013361928
    
    7363	54213769	399175981147
    
    7364	54228496	399338644544
    
    7365	54243225	399501352125
    
    7366	54257956	399664103896
    
    7367	54272689	399826899863
    
    7368	54287424	399989740032
    
    7369	54302161	400152624409
    
    7370	54316900	400315553000
    
    7371	54331641	400478525811
    
    7372	54346384	400641542848
    
    7373	54361129	400804604117
    
    7374	54375876	400967709624
    
    7375	54390625	401130859375
    
    7376	54405376	401294053376
    
    7377	54420129	401457291633
    
    7378	54434884	401620574152
    
    7379	54449641	401783900939
    
    7380	54464400	401947272000
    
    7381	54479161	402110687341
    
    7382	54493924	402274146968
    
    7383	54508689	402437650887
    
    7384	54523456	402601199104
    
    7385	54538225	402764791625
    
    7386	54552996	402928428456
    
    7387	54567769	403092109603
    
    7388	54582544	403255835072
    
    7389	54597321	403419604869
    
    7390	54612100	403583419000
    
    7391	54626881	403747277471
    
    7392	54641664	403911180288
    
    7393	54656449	404075127457
    
    7394	54671236	404239118984
    
    7395	54686025	404403154875
    
    7396	54700816	404567235136
    
    7397	54715609	404731359773
    
    7398	54730404	404895528792
    
    7399	54745201	405059742199
    
    7400	54760000	405224000000
    
    7401	54774801	405388302201
    
    7402	54789604	405552648808
    
    7403	54804409	405717039827
    
    7404	54819216	405881475264
    
    7405	54834025	406045955125
    
    7406	54848836	406210479416
    
    7407	54863649	406375048143
    
    7408	54878464	406539661312
    
    7409	54893281	406704318929
    
    7410	54908100	406869021000
    
    7411	54922921	407033767531
    
    7412	54937744	407198558528
    
    7413	54952569	407363393997
    
    7414	54967396	407528273944
    
    7415	54982225	407693198375
    
    7416	54997056	407858167296
    
    7417	55011889	408023180713
    
    7418	55026724	408188238632
    
    7419	55041561	408353341059
    
    7420	55056400	408518488000
    
    7421	55071241	408683679461
    
    7422	55086084	408848915448
    
    7423	55100929	409014195967
    
    7424	55115776	409179521024
    
    7425	55130625	409344890625
    
    7426	55145476	409510304776
    
    7427	55160329	409675763483
    
    7428	55175184	409841266752
    
    7429	55190041	410006814589
    
    7430	55204900	410172407000
    
    7431	55219761	410338043991
    
    7432	55234624	410503725568
    
    7433	55249489	410669451737
    
    7434	55264356	410835222504
    
    7435	55279225	411001037875
    
    7436	55294096	411166897856
    
    7437	55308969	411332802453
    
    7438	55323844	411498751672
    
    7439	55338721	411664745519
    
    7440	55353600	411830784000
    
    7441	55368481	411996867121
    
    7442	55383364	412162994888
    
    7443	55398249	412329167307
    
    7444	55413136	412495384384
    
    7445	55428025	412661646125
    
    7446	55442916	412827952536
    
    7447	55457809	412994303623
    
    7448	55472704	413160699392
    
    7449	55487601	413327139849
    
    7450	55502500	413493625000
    
    7451	55517401	413660154851
    
    7452	55532304	413826729408
    
    7453	55547209	413993348677
    
    7454	55562116	414160012664
    
    7455	55577025	414326721375
    
    7456	55591936	414493474816
    
    7457	55606849	414660272993
    
    7458	55621764	414827115912
    
    7459	55636681	414994003579
    
    7460	55651600	415160936000
    
    7461	55666521	415327913181
    
    7462	55681444	415494935128
    
    7463	55696369	415662001847
    
    7464	55711296	415829113344
    
    7465	55726225	415996269625
    
    7466	55741156	416163470696
    
    7467	55756089	416330716563
    
    7468	55771024	416498007232
    
    7469	55785961	416665342709
    
    7470	55800900	416832723000
    
    7471	55815841	417000148111
    
    7472	55830784	417167618048
    
    7473	55845729	417335132817
    
    7474	55860676	417502692424
    
    7475	55875625	417670296875
    
    7476	55890576	417837946176
    
    7477	55905529	418005640333
    
    7478	55920484	418173379352
    
    7479	55935441	418341163239
    
    7480	55950400	418508992000
    
    7481	55965361	418676865641
    
    7482	55980324	418844784168
    
    7483	55995289	419012747587
    
    7484	56010256	419180755904
    
    7485	56025225	419348809125
    
    7486	56040196	419516907256
    
    7487	56055169	419685050303
    
    7488	56070144	419853238272
    
    7489	56085121	420021471169
    
    7490	56100100	420189749000
    
    7491	56115081	420358071771
    
    7492	56130064	420526439488
    
    7493	56145049	420694852157
    
    7494	56160036	420863309784
    
    7495	56175025	421031812375
    
    7496	56190016	421200359936
    
    7497	56205009	421368952473
    
    7498	56220004	421537589992
    
    7499	56235001	421706272499
    
    7500	56250000	421875000000
    
    7501	56265001	422043772501
    
    7502	56280004	422212590008
    
    7503	56295009	422381452527
    
    7504	56310016	422550360064
    
    7505	56325025	422719312625
    
    7506	56340036	422888310216
    
    7507	56355049	423057352843
    
    7508	56370064	423226440512
    
    7509	56385081	423395573229
    
    7510	56400100	423564751000
    
    7511	56415121	423733973831
    
    7512	56430144	423903241728
    
    7513	56445169	424072554697
    
    7514	56460196	424241912744
    
    7515	56475225	424411315875
    
    7516	56490256	424580764096
    
    7517	56505289	424750257413
    
    7518	56520324	424919795832
    
    7519	56535361	425089379359
    
    7520	56550400	425259008000
    
    7521	56565441	425428681761
    
    7522	56580484	425598400648
    
    7523	56595529	425768164667
    
    7524	56610576	425937973824
    
    7525	56625625	426107828125
    
    7526	56640676	426277727576
    
    7527	56655729	426447672183
    
    7528	56670784	426617661952
    
    7529	56685841	426787696889
    
    7530	56700900	426957777000
    
    7531	56715961	427127902291
    
    7532	56731024	427298072768
    
    7533	56746089	427468288437
    
    7534	56761156	427638549304
    
    7535	56776225	427808855375
    
    7536	56791296	427979206656
    
    7537	56806369	428149603153
    
    7538	56821444	428320044872
    
    7539	56836521	428490531819
    
    7540	56851600	428661064000
    
    7541	56866681	428831641421
    
    7542	56881764	429002264088
    
    7543	56896849	429172932007
    
    7544	56911936	429343645184
    
    7545	56927025	429514403625
    
    7546	56942116	429685207336
    
    7547	56957209	429856056323
    
    7548	56972304	430026950592
    
    7549	56987401	430197890149
    
    7550	57002500	430368875000
    
    7551	57017601	430539905151
    
    7552	57032704	430710980608
    
    7553	57047809	430882101377
    
    7554	57062916	431053267464
    
    7555	57078025	431224478875
    
    7556	57093136	431395735616
    
    7557	57108249	431567037693
    
    7558	57123364	431738385112
    
    7559	57138481	431909777879
    
    7560	57153600	432081216000
    
    7561	57168721	432252699481
    
    7562	57183844	432424228328
    
    7563	57198969	432595802547
    
    7564	57214096	432767422144
    
    7565	57229225	432939087125
    
    7566	57244356	433110797496
    
    7567	57259489	433282553263
    
    7568	57274624	433454354432
    
    7569	57289761	433626201009
    
    7570	57304900	433798093000
    
    7571	57320041	433970030411
    
    7572	57335184	434142013248
    
    7573	57350329	434314041517
    
    7574	57365476	434486115224
    
    7575	57380625	434658234375
    
    7576	57395776	434830398976
    
    7577	57410929	435002609033
    
    7578	57426084	435174864552
    
    7579	57441241	435347165539
    
    7580	57456400	435519512000
    
    7581	57471561	435691903941
    
    7582	57486724	435864341368
    
    7583	57501889	436036824287
    
    7584	57517056	436209352704
    
    7585	57532225	436381926625
    
    7586	57547396	436554546056
    
    7587	57562569	436727211003
    
    7588	57577744	436899921472
    
    7589	57592921	437072677469
    
    7590	57608100	437245479000
    
    7591	57623281	437418326071
    
    7592	57638464	437591218688
    
    7593	57653649	437764156857
    
    7594	57668836	437937140584
    
    7595	57684025	438110169875
    
    7596	57699216	438283244736
    
    7597	57714409	438456365173
    
    7598	57729604	438629531192
    
    7599	57744801	438802742799
    
    7600	57760000	438976000000
    
    7601	57775201	439149302801
    
    7602	57790404	439322651208
    
    7603	57805609	439496045227
    
    7604	57820816	439669484864
    
    7605	57836025	439842970125
    
    7606	57851236	440016501016
    
    7607	57866449	440190077543
    
    7608	57881664	440363699712
    
    7609	57896881	440537367529
    
    7610	57912100	440711081000
    
    7611	57927321	440884840131
    
    7612	57942544	441058644928
    
    7613	57957769	441232495397
    
    7614	57972996	441406391544
    
    7615	57988225	441580333375
    
    7616	58003456	441754320896
    
    7617	58018689	441928354113
    
    7618	58033924	442102433032
    
    7619	58049161	442276557659
    
    7620	58064400	442450728000
    
    7621	58079641	442624944061
    
    7622	58094884	442799205848
    
    7623	58110129	442973513367
    
    7624	58125376	443147866624
    
    7625	58140625	443322265625
    
    7626	58155876	443496710376
    
    7627	58171129	443671200883
    
    7628	58186384	443845737152
    
    7629	58201641	444020319189
    
    7630	58216900	444194947000
    
    7631	58232161	444369620591
    
    7632	58247424	444544339968
    
    7633	58262689	444719105137
    
    7634	58277956	444893916104
    
    7635	58293225	445068772875
    
    7636	58308496	445243675456
    
    7637	58323769	445418623853
    
    7638	58339044	445593618072
    
    7639	58354321	445768658119
    
    7640	58369600	445943744000
    
    7641	58384881	446118875721
    
    7642	58400164	446294053288
    
    7643	58415449	446469276707
    
    7644	58430736	446644545984
    
    7645	58446025	446819861125
    
    7646	58461316	446995222136
    
    7647	58476609	447170629023
    
    7648	58491904	447346081792
    
    7649	58507201	447521580449
    
    7650	58522500	447697125000
    
    7651	58537801	447872715451
    
    7652	58553104	448048351808
    
    7653	58568409	448224034077
    
    7654	58583716	448399762264
    
    7655	58599025	448575536375
    
    7656	58614336	448751356416
    
    7657	58629649	448927222393
    
    7658	58644964	449103134312
    
    7659	58660281	449279092179
    
    7660	58675600	449455096000
    
    7661	58690921	449631145781
    
    7662	58706244	449807241528
    
    7663	58721569	449983383247
    
    7664	58736896	450159570944
    
    7665	58752225	450335804625
    
    7666	58767556	450512084296
    
    7667	58782889	450688409963
    
    7668	58798224	450864781632
    
    7669	58813561	451041199309
    
    7670	58828900	451217663000
    
    7671	58844241	451394172711
    
    7672	58859584	451570728448
    
    7673	58874929	451747330217
    
    7674	58890276	451923978024
    
    7675	58905625	452100671875
    
    7676	58920976	452277411776
    
    7677	58936329	452454197733
    
    7678	58951684	452631029752
    
    7679	58967041	452807907839
    
    7680	58982400	452984832000
    
    7681	58997761	453161802241
    
    7682	59013124	453338818568
    
    7683	59028489	453515880987
    
    7684	59043856	453692989504
    
    7685	59059225	453870144125
    
    7686	59074596	454047344856
    
    7687	59089969	454224591703
    
    7688	59105344	454401884672
    
    7689	59120721	454579223769
    
    7690	59136100	454756609000
    
    7691	59151481	454934040371
    
    7692	59166864	455111517888
    
    7693	59182249	455289041557
    
    7694	59197636	455466611384
    
    7695	59213025	455644227375
    
    7696	59228416	455821889536
    
    7697	59243809	455999597873
    
    7698	59259204	456177352392
    
    7699	59274601	456355153099
    
    7700	59290000	456533000000
    
    7701	59305401	456710893101
    
    7702	59320804	456888832408
    
    7703	59336209	457066817927
    
    7704	59351616	457244849664
    
    7705	59367025	457422927625
    
    7706	59382436	457601051816
    
    7707	59397849	457779222243
    
    7708	59413264	457957438912
    
    7709	59428681	458135701829
    
    7710	59444100	458314011000
    
    7711	59459521	458492366431
    
    7712	59474944	458670768128
    
    7713	59490369	458849216097
    
    7714	59505796	459027710344
    
    7715	59521225	459206250875
    
    7716	59536656	459384837696
    
    7717	59552089	459563470813
    
    7718	59567524	459742150232
    
    7719	59582961	459920875959
    
    7720	59598400	460099648000
    
    7721	59613841	460278466361
    
    7722	59629284	460457331048
    
    7723	59644729	460636242067
    
    7724	59660176	460815199424
    
    7725	59675625	460994203125
    
    7726	59691076	461173253176
    
    7727	59706529	461352349583
    
    7728	59721984	461531492352
    
    7729	59737441	461710681489
    
    7730	59752900	461889917000
    
    7731	59768361	462069198891
    
    7732	59783824	462248527168
    
    7733	59799289	462427901837
    
    7734	59814756	462607322904
    
    7735	59830225	462786790375
    
    7736	59845696	462966304256
    
    7737	59861169	463145864553
    
    7738	59876644	463325471272
    
    7739	59892121	463505124419
    
    7740	59907600	463684824000
    
    7741	59923081	463864570021
    
    7742	59938564	464044362488
    
    7743	59954049	464224201407
    
    7744	59969536	464404086784
    
    7745	59985025	464584018625
    
    7746	60000516	464763996936
    
    7747	60016009	464944021723
    
    7748	60031504	465124092992
    
    7749	60047001	465304210749
    
    7750	60062500	465484375000
    
    7751	60078001	465664585751
    
    7752	60093504	465844843008
    
    7753	60109009	466025146777
    
    7754	60124516	466205497064
    
    7755	60140025	466385893875
    
    7756	60155536	466566337216
    
    7757	60171049	466746827093
    
    7758	60186564	466927363512
    
    7759	60202081	467107946479
    
    7760	60217600	467288576000
    
    7761	60233121	467469252081
    
    7762	60248644	467649974728
    
    7763	60264169	467830743947
    
    7764	60279696	468011559744
    
    7765	60295225	468192422125
    
    7766	60310756	468373331096
    
    7767	60326289	468554286663
    
    7768	60341824	468735288832
    
    7769	60357361	468916337609
    
    7770	60372900	469097433000
    
    7771	60388441	469278575011
    
    7772	60403984	469459763648
    
    7773	60419529	469640998917
    
    7774	60435076	469822280824
    
    7775	60450625	470003609375
    
    7776	60466176	470184984576
    
    7777	60481729	470366406433
    
    7778	60497284	470547874952
    
    7779	60512841	470729390139
    
    7780	60528400	470910952000
    
    7781	60543961	471092560541
    
    7782	60559524	471274215768
    
    7783	60575089	471455917687
    
    7784	60590656	471637666304
    
    7785	60606225	471819461625
    
    7786	60621796	472001303656
    
    7787	60637369	472183192403
    
    7788	60652944	472365127872
    
    7789	60668521	472547110069
    
    7790	60684100	472729139000
    
    7791	60699681	472911214671
    
    7792	60715264	473093337088
    
    7793	60730849	473275506257
    
    7794	60746436	473457722184
    
    7795	60762025	473639984875
    
    7796	60777616	473822294336
    
    7797	60793209	474004650573
    
    7798	60808804	474187053592
    
    7799	60824401	474369503399
    
    7800	60840000	474552000000
    
    7801	60855601	474734543401
    
    7802	60871204	474917133608
    
    7803	60886809	475099770627
    
    7804	60902416	475282454464
    
    7805	60918025	475465185125
    
    7806	60933636	475647962616
    
    7807	60949249	475830786943
    
    7808	60964864	476013658112
    
    7809	60980481	476196576129
    
    7810	60996100	476379541000
    
    7811	61011721	476562552731
    
    7812	61027344	476745611328
    
    7813	61042969	476928716797
    
    7814	61058596	477111869144
    
    7815	61074225	477295068375
    
    7816	61089856	477478314496
    
    7817	61105489	477661607513
    
    7818	61121124	477844947432
    
    7819	61136761	478028334259
    
    7820	61152400	478211768000
    
    7821	61168041	478395248661
    
    7822	61183684	478578776248
    
    7823	61199329	478762350767
    
    7824	61214976	478945972224
    
    7825	61230625	479129640625
    
    7826	61246276	479313355976
    
    7827	61261929	479497118283
    
    7828	61277584	479680927552
    
    7829	61293241	479864783789
    
    7830	61308900	480048687000
    
    7831	61324561	480232637191
    
    7832	61340224	480416634368
    
    7833	61355889	480600678537
    
    7834	61371556	480784769704
    
    7835	61387225	480968907875
    
    7836	61402896	481153093056
    
    7837	61418569	481337325253
    
    7838	61434244	481521604472
    
    7839	61449921	481705930719
    
    7840	61465600	481890304000
    
    7841	61481281	482074724321
    
    7842	61496964	482259191688
    
    7843	61512649	482443706107
    
    7844	61528336	482628267584
    
    7845	61544025	482812876125
    
    7846	61559716	482997531736
    
    7847	61575409	483182234423
    
    7848	61591104	483366984192
    
    7849	61606801	483551781049
    
    7850	61622500	483736625000
    
    7851	61638201	483921516051
    
    7852	61653904	484106454208
    
    7853	61669609	484291439477
    
    7854	61685316	484476471864
    
    7855	61701025	484661551375
    
    7856	61716736	484846678016
    
    7857	61732449	485031851793
    
    7858	61748164	485217072712
    
    7859	61763881	485402340779
    
    7860	61779600	485587656000
    
    7861	61795321	485773018381
    
    7862	61811044	485958427928
    
    7863	61826769	486143884647
    
    7864	61842496	486329388544
    
    7865	61858225	486514939625
    
    7866	61873956	486700537896
    
    7867	61889689	486886183363
    
    7868	61905424	487071876032
    
    7869	61921161	487257615909
    
    7870	61936900	487443403000
    
    7871	61952641	487629237311
    
    7872	61968384	487815118848
    
    7873	61984129	488001047617
    
    7874	61999876	488187023624
    
    7875	62015625	488373046875
    
    7876	62031376	488559117376
    
    7877	62047129	488745235133
    
    7878	62062884	488931400152
    
    7879	62078641	489117612439
    
    7880	62094400	489303872000
    
    7881	62110161	489490178841
    
    7882	62125924	489676532968
    
    7883	62141689	489862934387
    
    7884	62157456	490049383104
    
    7885	62173225	490235879125
    
    7886	62188996	490422422456
    
    7887	62204769	490609013103
    
    7888	62220544	490795651072
    
    7889	62236321	490982336369
    
    7890	62252100	491169069000
    
    7891	62267881	491355848971
    
    7892	62283664	491542676288
    
    7893	62299449	491729550957
    
    7894	62315236	491916472984
    
    7895	62331025	492103442375
    
    7896	62346816	492290459136
    
    7897	62362609	492477523273
    
    7898	62378404	492664634792
    
    7899	62394201	492851793699
    
    7900	62410000	493039000000
    
    7901	62425801	493226253701
    
    7902	62441604	493413554808
    
    7903	62457409	493600903327
    
    7904	62473216	493788299264
    
    7905	62489025	493975742625
    
    7906	62504836	494163233416
    
    7907	62520649	494350771643
    
    7908	62536464	494538357312
    
    7909	62552281	494725990429
    
    7910	62568100	494913671000
    
    7911	62583921	495101399031
    
    7912	62599744	495289174528
    
    7913	62615569	495476997497
    
    7914	62631396	495664867944
    
    7915	62647225	495852785875
    
    7916	62663056	496040751296
    
    7917	62678889	496228764213
    
    7918	62694724	496416824632
    
    7919	62710561	496604932559
    
    7920	62726400	496793088000
    
    7921	62742241	496981290961
    
    7922	62758084	497169541448
    
    7923	62773929	497357839467
    
    7924	62789776	497546185024
    
    7925	62805625	497734578125
    
    7926	62821476	497923018776
    
    7927	62837329	498111506983
    
    7928	62853184	498300042752
    
    7929	62869041	498488626089
    
    7930	62884900	498677257000
    
    7931	62900761	498865935491
    
    7932	62916624	499054661568
    
    7933	62932489	499243435237
    
    7934	62948356	499432256504
    
    7935	62964225	499621125375
    
    7936	62980096	499810041856
    
    7937	62995969	499999005953
    
    7938	63011844	500188017672
    
    7939	63027721	500377077019
    
    7940	63043600	500566184000
    
    7941	63059481	500755338621
    
    7942	63075364	500944540888
    
    7943	63091249	501133790807
    
    7944	63107136	501323088384
    
    7945	63123025	501512433625
    
    7946	63138916	501701826536
    
    7947	63154809	501891267123
    
    7948	63170704	502080755392
    
    7949	63186601	502270291349
    
    7950	63202500	502459875000
    
    7951	63218401	502649506351
    
    7952	63234304	502839185408
    
    7953	63250209	503028912177
    
    7954	63266116	503218686664
    
    7955	63282025	503408508875
    
    7956	63297936	503598378816
    
    7957	63313849	503788296493
    
    7958	63329764	503978261912
    
    7959	63345681	504168275079
    
    7960	63361600	504358336000
    
    7961	63377521	504548444681
    
    7962	63393444	504738601128
    
    7963	63409369	504928805347
    
    7964	63425296	505119057344
    
    7965	63441225	505309357125
    
    7966	63457156	505499704696
    
    7967	63473089	505690100063
    
    7968	63489024	505880543232
    
    7969	63504961	506071034209
    
    7970	63520900	506261573000
    
    7971	63536841	506452159611
    
    7972	63552784	506642794048
    
    7973	63568729	506833476317
    
    7974	63584676	507024206424
    
    7975	63600625	507214984375
    
    7976	63616576	507405810176
    
    7977	63632529	507596683833
    
    7978	63648484	507787605352
    
    7979	63664441	507978574739
    
    7980	63680400	508169592000
    
    7981	63696361	508360657141
    
    7982	63712324	508551770168
    
    7983	63728289	508742931087
    
    7984	63744256	508934139904
    
    7985	63760225	509125396625
    
    7986	63776196	509316701256
    
    7987	63792169	509508053803
    
    7988	63808144	509699454272
    
    7989	63824121	509890902669
    
    7990	63840100	510082399000
    
    7991	63856081	510273943271
    
    7992	63872064	510465535488
    
    7993	63888049	510657175657
    
    7994	63904036	510848863784
    
    7995	63920025	511040599875
    
    7996	63936016	511232383936
    
    7997	63952009	511424215973
    
    7998	63968004	511616095992
    
    7999	63984001	511808023999
    
    8000	64000000	512000000000
    
    8001	64016001	512192024001
    
    8002	64032004	512384096008
    
    8003	64048009	512576216027
    
    8004	64064016	512768384064
    
    8005	64080025	512960600125
    
    8006	64096036	513152864216
    
    8007	64112049	513345176343
    
    8008	64128064	513537536512
    
    8009	64144081	513729944729
    
    8010	64160100	513922401000
    
    8011	64176121	514114905331
    
    8012	64192144	514307457728
    
    8013	64208169	514500058197
    
    8014	64224196	514692706744
    
    8015	64240225	514885403375
    
    8016	64256256	515078148096
    
    8017	64272289	515270940913
    
    8018	64288324	515463781832
    
    8019	64304361	515656670859
    
    8020	64320400	515849608000
    
    8021	64336441	516042593261
    
    8022	64352484	516235626648
    
    8023	64368529	516428708167
    
    8024	64384576	516621837824
    
    8025	64400625	516815015625
    
    8026	64416676	517008241576
    
    8027	64432729	517201515683
    
    8028	64448784	517394837952
    
    8029	64464841	517588208389
    
    8030	64480900	517781627000
    
    8031	64496961	517975093791
    
    8032	64513024	518168608768
    
    8033	64529089	518362171937
    
    8034	64545156	518555783304
    
    8035	64561225	518749442875
    
    8036	64577296	518943150656
    
    8037	64593369	519136906653
    
    8038	64609444	519330710872
    
    8039	64625521	519524563319
    
    8040	64641600	519718464000
    
    8041	64657681	519912412921
    
    8042	64673764	520106410088
    
    8043	64689849	520300455507
    
    8044	64705936	520494549184
    
    8045	64722025	520688691125
    
    8046	64738116	520882881336
    
    8047	64754209	521077119823
    
    8048	64770304	521271406592
    
    8049	64786401	521465741649
    
    8050	64802500	521660125000
    
    8051	64818601	521854556651
    
    8052	64834704	522049036608
    
    8053	64850809	522243564877
    
    8054	64866916	522438141464
    
    8055	64883025	522632766375
    
    8056	64899136	522827439616
    
    8057	64915249	523022161193
    
    8058	64931364	523216931112
    
    8059	64947481	523411749379
    
    8060	64963600	523606616000
    
    8061	64979721	523801530981
    
    8062	64995844	523996494328
    
    8063	65011969	524191506047
    
    8064	65028096	524386566144
    
    8065	65044225	524581674625
    
    8066	65060356	524776831496
    
    8067	65076489	524972036763
    
    8068	65092624	525167290432
    
    8069	65108761	525362592509
    
    8070	65124900	525557943000
    
    8071	65141041	525753341911
    
    8072	65157184	525948789248
    
    8073	65173329	526144285017
    
    8074	65189476	526339829224
    
    8075	65205625	526535421875
    
    8076	65221776	526731062976
    
    8077	65237929	526926752533
    
    8078	65254084	527122490552
    
    8079	65270241	527318277039
    
    8080	65286400	527514112000
    
    8081	65302561	527709995441
    
    8082	65318724	527905927368
    
    8083	65334889	528101907787
    
    8084	65351056	528297936704
    
    8085	65367225	528494014125
    
    8086	65383396	528690140056
    
    8087	65399569	528886314503
    
    8088	65415744	529082537472
    
    8089	65431921	529278808969
    
    8090	65448100	529475129000
    
    8091	65464281	529671497571
    
    8092	65480464	529867914688
    
    8093	65496649	530064380357
    
    8094	65512836	530260894584
    
    8095	65529025	530457457375
    
    8096	65545216	530654068736
    
    8097	65561409	530850728673
    
    8098	65577604	531047437192
    
    8099	65593801	531244194299
    
    8100	65610000	531441000000
    
    8101	65626201	531637854301
    
    8102	65642404	531834757208
    
    8103	65658609	532031708727
    
    8104	65674816	532228708864
    
    8105	65691025	532425757625
    
    8106	65707236	532622855016
    
    8107	65723449	532820001043
    
    8108	65739664	533017195712
    
    8109	65755881	533214439029
    
    8110	65772100	533411731000
    
    8111	65788321	533609071631
    
    8112	65804544	533806460928
    
    8113	65820769	534003898897
    
    8114	65836996	534201385544
    
    8115	65853225	534398920875
    
    8116	65869456	534596504896
    
    8117	65885689	534794137613
    
    8118	65901924	534991819032
    
    8119	65918161	535189549159
    
    8120	65934400	535387328000
    
    8121	65950641	535585155561
    
    8122	65966884	535783031848
    
    8123	65983129	535980956867
    
    8124	65999376	536178930624
    
    8125	66015625	536376953125
    
    8126	66031876	536575024376
    
    8127	66048129	536773144383
    
    8128	66064384	536971313152
    
    8129	66080641	537169530689
    
    8130	66096900	537367797000
    
    8131	66113161	537566112091
    
    8132	66129424	537764475968
    
    8133	66145689	537962888637
    
    8134	66161956	538161350104
    
    8135	66178225	538359860375
    
    8136	66194496	538558419456
    
    8137	66210769	538757027353
    
    8138	66227044	538955684072
    
    8139	66243321	539154389619
    
    8140	66259600	539353144000
    
    8141	66275881	539551947221
    
    8142	66292164	539750799288
    
    8143	66308449	539949700207
    
    8144	66324736	540148649984
    
    8145	66341025	540347648625
    
    8146	66357316	540546696136
    
    8147	66373609	540745792523
    
    8148	66389904	540944937792
    
    8149	66406201	541144131949
    
    8150	66422500	541343375000
    
    8151	66438801	541542666951
    
    8152	66455104	541742007808
    
    8153	66471409	541941397577
    
    8154	66487716	542140836264
    
    8155	66504025	542340323875
    
    8156	66520336	542539860416
    
    8157	66536649	542739445893
    
    8158	66552964	542939080312
    
    8159	66569281	543138763679
    
    8160	66585600	543338496000
    
    8161	66601921	543538277281
    
    8162	66618244	543738107528
    
    8163	66634569	543937986747
    
    8164	66650896	544137914944
    
    8165	66667225	544337892125
    
    8166	66683556	544537918296
    
    8167	66699889	544737993463
    
    8168	66716224	544938117632
    
    8169	66732561	545138290809
    
    8170	66748900	545338513000
    
    8171	66765241	545538784211
    
    8172	66781584	545739104448
    
    8173	66797929	545939473717
    
    8174	66814276	546139892024
    
    8175	66830625	546340359375
    
    8176	66846976	546540875776
    
    8177	66863329	546741441233
    
    8178	66879684	546942055752
    
    8179	66896041	547142719339
    
    8180	66912400	547343432000
    
    8181	66928761	547544193741
    
    8182	66945124	547745004568
    
    8183	66961489	547945864487
    
    8184	66977856	548146773504
    
    8185	66994225	548347731625
    
    8186	67010596	548548738856
    
    8187	67026969	548749795203
    
    8188	67043344	548950900672
    
    8189	67059721	549152055269
    
    8190	67076100	549353259000
    
    8191	67092481	549554511871
    
    8192	67108864	549755813888
    
    8193	67125249	549957165057
    
    8194	67141636	550158565384
    
    8195	67158025	550360014875
    
    8196	67174416	550561513536
    
    8197	67190809	550763061373
    
    8198	67207204	550964658392
    
    8199	67223601	551166304599
    
    8200	67240000	551368000000
    
    8201	67256401	551569744601
    
    8202	67272804	551771538408
    
    8203	67289209	551973381427
    
    8204	67305616	552175273664
    
    8205	67322025	552377215125
    
    8206	67338436	552579205816
    
    8207	67354849	552781245743
    
    8208	67371264	552983334912
    
    8209	67387681	553185473329
    
    8210	67404100	553387661000
    
    8211	67420521	553589897931
    
    8212	67436944	553792184128
    
    8213	67453369	553994519597
    
    8214	67469796	554196904344
    
    8215	67486225	554399338375
    
    8216	67502656	554601821696
    
    8217	67519089	554804354313
    
    8218	67535524	555006936232
    
    8219	67551961	555209567459
    
    8220	67568400	555412248000
    
    8221	67584841	555614977861
    
    8222	67601284	555817757048
    
    8223	67617729	556020585567
    
    8224	67634176	556223463424
    
    8225	67650625	556426390625
    
    8226	67667076	556629367176
    
    8227	67683529	556832393083
    
    8228	67699984	557035468352
    
    8229	67716441	557238592989
    
    8230	67732900	557441767000
    
    8231	67749361	557644990391
    
    8232	67765824	557848263168
    
    8233	67782289	558051585337
    
    8234	67798756	558254956904
    
    8235	67815225	558458377875
    
    8236	67831696	558661848256
    
    8237	67848169	558865368053
    
    8238	67864644	559068937272
    
    8239	67881121	559272555919
    
    8240	67897600	559476224000
    
    8241	67914081	559679941521
    
    8242	67930564	559883708488
    
    8243	67947049	560087524907
    
    8244	67963536	560291390784
    
    8245	67980025	560495306125
    
    8246	67996516	560699270936
    
    8247	68013009	560903285223
    
    8248	68029504	561107348992
    
    8249	68046001	561311462249
    
    8250	68062500	561515625000
    
    8251	68079001	561719837251
    
    8252	68095504	561924099008
    
    8253	68112009	562128410277
    
    8254	68128516	562332771064
    
    8255	68145025	562537181375
    
    8256	68161536	562741641216
    
    8257	68178049	562946150593
    
    8258	68194564	563150709512
    
    8259	68211081	563355317979
    
    8260	68227600	563559976000
    
    8261	68244121	563764683581
    
    8262	68260644	563969440728
    
    8263	68277169	564174247447
    
    8264	68293696	564379103744
    
    8265	68310225	564584009625
    
    8266	68326756	564788965096
    
    8267	68343289	564993970163
    
    8268	68359824	565199024832
    
    8269	68376361	565404129109
    
    8270	68392900	565609283000
    
    8271	68409441	565814486511
    
    8272	68425984	566019739648
    
    8273	68442529	566225042417
    
    8274	68459076	566430394824
    
    8275	68475625	566635796875
    
    8276	68492176	566841248576
    
    8277	68508729	567046749933
    
    8278	68525284	567252300952
    
    8279	68541841	567457901639
    
    8280	68558400	567663552000
    
    8281	68574961	567869252041
    
    8282	68591524	568075001768
    
    8283	68608089	568280801187
    
    8284	68624656	568486650304
    
    8285	68641225	568692549125
    
    8286	68657796	568898497656
    
    8287	68674369	569104495903
    
    8288	68690944	569310543872
    
    8289	68707521	569516641569
    
    8290	68724100	569722789000
    
    8291	68740681	569928986171
    
    8292	68757264	570135233088
    
    8293	68773849	570341529757
    
    8294	68790436	570547876184
    
    8295	68807025	570754272375
    
    8296	68823616	570960718336
    
    8297	68840209	571167214073
    
    8298	68856804	571373759592
    
    8299	68873401	571580354899
    
    8300	68890000	571787000000
    
    8301	68906601	571993694901
    
    8302	68923204	572200439608
    
    8303	68939809	572407234127
    
    8304	68956416	572614078464
    
    8305	68973025	572820972625
    
    8306	68989636	573027916616
    
    8307	69006249	573234910443
    
    8308	69022864	573441954112
    
    8309	69039481	573649047629
    
    8310	69056100	573856191000
    
    8311	69072721	574063384231
    
    8312	69089344	574270627328
    
    8313	69105969	574477920297
    
    8314	69122596	574685263144
    
    8315	69139225	574892655875
    
    8316	69155856	575100098496
    
    8317	69172489	575307591013
    
    8318	69189124	575515133432
    
    8319	69205761	575722725759
    
    8320	69222400	575930368000
    
    8321	69239041	576138060161
    
    8322	69255684	576345802248
    
    8323	69272329	576553594267
    
    8324	69288976	576761436224
    
    8325	69305625	576969328125
    
    8326	69322276	577177269976
    
    8327	69338929	577385261783
    
    8328	69355584	577593303552
    
    8329	69372241	577801395289
    
    8330	69388900	578009537000
    
    8331	69405561	578217728691
    
    8332	69422224	578425970368
    
    8333	69438889	578634262037
    
    8334	69455556	578842603704
    
    8335	69472225	579050995375
    
    8336	69488896	579259437056
    
    8337	69505569	579467928753
    
    8338	69522244	579676470472
    
    8339	69538921	579885062219
    
    8340	69555600	580093704000
    
    8341	69572281	580302395821
    
    8342	69588964	580511137688
    
    8343	69605649	580719929607
    
    8344	69622336	580928771584
    
    8345	69639025	581137663625
    
    8346	69655716	581346605736
    
    8347	69672409	581555597923
    
    8348	69689104	581764640192
    
    8349	69705801	581973732549
    
    8350	69722500	582182875000
    
    8351	69739201	582392067551
    
    8352	69755904	582601310208
    
    8353	69772609	582810602977
    
    8354	69789316	583019945864
    
    8355	69806025	583229338875
    
    8356	69822736	583438782016
    
    8357	69839449	583648275293
    
    8358	69856164	583857818712
    
    8359	69872881	584067412279
    
    8360	69889600	584277056000
    
    8361	69906321	584486749881
    
    8362	69923044	584696493928
    
    8363	69939769	584906288147
    
    8364	69956496	585116132544
    
    8365	69973225	585326027125
    
    8366	69989956	585535971896
    
    8367	70006689	585745966863
    
    8368	70023424	585956012032
    
    8369	70040161	586166107409
    
    8370	70056900	586376253000
    
    8371	70073641	586586448811
    
    8372	70090384	586796694848
    
    8373	70107129	587006991117
    
    8374	70123876	587217337624
    
    8375	70140625	587427734375
    
    8376	70157376	587638181376
    
    8377	70174129	587848678633
    
    8378	70190884	588059226152
    
    8379	70207641	588269823939
    
    8380	70224400	588480472000
    
    8381	70241161	588691170341
    
    8382	70257924	588901918968
    
    8383	70274689	589112717887
    
    8384	70291456	589323567104
    
    8385	70308225	589534466625
    
    8386	70324996	589745416456
    
    8387	70341769	589956416603
    
    8388	70358544	590167467072
    
    8389	70375321	590378567869
    
    8390	70392100	590589719000
    
    8391	70408881	590800920471
    
    8392	70425664	591012172288
    
    8393	70442449	591223474457
    
    8394	70459236	591434826984
    
    8395	70476025	591646229875
    
    8396	70492816	591857683136
    
    8397	70509609	592069186773
    
    8398	70526404	592280740792
    
    8399	70543201	592492345199
    
    8400	70560000	592704000000
    
    8401	70576801	592915705201
    
    8402	70593604	593127460808
    
    8403	70610409	593339266827
    
    8404	70627216	593551123264
    
    8405	70644025	593763030125
    
    8406	70660836	593974987416
    
    8407	70677649	594186995143
    
    8408	70694464	594399053312
    
    8409	70711281	594611161929
    
    8410	70728100	594823321000
    
    8411	70744921	595035530531
    
    8412	70761744	595247790528
    
    8413	70778569	595460100997
    
    8414	70795396	595672461944
    
    8415	70812225	595884873375
    
    8416	70829056	596097335296
    
    8417	70845889	596309847713
    
    8418	70862724	596522410632
    
    8419	70879561	596735024059
    
    8420	70896400	596947688000
    
    8421	70913241	597160402461
    
    8422	70930084	597373167448
    
    8423	70946929	597585982967
    
    8424	70963776	597798849024
    
    8425	70980625	598011765625
    
    8426	70997476	598224732776
    
    8427	71014329	598437750483
    
    8428	71031184	598650818752
    
    8429	71048041	598863937589
    
    8430	71064900	599077107000
    
    8431	71081761	599290326991
    
    8432	71098624	599503597568
    
    8433	71115489	599716918737
    
    8434	71132356	599930290504
    
    8435	71149225	600143712875
    
    8436	71166096	600357185856
    
    8437	71182969	600570709453
    
    8438	71199844	600784283672
    
    8439	71216721	600997908519
    
    8440	71233600	601211584000
    
    8441	71250481	601425310121
    
    8442	71267364	601639086888
    
    8443	71284249	601852914307
    
    8444	71301136	602066792384
    
    8445	71318025	602280721125
    
    8446	71334916	602494700536
    
    8447	71351809	602708730623
    
    8448	71368704	602922811392
    
    8449	71385601	603136942849
    
    8450	71402500	603351125000
    
    8451	71419401	603565357851
    
    8452	71436304	603779641408
    
    8453	71453209	603993975677
    
    8454	71470116	604208360664
    
    8455	71487025	604422796375
    
    8456	71503936	604637282816
    
    8457	71520849	604851819993
    
    8458	71537764	605066407912
    
    8459	71554681	605281046579
    
    8460	71571600	605495736000
    
    8461	71588521	605710476181
    
    8462	71605444	605925267128
    
    8463	71622369	606140108847
    
    8464	71639296	606355001344
    
    8465	71656225	606569944625
    
    8466	71673156	606784938696
    
    8467	71690089	606999983563
    
    8468	71707024	607215079232
    
    8469	71723961	607430225709
    
    8470	71740900	607645423000
    
    8471	71757841	607860671111
    
    8472	71774784	608075970048
    
    8473	71791729	608291319817
    
    8474	71808676	608506720424
    
    8475	71825625	608722171875
    
    8476	71842576	608937674176
    
    8477	71859529	609153227333
    
    8478	71876484	609368831352
    
    8479	71893441	609584486239
    
    8480	71910400	609800192000
    
    8481	71927361	610015948641
    
    8482	71944324	610231756168
    
    8483	71961289	610447614587
    
    8484	71978256	610663523904
    
    8485	71995225	610879484125
    
    8486	72012196	611095495256
    
    8487	72029169	611311557303
    
    8488	72046144	611527670272
    
    8489	72063121	611743834169
    
    8490	72080100	611960049000
    
    8491	72097081	612176314771
    
    8492	72114064	612392631488
    
    8493	72131049	612608999157
    
    8494	72148036	612825417784
    
    8495	72165025	613041887375
    
    8496	72182016	613258407936
    
    8497	72199009	613474979473
    
    8498	72216004	613691601992
    
    8499	72233001	613908275499
    
    8500	72250000	614125000000
    
    8501	72267001	614341775501
    
    8502	72284004	614558602008
    
    8503	72301009	614775479527
    
    8504	72318016	614992408064
    
    8505	72335025	615209387625
    
    8506	72352036	615426418216
    
    8507	72369049	615643499843
    
    8508	72386064	615860632512
    
    8509	72403081	616077816229
    
    8510	72420100	616295051000
    
    8511	72437121	616512336831
    
    8512	72454144	616729673728
    
    8513	72471169	616947061697
    
    8514	72488196	617164500744
    
    8515	72505225	617381990875
    
    8516	72522256	617599532096
    
    8517	72539289	617817124413
    
    8518	72556324	618034767832
    
    8519	72573361	618252462359
    
    8520	72590400	618470208000
    
    8521	72607441	618688004761
    
    8522	72624484	618905852648
    
    8523	72641529	619123751667
    
    8524	72658576	619341701824
    
    8525	72675625	619559703125
    
    8526	72692676	619777755576
    
    8527	72709729	619995859183
    
    8528	72726784	620214013952
    
    8529	72743841	620432219889
    
    8530	72760900	620650477000
    
    8531	72777961	620868785291
    
    8532	72795024	621087144768
    
    8533	72812089	621305555437
    
    8534	72829156	621524017304
    
    8535	72846225	621742530375
    
    8536	72863296	621961094656
    
    8537	72880369	622179710153
    
    8538	72897444	622398376872
    
    8539	72914521	622617094819
    
    8540	72931600	622835864000
    
    8541	72948681	623054684421
    
    8542	72965764	623273556088
    
    8543	72982849	623492479007
    
    8544	72999936	623711453184
    
    8545	73017025	623930478625
    
    8546	73034116	624149555336
    
    8547	73051209	624368683323
    
    8548	73068304	624587862592
    
    8549	73085401	624807093149
    
    8550	73102500	625026375000
    
    8551	73119601	625245708151
    
    8552	73136704	625465092608
    
    8553	73153809	625684528377
    
    8554	73170916	625904015464
    
    8555	73188025	626123553875
    
    8556	73205136	626343143616
    
    8557	73222249	626562784693
    
    8558	73239364	626782477112
    
    8559	73256481	627002220879
    
    8560	73273600	627222016000
    
    8561	73290721	627441862481
    
    8562	73307844	627661760328
    
    8563	73324969	627881709547
    
    8564	73342096	628101710144
    
    8565	73359225	628321762125
    
    8566	73376356	628541865496
    
    8567	73393489	628762020263
    
    8568	73410624	628982226432
    
    8569	73427761	629202484009
    
    8570	73444900	629422793000
    
    8571	73462041	629643153411
    
    8572	73479184	629863565248
    
    8573	73496329	630084028517
    
    8574	73513476	630304543224
    
    8575	73530625	630525109375
    
    8576	73547776	630745726976
    
    8577	73564929	630966396033
    
    8578	73582084	631187116552
    
    8579	73599241	631407888539
    
    8580	73616400	631628712000
    
    8581	73633561	631849586941
    
    8582	73650724	632070513368
    
    8583	73667889	632291491287
    
    8584	73685056	632512520704
    
    8585	73702225	632733601625
    
    8586	73719396	632954734056
    
    8587	73736569	633175918003
    
    8588	73753744	633397153472
    
    8589	73770921	633618440469
    
    8590	73788100	633839779000
    
    8591	73805281	634061169071
    
    8592	73822464	634282610688
    
    8593	73839649	634504103857
    
    8594	73856836	634725648584
    
    8595	73874025	634947244875
    
    8596	73891216	635168892736
    
    8597	73908409	635390592173
    
    8598	73925604	635612343192
    
    8599	73942801	635834145799
    
    8600	73960000	636056000000
    
    8601	73977201	636277905801
    
    8602	73994404	636499863208
    
    8603	74011609	636721872227
    
    8604	74028816	636943932864
    
    8605	74046025	637166045125
    
    8606	74063236	637388209016
    
    8607	74080449	637610424543
    
    8608	74097664	637832691712
    
    8609	74114881	638055010529
    
    8610	74132100	638277381000
    
    8611	74149321	638499803131
    
    8612	74166544	638722276928
    
    8613	74183769	638944802397
    
    8614	74200996	639167379544
    
    8615	74218225	639390008375
    
    8616	74235456	639612688896
    
    8617	74252689	639835421113
    
    8618	74269924	640058205032
    
    8619	74287161	640281040659
    
    8620	74304400	640503928000
    
    8621	74321641	640726867061
    
    8622	74338884	640949857848
    
    8623	74356129	641172900367
    
    8624	74373376	641395994624
    
    8625	74390625	641619140625
    
    8626	74407876	641842338376
    
    8627	74425129	642065587883
    
    8628	74442384	642288889152
    
    8629	74459641	642512242189
    
    8630	74476900	642735647000
    
    8631	74494161	642959103591
    
    8632	74511424	643182611968
    
    8633	74528689	643406172137
    
    8634	74545956	643629784104
    
    8635	74563225	643853447875
    
    8636	74580496	644077163456
    
    8637	74597769	644300930853
    
    8638	74615044	644524750072
    
    8639	74632321	644748621119
    
    8640	74649600	644972544000
    
    8641	74666881	645196518721
    
    8642	74684164	645420545288
    
    8643	74701449	645644623707
    
    8644	74718736	645868753984
    
    8645	74736025	646092936125
    
    8646	74753316	646317170136
    
    8647	74770609	646541456023
    
    8648	74787904	646765793792
    
    8649	74805201	646990183449
    
    8650	74822500	647214625000
    
    8651	74839801	647439118451
    
    8652	74857104	647663663808
    
    8653	74874409	647888261077
    
    8654	74891716	648112910264
    
    8655	74909025	648337611375
    
    8656	74926336	648562364416
    
    8657	74943649	648787169393
    
    8658	74960964	649012026312
    
    8659	74978281	649236935179
    
    8660	74995600	649461896000
    
    8661	75012921	649686908781
    
    8662	75030244	649911973528
    
    8663	75047569	650137090247
    
    8664	75064896	650362258944
    
    8665	75082225	650587479625
    
    8666	75099556	650812752296
    
    8667	75116889	651038076963
    
    8668	75134224	651263453632
    
    8669	75151561	651488882309
    
    8670	75168900	651714363000
    
    8671	75186241	651939895711
    
    8672	75203584	652165480448
    
    8673	75220929	652391117217
    
    8674	75238276	652616806024
    
    8675	75255625	652842546875
    
    8676	75272976	653068339776
    
    8677	75290329	653294184733
    
    8678	75307684	653520081752
    
    8679	75325041	653746030839
    
    8680	75342400	653972032000
    
    8681	75359761	654198085241
    
    8682	75377124	654424190568
    
    8683	75394489	654650347987
    
    8684	75411856	654876557504
    
    8685	75429225	655102819125
    
    8686	75446596	655329132856
    
    8687	75463969	655555498703
    
    8688	75481344	655781916672
    
    8689	75498721	656008386769
    
    8690	75516100	656234909000
    
    8691	75533481	656461483371
    
    8692	75550864	656688109888
    
    8693	75568249	656914788557
    
    8694	75585636	657141519384
    
    8695	75603025	657368302375
    
    8696	75620416	657595137536
    
    8697	75637809	657822024873
    
    8698	75655204	658048964392
    
    8699	75672601	658275956099
    
    8700	75690000	658503000000
    
    8701	75707401	658730096101
    
    8702	75724804	658957244408
    
    8703	75742209	659184444927
    
    8704	75759616	659411697664
    
    8705	75777025	659639002625
    
    8706	75794436	659866359816
    
    8707	75811849	660093769243
    
    8708	75829264	660321230912
    
    8709	75846681	660548744829
    
    8710	75864100	660776311000
    
    8711	75881521	661003929431
    
    8712	75898944	661231600128
    
    8713	75916369	661459323097
    
    8714	75933796	661687098344
    
    8715	75951225	661914925875
    
    8716	75968656	662142805696
    
    8717	75986089	662370737813
    
    8718	76003524	662598722232
    
    8719	76020961	662826758959
    
    8720	76038400	663054848000
    
    8721	76055841	663282989361
    
    8722	76073284	663511183048
    
    8723	76090729	663739429067
    
    8724	76108176	663967727424
    
    8725	76125625	664196078125
    
    8726	76143076	664424481176
    
    8727	76160529	664652936583
    
    8728	76177984	664881444352
    
    8729	76195441	665110004489
    
    8730	76212900	665338617000
    
    8731	76230361	665567281891
    
    8732	76247824	665795999168
    
    8733	76265289	666024768837
    
    8734	76282756	666253590904
    
    8735	76300225	666482465375
    
    8736	76317696	666711392256
    
    8737	76335169	666940371553
    
    8738	76352644	667169403272
    
    8739	76370121	667398487419
    
    8740	76387600	667627624000
    
    8741	76405081	667856813021
    
    8742	76422564	668086054488
    
    8743	76440049	668315348407
    
    8744	76457536	668544694784
    
    8745	76475025	668774093625
    
    8746	76492516	669003544936
    
    8747	76510009	669233048723
    
    8748	76527504	669462604992
    
    8749	76545001	669692213749
    
    8750	76562500	669921875000
    
    8751	76580001	670151588751
    
    8752	76597504	670381355008
    
    8753	76615009	670611173777
    
    8754	76632516	670841045064
    
    8755	76650025	671070968875
    
    8756	76667536	671300945216
    
    8757	76685049	671530974093
    
    8758	76702564	671761055512
    
    8759	76720081	671991189479
    
    8760	76737600	672221376000
    
    8761	76755121	672451615081
    
    8762	76772644	672681906728
    
    8763	76790169	672912250947
    
    8764	76807696	673142647744
    
    8765	76825225	673373097125
    
    8766	76842756	673603599096
    
    8767	76860289	673834153663
    
    8768	76877824	674064760832
    
    8769	76895361	674295420609
    
    8770	76912900	674526133000
    
    8771	76930441	674756898011
    
    8772	76947984	674987715648
    
    8773	76965529	675218585917
    
    8774	76983076	675449508824
    
    8775	77000625	675680484375
    
    8776	77018176	675911512576
    
    8777	77035729	676142593433
    
    8778	77053284	676373726952
    
    8779	77070841	676604913139
    
    8780	77088400	676836152000
    
    8781	77105961	677067443541
    
    8782	77123524	677298787768
    
    8783	77141089	677530184687
    
    8784	77158656	677761634304
    
    8785	77176225	677993136625
    
    8786	77193796	678224691656
    
    8787	77211369	678456299403
    
    8788	77228944	678687959872
    
    8789	77246521	678919673069
    
    8790	77264100	679151439000
    
    8791	77281681	679383257671
    
    8792	77299264	679615129088
    
    8793	77316849	679847053257
    
    8794	77334436	680079030184
    
    8795	77352025	680311059875
    
    8796	77369616	680543142336
    
    8797	77387209	680775277573
    
    8798	77404804	681007465592
    
    8799	77422401	681239706399
    
    8800	77440000	681472000000
    
    8801	77457601	681704346401
    
    8802	77475204	681936745608
    
    8803	77492809	682169197627
    
    8804	77510416	682401702464
    
    8805	77528025	682634260125
    
    8806	77545636	682866870616
    
    8807	77563249	683099533943
    
    8808	77580864	683332250112
    
    8809	77598481	683565019129
    
    8810	77616100	683797841000
    
    8811	77633721	684030715731
    
    8812	77651344	684263643328
    
    8813	77668969	684496623797
    
    8814	77686596	684729657144
    
    8815	77704225	684962743375
    
    8816	77721856	685195882496
    
    8817	77739489	685429074513
    
    8818	77757124	685662319432
    
    8819	77774761	685895617259
    
    8820	77792400	686128968000
    
    8821	77810041	686362371661
    
    8822	77827684	686595828248
    
    8823	77845329	686829337767
    
    8824	77862976	687062900224
    
    8825	77880625	687296515625
    
    8826	77898276	687530183976
    
    8827	77915929	687763905283
    
    8828	77933584	687997679552
    
    8829	77951241	688231506789
    
    8830	77968900	688465387000
    
    8831	77986561	688699320191
    
    8832	78004224	688933306368
    
    8833	78021889	689167345537
    
    8834	78039556	689401437704
    
    8835	78057225	689635582875
    
    8836	78074896	689869781056
    
    8837	78092569	690104032253
    
    8838	78110244	690338336472
    
    8839	78127921	690572693719
    
    8840	78145600	690807104000
    
    8841	78163281	691041567321
    
    8842	78180964	691276083688
    
    8843	78198649	691510653107
    
    8844	78216336	691745275584
    
    8845	78234025	691979951125
    
    8846	78251716	692214679736
    
    8847	78269409	692449461423
    
    8848	78287104	692684296192
    
    8849	78304801	692919184049
    
    8850	78322500	693154125000
    
    8851	78340201	693389119051
    
    8852	78357904	693624166208
    
    8853	78375609	693859266477
    
    8854	78393316	694094419864
    
    8855	78411025	694329626375
    
    8856	78428736	694564886016
    
    8857	78446449	694800198793
    
    8858	78464164	695035564712
    
    8859	78481881	695270983779
    
    8860	78499600	695506456000
    
    8861	78517321	695741981381
    
    8862	78535044	695977559928
    
    8863	78552769	696213191647
    
    8864	78570496	696448876544
    
    8865	78588225	696684614625
    
    8866	78605956	696920405896
    
    8867	78623689	697156250363
    
    8868	78641424	697392148032
    
    8869	78659161	697628098909
    
    8870	78676900	697864103000
    
    8871	78694641	698100160311
    
    8872	78712384	698336270848
    
    8873	78730129	698572434617
    
    8874	78747876	698808651624
    
    8875	78765625	699044921875
    
    8876	78783376	699281245376
    
    8877	78801129	699517622133
    
    8878	78818884	699754052152
    
    8879	78836641	699990535439
    
    8880	78854400	700227072000
    
    8881	78872161	700463661841
    
    8882	78889924	700700304968
    
    8883	78907689	700937001387
    
    8884	78925456	701173751104
    
    8885	78943225	701410554125
    
    8886	78960996	701647410456
    
    8887	78978769	701884320103
    
    8888	78996544	702121283072
    
    8889	79014321	702358299369
    
    8890	79032100	702595369000
    
    8891	79049881	702832491971
    
    8892	79067664	703069668288
    
    8893	79085449	703306897957
    
    8894	79103236	703544180984
    
    8895	79121025	703781517375
    
    8896	79138816	704018907136
    
    8897	79156609	704256350273
    
    8898	79174404	704493846792
    
    8899	79192201	704731396699
    
    8900	79210000	704969000000
    
    8901	79227801	705206656701
    
    8902	79245604	705444366808
    
    8903	79263409	705682130327
    
    8904	79281216	705919947264
    
    8905	79299025	706157817625
    
    8906	79316836	706395741416
    
    8907	79334649	706633718643
    
    8908	79352464	706871749312
    
    8909	79370281	707109833429
    
    8910	79388100	707347971000
    
    8911	79405921	707586162031
    
    8912	79423744	707824406528
    
    8913	79441569	708062704497
    
    8914	79459396	708301055944
    
    8915	79477225	708539460875
    
    8916	79495056	708777919296
    
    8917	79512889	709016431213
    
    8918	79530724	709254996632
    
    8919	79548561	709493615559
    
    8920	79566400	709732288000
    
    8921	79584241	709971013961
    
    8922	79602084	710209793448
    
    8923	79619929	710448626467
    
    8924	79637776	710687513024
    
    8925	79655625	710926453125
    
    8926	79673476	711165446776
    
    8927	79691329	711404493983
    
    8928	79709184	711643594752
    
    8929	79727041	711882749089
    
    8930	79744900	712121957000
    
    8931	79762761	712361218491
    
    8932	79780624	712600533568
    
    8933	79798489	712839902237
    
    8934	79816356	713079324504
    
    8935	79834225	713318800375
    
    8936	79852096	713558329856
    
    8937	79869969	713797912953
    
    8938	79887844	714037549672
    
    8939	79905721	714277240019
    
    8940	79923600	714516984000
    
    8941	79941481	714756781621
    
    8942	79959364	714996632888
    
    8943	79977249	715236537807
    
    8944	79995136	715476496384
    
    8945	80013025	715716508625
    
    8946	80030916	715956574536
    
    8947	80048809	716196694123
    
    8948	80066704	716436867392
    
    8949	80084601	716677094349
    
    8950	80102500	716917375000
    
    8951	80120401	717157709351
    
    8952	80138304	717398097408
    
    8953	80156209	717638539177
    
    8954	80174116	717879034664
    
    8955	80192025	718119583875
    
    8956	80209936	718360186816
    
    8957	80227849	718600843493
    
    8958	80245764	718841553912
    
    8959	80263681	719082318079
    
    8960	80281600	719323136000
    
    8961	80299521	719564007681
    
    8962	80317444	719804933128
    
    8963	80335369	720045912347
    
    8964	80353296	720286945344
    
    8965	80371225	720528032125
    
    8966	80389156	720769172696
    
    8967	80407089	721010367063
    
    8968	80425024	721251615232
    
    8969	80442961	721492917209
    
    8970	80460900	721734273000
    
    8971	80478841	721975682611
    
    8972	80496784	722217146048
    
    8973	80514729	722458663317
    
    8974	80532676	722700234424
    
    8975	80550625	722941859375
    
    8976	80568576	723183538176
    
    8977	80586529	723425270833
    
    8978	80604484	723667057352
    
    8979	80622441	723908897739
    
    8980	80640400	724150792000
    
    8981	80658361	724392740141
    
    8982	80676324	724634742168
    
    8983	80694289	724876798087
    
    8984	80712256	725118907904
    
    8985	80730225	725361071625
    
    8986	80748196	725603289256
    
    8987	80766169	725845560803
    
    8988	80784144	726087886272
    
    8989	80802121	726330265669
    
    8990	80820100	726572699000
    
    8991	80838081	726815186271
    
    8992	80856064	727057727488
    
    8993	80874049	727300322657
    
    8994	80892036	727542971784
    
    8995	80910025	727785674875
    
    8996	80928016	728028431936
    
    8997	80946009	728271242973
    
    8998	80964004	728514107992
    
    8999	80982001	728757026999
    
    9000	81000000	729000000000
    
    9001	81018001	729243027001
    
    9002	81036004	729486108008
    
    9003	81054009	729729243027
    
    9004	81072016	729972432064
    
    9005	81090025	730215675125
    
    9006	81108036	730458972216
    
    9007	81126049	730702323343
    
    9008	81144064	730945728512
    
    9009	81162081	731189187729
    
    9010	81180100	731432701000
    
    9011	81198121	731676268331
    
    9012	81216144	731919889728
    
    9013	81234169	732163565197
    
    9014	81252196	732407294744
    
    9015	81270225	732651078375
    
    9016	81288256	732894916096
    
    9017	81306289	733138807913
    
    9018	81324324	733382753832
    
    9019	81342361	733626753859
    
    9020	81360400	733870808000
    
    9021	81378441	734114916261
    
    9022	81396484	734359078648
    
    9023	81414529	734603295167
    
    9024	81432576	734847565824
    
    9025	81450625	735091890625
    
    9026	81468676	735336269576
    
    9027	81486729	735580702683
    
    9028	81504784	735825189952
    
    9029	81522841	736069731389
    
    9030	81540900	736314327000
    
    9031	81558961	736558976791
    
    9032	81577024	736803680768
    
    9033	81595089	737048438937
    
    9034	81613156	737293251304
    
    9035	81631225	737538117875
    
    9036	81649296	737783038656
    
    9037	81667369	738028013653
    
    9038	81685444	738273042872
    
    9039	81703521	738518126319
    
    9040	81721600	738763264000
    
    9041	81739681	739008455921
    
    9042	81757764	739253702088
    
    9043	81775849	739499002507
    
    9044	81793936	739744357184
    
    9045	81812025	739989766125
    
    9046	81830116	740235229336
    
    9047	81848209	740480746823
    
    9048	81866304	740726318592
    
    9049	81884401	740971944649
    
    9050	81902500	741217625000
    
    9051	81920601	741463359651
    
    9052	81938704	741709148608
    
    9053	81956809	741954991877
    
    9054	81974916	742200889464
    
    9055	81993025	742446841375
    
    9056	82011136	742692847616
    
    9057	82029249	742938908193
    
    9058	82047364	743185023112
    
    9059	82065481	743431192379
    
    9060	82083600	743677416000
    
    9061	82101721	743923693981
    
    9062	82119844	744170026328
    
    9063	82137969	744416413047
    
    9064	82156096	744662854144
    
    9065	82174225	744909349625
    
    9066	82192356	745155899496
    
    9067	82210489	745402503763
    
    9068	82228624	745649162432
    
    9069	82246761	745895875509
    
    9070	82264900	746142643000
    
    9071	82283041	746389464911
    
    9072	82301184	746636341248
    
    9073	82319329	746883272017
    
    9074	82337476	747130257224
    
    9075	82355625	747377296875
    
    9076	82373776	747624390976
    
    9077	82391929	747871539533
    
    9078	82410084	748118742552
    
    9079	82428241	748366000039
    
    9080	82446400	748613312000
    
    9081	82464561	748860678441
    
    9082	82482724	749108099368
    
    9083	82500889	749355574787
    
    9084	82519056	749603104704
    
    9085	82537225	749850689125
    
    9086	82555396	750098328056
    
    9087	82573569	750346021503
    
    9088	82591744	750593769472
    
    9089	82609921	750841571969
    
    9090	82628100	751089429000
    
    9091	82646281	751337340571
    
    9092	82664464	751585306688
    
    9093	82682649	751833327357
    
    9094	82700836	752081402584
    
    9095	82719025	752329532375
    
    9096	82737216	752577716736
    
    9097	82755409	752825955673
    
    9098	82773604	753074249192
    
    9099	82791801	753322597299
    
    9100	82810000	753571000000
    
    9101	82828201	753819457301
    
    9102	82846404	754067969208
    
    9103	82864609	754316535727
    
    9104	82882816	754565156864
    
    9105	82901025	754813832625
    
    9106	82919236	755062563016
    
    9107	82937449	755311348043
    
    9108	82955664	755560187712
    
    9109	82973881	755809082029
    
    9110	82992100	756058031000
    
    9111	83010321	756307034631
    
    9112	83028544	756556092928
    
    9113	83046769	756805205897
    
    9114	83064996	757054373544
    
    9115	83083225	757303595875
    
    9116	83101456	757552872896
    
    9117	83119689	757802204613
    
    9118	83137924	758051591032
    
    9119	83156161	758301032159
    
    9120	83174400	758550528000
    
    9121	83192641	758800078561
    
    9122	83210884	759049683848
    
    9123	83229129	759299343867
    
    9124	83247376	759549058624
    
    9125	83265625	759798828125
    
    9126	83283876	760048652376
    
    9127	83302129	760298531383
    
    9128	83320384	760548465152
    
    9129	83338641	760798453689
    
    9130	83356900	761048497000
    
    9131	83375161	761298595091
    
    9132	83393424	761548747968
    
    9133	83411689	761798955637
    
    9134	83429956	762049218104
    
    9135	83448225	762299535375
    
    9136	83466496	762549907456
    
    9137	83484769	762800334353
    
    9138	83503044	763050816072
    
    9139	83521321	763301352619
    
    9140	83539600	763551944000
    
    9141	83557881	763802590221
    
    9142	83576164	764053291288
    
    9143	83594449	764304047207
    
    9144	83612736	764554857984
    
    9145	83631025	764805723625
    
    9146	83649316	765056644136
    
    9147	83667609	765307619523
    
    9148	83685904	765558649792
    
    9149	83704201	765809734949
    
    9150	83722500	766060875000
    
    9151	83740801	766312069951
    
    9152	83759104	766563319808
    
    9153	83777409	766814624577
    
    9154	83795716	767065984264
    
    9155	83814025	767317398875
    
    9156	83832336	767568868416
    
    9157	83850649	767820392893
    
    9158	83868964	768071972312
    
    9159	83887281	768323606679
    
    9160	83905600	768575296000
    
    9161	83923921	768827040281
    
    9162	83942244	769078839528
    
    9163	83960569	769330693747
    
    9164	83978896	769582602944
    
    9165	83997225	769834567125
    
    9166	84015556	770086586296
    
    9167	84033889	770338660463
    
    9168	84052224	770590789632
    
    9169	84070561	770842973809
    
    9170	84088900	771095213000
    
    9171	84107241	771347507211
    
    9172	84125584	771599856448
    
    9173	84143929	771852260717
    
    9174	84162276	772104720024
    
    9175	84180625	772357234375
    
    9176	84198976	772609803776
    
    9177	84217329	772862428233
    
    9178	84235684	773115107752
    
    9179	84254041	773367842339
    
    9180	84272400	773620632000
    
    9181	84290761	773873476741
    
    9182	84309124	774126376568
    
    9183	84327489	774379331487
    
    9184	84345856	774632341504
    
    9185	84364225	774885406625
    
    9186	84382596	775138526856
    
    9187	84400969	775391702203
    
    9188	84419344	775644932672
    
    9189	84437721	775898218269
    
    9190	84456100	776151559000
    
    9191	84474481	776404954871
    
    9192	84492864	776658405888
    
    9193	84511249	776911912057
    
    9194	84529636	777165473384
    
    9195	84548025	777419089875
    
    9196	84566416	777672761536
    
    9197	84584809	777926488373
    
    9198	84603204	778180270392
    
    9199	84621601	778434107599
    
    9200	84640000	778688000000
    
    9201	84658401	778941947601
    
    9202	84676804	779195950408
    
    9203	84695209	779450008427
    
    9204	84713616	779704121664
    
    9205	84732025	779958290125
    
    9206	84750436	780212513816
    
    9207	84768849	780466792743
    
    9208	84787264	780721126912
    
    9209	84805681	780975516329
    
    9210	84824100	781229961000
    
    9211	84842521	781484460931
    
    9212	84860944	781739016128
    
    9213	84879369	781993626597
    
    9214	84897796	782248292344
    
    9215	84916225	782503013375
    
    9216	84934656	782757789696
    
    9217	84953089	783012621313
    
    9218	84971524	783267508232
    
    9219	84989961	783522450459
    
    9220	85008400	783777448000
    
    9221	85026841	784032500861
    
    9222	85045284	784287609048
    
    9223	85063729	784542772567
    
    9224	85082176	784797991424
    
    9225	85100625	785053265625
    
    9226	85119076	785308595176
    
    9227	85137529	785563980083
    
    9228	85155984	785819420352
    
    9229	85174441	786074915989
    
    9230	85192900	786330467000
    
    9231	85211361	786586073391
    
    9232	85229824	786841735168
    
    9233	85248289	787097452337
    
    9234	85266756	787353224904
    
    9235	85285225	787609052875
    
    9236	85303696	787864936256
    
    9237	85322169	788120875053
    
    9238	85340644	788376869272
    
    9239	85359121	788632918919
    
    9240	85377600	788889024000
    
    9241	85396081	789145184521
    
    9242	85414564	789401400488
    
    9243	85433049	789657671907
    
    9244	85451536	789913998784
    
    9245	85470025	790170381125
    
    9246	85488516	790426818936
    
    9247	85507009	790683312223
    
    9248	85525504	790939860992
    
    9249	85544001	791196465249
    
    9250	85562500	791453125000
    
    9251	85581001	791709840251
    
    9252	85599504	791966611008
    
    9253	85618009	792223437277
    
    9254	85636516	792480319064
    
    9255	85655025	792737256375
    
    9256	85673536	792994249216
    
    9257	85692049	793251297593
    
    9258	85710564	793508401512
    
    9259	85729081	793765560979
    
    9260	85747600	794022776000
    
    9261	85766121	794280046581
    
    9262	85784644	794537372728
    
    9263	85803169	794794754447
    
    9264	85821696	795052191744
    
    9265	85840225	795309684625
    
    9266	85858756	795567233096
    
    9267	85877289	795824837163
    
    9268	85895824	796082496832
    
    9269	85914361	796340212109
    
    9270	85932900	796597983000
    
    9271	85951441	796855809511
    
    9272	85969984	797113691648
    
    9273	85988529	797371629417
    
    9274	86007076	797629622824
    
    9275	86025625	797887671875
    
    9276	86044176	798145776576
    
    9277	86062729	798403936933
    
    9278	86081284	798662152952
    
    9279	86099841	798920424639
    
    9280	86118400	799178752000
    
    9281	86136961	799437135041
    
    9282	86155524	799695573768
    
    9283	86174089	799954068187
    
    9284	86192656	800212618304
    
    9285	86211225	800471224125
    
    9286	86229796	800729885656
    
    9287	86248369	800988602903
    
    9288	86266944	801247375872
    
    9289	86285521	801506204569
    
    9290	86304100	801765089000
    
    9291	86322681	802024029171
    
    9292	86341264	802283025088
    
    9293	86359849	802542076757
    
    9294	86378436	802801184184
    
    9295	86397025	803060347375
    
    9296	86415616	803319566336
    
    9297	86434209	803578841073
    
    9298	86452804	803838171592
    
    9299	86471401	804097557899
    
    9300	86490000	804357000000
    
    9301	86508601	804616497901
    
    9302	86527204	804876051608
    
    9303	86545809	805135661127
    
    9304	86564416	805395326464
    
    9305	86583025	805655047625
    
    9306	86601636	805914824616
    
    9307	86620249	806174657443
    
    9308	86638864	806434546112
    
    9309	86657481	806694490629
    
    9310	86676100	806954491000
    
    9311	86694721	807214547231
    
    9312	86713344	807474659328
    
    9313	86731969	807734827297
    
    9314	86750596	807995051144
    
    9315	86769225	808255330875
    
    9316	86787856	808515666496
    
    9317	86806489	808776058013
    
    9318	86825124	809036505432
    
    9319	86843761	809297008759
    
    9320	86862400	809557568000
    
    9321	86881041	809818183161
    
    9322	86899684	810078854248
    
    9323	86918329	810339581267
    
    9324	86936976	810600364224
    
    9325	86955625	810861203125
    
    9326	86974276	811122097976
    
    9327	86992929	811383048783
    
    9328	87011584	811644055552
    
    9329	87030241	811905118289
    
    9330	87048900	812166237000
    
    9331	87067561	812427411691
    
    9332	87086224	812688642368
    
    9333	87104889	812949929037
    
    9334	87123556	813211271704
    
    9335	87142225	813472670375
    
    9336	87160896	813734125056
    
    9337	87179569	813995635753
    
    9338	87198244	814257202472
    
    9339	87216921	814518825219
    
    9340	87235600	814780504000
    
    9341	87254281	815042238821
    
    9342	87272964	815304029688
    
    9343	87291649	815565876607
    
    9344	87310336	815827779584
    
    9345	87329025	816089738625
    
    9346	87347716	816351753736
    
    9347	87366409	816613824923
    
    9348	87385104	816875952192
    
    9349	87403801	817138135549
    
    9350	87422500	817400375000
    
    9351	87441201	817662670551
    
    9352	87459904	817925022208
    
    9353	87478609	818187429977
    
    9354	87497316	818449893864
    
    9355	87516025	818712413875
    
    9356	87534736	818974990016
    
    9357	87553449	819237622293
    
    9358	87572164	819500310712
    
    9359	87590881	819763055279
    
    9360	87609600	820025856000
    
    9361	87628321	820288712881
    
    9362	87647044	820551625928
    
    9363	87665769	820814595147
    
    9364	87684496	821077620544
    
    9365	87703225	821340702125
    
    9366	87721956	821603839896
    
    9367	87740689	821867033863
    
    9368	87759424	822130284032
    
    9369	87778161	822393590409
    
    9370	87796900	822656953000
    
    9371	87815641	822920371811
    
    9372	87834384	823183846848
    
    9373	87853129	823447378117
    
    9374	87871876	823710965624
    
    9375	87890625	823974609375
    
    9376	87909376	824238309376
    
    9377	87928129	824502065633
    
    9378	87946884	824765878152
    
    9379	87965641	825029746939
    
    9380	87984400	825293672000
    
    9381	88003161	825557653341
    
    9382	88021924	825821690968
    
    9383	88040689	826085784887
    
    9384	88059456	826349935104
    
    9385	88078225	826614141625
    
    9386	88096996	826878404456
    
    9387	88115769	827142723603
    
    9388	88134544	827407099072
    
    9389	88153321	827671530869
    
    9390	88172100	827936019000
    
    9391	88190881	828200563471
    
    9392	88209664	828465164288
    
    9393	88228449	828729821457
    
    9394	88247236	828994534984
    
    9395	88266025	829259304875
    
    9396	88284816	829524131136
    
    9397	88303609	829789013773
    
    9398	88322404	830053952792
    
    9399	88341201	830318948199
    
    9400	88360000	830584000000
    
    9401	88378801	830849108201
    
    9402	88397604	831114272808
    
    9403	88416409	831379493827
    
    9404	88435216	831644771264
    
    9405	88454025	831910105125
    
    9406	88472836	832175495416
    
    9407	88491649	832440942143
    
    9408	88510464	832706445312
    
    9409	88529281	832972004929
    
    9410	88548100	833237621000
    
    9411	88566921	833503293531
    
    9412	88585744	833769022528
    
    9413	88604569	834034807997
    
    9414	88623396	834300649944
    
    9415	88642225	834566548375
    
    9416	88661056	834832503296
    
    9417	88679889	835098514713
    
    9418	88698724	835364582632
    
    9419	88717561	835630707059
    
    9420	88736400	835896888000
    
    9421	88755241	836163125461
    
    9422	88774084	836429419448
    
    9423	88792929	836695769967
    
    9424	88811776	836962177024
    
    9425	88830625	837228640625
    
    9426	88849476	837495160776
    
    9427	88868329	837761737483
    
    9428	88887184	838028370752
    
    9429	88906041	838295060589
    
    9430	88924900	838561807000
    
    9431	88943761	838828609991
    
    9432	88962624	839095469568
    
    9433	88981489	839362385737
    
    9434	89000356	839629358504
    
    9435	89019225	839896387875
    
    9436	89038096	840163473856
    
    9437	89056969	840430616453
    
    9438	89075844	840697815672
    
    9439	89094721	840965071519
    
    9440	89113600	841232384000
    
    9441	89132481	841499753121
    
    9442	89151364	841767178888
    
    9443	89170249	842034661307
    
    9444	89189136	842302200384
    
    9445	89208025	842569796125
    
    9446	89226916	842837448536
    
    9447	89245809	843105157623
    
    9448	89264704	843372923392
    
    9449	89283601	843640745849
    
    9450	89302500	843908625000
    
    9451	89321401	844176560851
    
    9452	89340304	844444553408
    
    9453	89359209	844712602677
    
    9454	89378116	844980708664
    
    9455	89397025	845248871375
    
    9456	89415936	845517090816
    
    9457	89434849	845785366993
    
    9458	89453764	846053699912
    
    9459	89472681	846322089579
    
    9460	89491600	846590536000
    
    9461	89510521	846859039181
    
    9462	89529444	847127599128
    
    9463	89548369	847396215847
    
    9464	89567296	847664889344
    
    9465	89586225	847933619625
    
    9466	89605156	848202406696
    
    9467	89624089	848471250563
    
    9468	89643024	848740151232
    
    9469	89661961	849009108709
    
    9470	89680900	849278123000
    
    9471	89699841	849547194111
    
    9472	89718784	849816322048
    
    9473	89737729	850085506817
    
    9474	89756676	850354748424
    
    9475	89775625	850624046875
    
    9476	89794576	850893402176
    
    9477	89813529	851162814333
    
    9478	89832484	851432283352
    
    9479	89851441	851701809239
    
    9480	89870400	851971392000
    
    9481	89889361	852241031641
    
    9482	89908324	852510728168
    
    9483	89927289	852780481587
    
    9484	89946256	853050291904
    
    9485	89965225	853320159125
    
    9486	89984196	853590083256
    
    9487	90003169	853860064303
    
    9488	90022144	854130102272
    
    9489	90041121	854400197169
    
    9490	90060100	854670349000
    
    9491	90079081	854940557771
    
    9492	90098064	855210823488
    
    9493	90117049	855481146157
    
    9494	90136036	855751525784
    
    9495	90155025	856021962375
    
    9496	90174016	856292455936
    
    9497	90193009	856563006473
    
    9498	90212004	856833613992
    
    9499	90231001	857104278499
    
    9500	90250000	857375000000
    
    9501	90269001	857645778501
    
    9502	90288004	857916614008
    
    9503	90307009	858187506527
    
    9504	90326016	858458456064
    
    9505	90345025	858729462625
    
    9506	90364036	859000526216
    
    9507	90383049	859271646843
    
    9508	90402064	859542824512
    
    9509	90421081	859814059229
    
    9510	90440100	860085351000
    
    9511	90459121	860356699831
    
    9512	90478144	860628105728
    
    9513	90497169	860899568697
    
    9514	90516196	861171088744
    
    9515	90535225	861442665875
    
    9516	90554256	861714300096
    
    9517	90573289	861985991413
    
    9518	90592324	862257739832
    
    9519	90611361	862529545359
    
    9520	90630400	862801408000
    
    9521	90649441	863073327761
    
    9522	90668484	863345304648
    
    9523	90687529	863617338667
    
    9524	90706576	863889429824
    
    9525	90725625	864161578125
    
    9526	90744676	864433783576
    
    9527	90763729	864706046183
    
    9528	90782784	864978365952
    
    9529	90801841	865250742889
    
    9530	90820900	865523177000
    
    9531	90839961	865795668291
    
    9532	90859024	866068216768
    
    9533	90878089	866340822437
    
    9534	90897156	866613485304
    
    9535	90916225	866886205375
    
    9536	90935296	867158982656
    
    9537	90954369	867431817153
    
    9538	90973444	867704708872
    
    9539	90992521	867977657819
    
    9540	91011600	868250664000
    
    9541	91030681	868523727421
    
    9542	91049764	868796848088
    
    9543	91068849	869070026007
    
    9544	91087936	869343261184
    
    9545	91107025	869616553625
    
    9546	91126116	869889903336
    
    9547	91145209	870163310323
    
    9548	91164304	870436774592
    
    9549	91183401	870710296149
    
    9550	91202500	870983875000
    
    9551	91221601	871257511151
    
    9552	91240704	871531204608
    
    9553	91259809	871804955377
    
    9554	91278916	872078763464
    
    9555	91298025	872352628875
    
    9556	91317136	872626551616
    
    9557	91336249	872900531693
    
    9558	91355364	873174569112
    
    9559	91374481	873448663879
    
    9560	91393600	873722816000
    
    9561	91412721	873997025481
    
    9562	91431844	874271292328
    
    9563	91450969	874545616547
    
    9564	91470096	874819998144
    
    9565	91489225	875094437125
    
    9566	91508356	875368933496
    
    9567	91527489	875643487263
    
    9568	91546624	875918098432
    
    9569	91565761	876192767009
    
    9570	91584900	876467493000
    
    9571	91604041	876742276411
    
    9572	91623184	877017117248
    
    9573	91642329	877292015517
    
    9574	91661476	877566971224
    
    9575	91680625	877841984375
    
    9576	91699776	878117054976
    
    9577	91718929	878392183033
    
    9578	91738084	878667368552
    
    9579	91757241	878942611539
    
    9580	91776400	879217912000
    
    9581	91795561	879493269941
    
    9582	91814724	879768685368
    
    9583	91833889	880044158287
    
    9584	91853056	880319688704
    
    9585	91872225	880595276625
    
    9586	91891396	880870922056
    
    9587	91910569	881146625003
    
    9588	91929744	881422385472
    
    9589	91948921	881698203469
    
    9590	91968100	881974079000
    
    9591	91987281	882250012071
    
    9592	92006464	882526002688
    
    9593	92025649	882802050857
    
    9594	92044836	883078156584
    
    9595	92064025	883354319875
    
    9596	92083216	883630540736
    
    9597	92102409	883906819173
    
    9598	92121604	884183155192
    
    9599	92140801	884459548799
    
    9600	92160000	884736000000
    
    9601	92179201	885012508801
    
    9602	92198404	885289075208
    
    9603	92217609	885565699227
    
    9604	92236816	885842380864
    
    9605	92256025	886119120125
    
    9606	92275236	886395917016
    
    9607	92294449	886672771543
    
    9608	92313664	886949683712
    
    9609	92332881	887226653529
    
    9610	92352100	887503681000
    
    9611	92371321	887780766131
    
    9612	92390544	888057908928
    
    9613	92409769	888335109397
    
    9614	92428996	888612367544
    
    9615	92448225	888889683375
    
    9616	92467456	889167056896
    
    9617	92486689	889444488113
    
    9618	92505924	889721977032
    
    9619	92525161	889999523659
    
    9620	92544400	890277128000
    
    9621	92563641	890554790061
    
    9622	92582884	890832509848
    
    9623	92602129	891110287367
    
    9624	92621376	891388122624
    
    9625	92640625	891666015625
    
    9626	92659876	891943966376
    
    9627	92679129	892221974883
    
    9628	92698384	892500041152
    
    9629	92717641	892778165189
    
    9630	92736900	893056347000
    
    9631	92756161	893334586591
    
    9632	92775424	893612883968
    
    9633	92794689	893891239137
    
    9634	92813956	894169652104
    
    9635	92833225	894448122875
    
    9636	92852496	894726651456
    
    9637	92871769	895005237853
    
    9638	92891044	895283882072
    
    9639	92910321	895562584119
    
    9640	92929600	895841344000
    
    9641	92948881	896120161721
    
    9642	92968164	896399037288
    
    9643	92987449	896677970707
    
    9644	93006736	896956961984
    
    9645	93026025	897236011125
    
    9646	93045316	897515118136
    
    9647	93064609	897794283023
    
    9648	93083904	898073505792
    
    9649	93103201	898352786449
    
    9650	93122500	898632125000
    
    9651	93141801	898911521451
    
    9652	93161104	899190975808
    
    9653	93180409	899470488077
    
    9654	93199716	899750058264
    
    9655	93219025	900029686375
    
    9656	93238336	900309372416
    
    9657	93257649	900589116393
    
    9658	93276964	900868918312
    
    9659	93296281	901148778179
    
    9660	93315600	901428696000
    
    9661	93334921	901708671781
    
    9662	93354244	901988705528
    
    9663	93373569	902268797247
    
    9664	93392896	902548946944
    
    9665	93412225	902829154625
    
    9666	93431556	903109420296
    
    9667	93450889	903389743963
    
    9668	93470224	903670125632
    
    9669	93489561	903950565309
    
    9670	93508900	904231063000
    
    9671	93528241	904511618711
    
    9672	93547584	904792232448
    
    9673	93566929	905072904217
    
    9674	93586276	905353634024
    
    9675	93605625	905634421875
    
    9676	93624976	905915267776
    
    9677	93644329	906196171733
    
    9678	93663684	906477133752
    
    9679	93683041	906758153839
    
    9680	93702400	907039232000
    
    9681	93721761	907320368241
    
    9682	93741124	907601562568
    
    9683	93760489	907882814987
    
    9684	93779856	908164125504
    
    9685	93799225	908445494125
    
    9686	93818596	908726920856
    
    9687	93837969	909008405703
    
    9688	93857344	909289948672
    
    9689	93876721	909571549769
    
    9690	93896100	909853209000
    
    9691	93915481	910134926371
    
    9692	93934864	910416701888
    
    9693	93954249	910698535557
    
    9694	93973636	910980427384
    
    9695	93993025	911262377375
    
    9696	94012416	911544385536
    
    9697	94031809	911826451873
    
    9698	94051204	912108576392
    
    9699	94070601	912390759099
    
    9700	94090000	912673000000
    
    9701	94109401	912955299101
    
    9702	94128804	913237656408
    
    9703	94148209	913520071927
    
    9704	94167616	913802545664
    
    9705	94187025	914085077625
    
    9706	94206436	914367667816
    
    9707	94225849	914650316243
    
    9708	94245264	914933022912
    
    9709	94264681	915215787829
    
    9710	94284100	915498611000
    
    9711	94303521	915781492431
    
    9712	94322944	916064432128
    
    9713	94342369	916347430097
    
    9714	94361796	916630486344
    
    9715	94381225	916913600875
    
    9716	94400656	917196773696
    
    9717	94420089	917480004813
    
    9718	94439524	917763294232
    
    9719	94458961	918046641959
    
    9720	94478400	918330048000
    
    9721	94497841	918613512361
    
    9722	94517284	918897035048
    
    9723	94536729	919180616067
    
    9724	94556176	919464255424
    
    9725	94575625	919747953125
    
    9726	94595076	920031709176
    
    9727	94614529	920315523583
    
    9728	94633984	920599396352
    
    9729	94653441	920883327489
    
    9730	94672900	921167317000
    
    9731	94692361	921451364891
    
    9732	94711824	921735471168
    
    9733	94731289	922019635837
    
    9734	94750756	922303858904
    
    9735	94770225	922588140375
    
    9736	94789696	922872480256
    
    9737	94809169	923156878553
    
    9738	94828644	923441335272
    
    9739	94848121	923725850419
    
    9740	94867600	924010424000
    
    9741	94887081	924295056021
    
    9742	94906564	924579746488
    
    9743	94926049	924864495407
    
    9744	94945536	925149302784
    
    9745	94965025	925434168625
    
    9746	94984516	925719092936
    
    9747	95004009	926004075723
    
    9748	95023504	926289116992
    
    9749	95043001	926574216749
    
    9750	95062500	926859375000
    
    9751	95082001	927144591751
    
    9752	95101504	927429867008
    
    9753	95121009	927715200777
    
    9754	95140516	928000593064
    
    9755	95160025	928286043875
    
    9756	95179536	928571553216
    
    9757	95199049	928857121093
    
    9758	95218564	929142747512
    
    9759	95238081	929428432479
    
    9760	95257600	929714176000
    
    9761	95277121	929999978081
    
    9762	95296644	930285838728
    
    9763	95316169	930571757947
    
    9764	95335696	930857735744
    
    9765	95355225	931143772125
    
    9766	95374756	931429867096
    
    9767	95394289	931716020663
    
    9768	95413824	932002232832
    
    9769	95433361	932288503609
    
    9770	95452900	932574833000
    
    9771	95472441	932861221011
    
    9772	95491984	933147667648
    
    9773	95511529	933434172917
    
    9774	95531076	933720736824
    
    9775	95550625	934007359375
    
    9776	95570176	934294040576
    
    9777	95589729	934580780433
    
    9778	95609284	934867578952
    
    9779	95628841	935154436139
    
    9780	95648400	935441352000
    
    9781	95667961	935728326541
    
    9782	95687524	936015359768
    
    9783	95707089	936302451687
    
    9784	95726656	936589602304
    
    9785	95746225	936876811625
    
    9786	95765796	937164079656
    
    9787	95785369	937451406403
    
    9788	95804944	937738791872
    
    9789	95824521	938026236069
    
    9790	95844100	938313739000
    
    9791	95863681	938601300671
    
    9792	95883264	938888921088
    
    9793	95902849	939176600257
    
    9794	95922436	939464338184
    
    9795	95942025	939752134875
    
    9796	95961616	940039990336
    
    9797	95981209	940327904573
    
    9798	96000804	940615877592
    
    9799	96020401	940903909399
    
    9800	96040000	941192000000
    
    9801	96059601	941480149401
    
    9802	96079204	941768357608
    
    9803	96098809	942056624627
    
    9804	96118416	942344950464
    
    9805	96138025	942633335125
    
    9806	96157636	942921778616
    
    9807	96177249	943210280943
    
    9808	96196864	943498842112
    
    9809	96216481	943787462129
    
    9810	96236100	944076141000
    
    9811	96255721	944364878731
    
    9812	96275344	944653675328
    
    9813	96294969	944942530797
    
    9814	96314596	945231445144
    
    9815	96334225	945520418375
    
    9816	96353856	945809450496
    
    9817	96373489	946098541513
    
    9818	96393124	946387691432
    
    9819	96412761	946676900259
    
    9820	96432400	946966168000
    
    9821	96452041	947255494661
    
    9822	96471684	947544880248
    
    9823	96491329	947834324767
    
    9824	96510976	948123828224
    
    9825	96530625	948413390625
    
    9826	96550276	948703011976
    
    9827	96569929	948992692283
    
    9828	96589584	949282431552
    
    9829	96609241	949572229789
    
    9830	96628900	949862087000
    
    9831	96648561	950152003191
    
    9832	96668224	950441978368
    
    9833	96687889	950732012537
    
    9834	96707556	951022105704
    
    9835	96727225	951312257875
    
    9836	96746896	951602469056
    
    9837	96766569	951892739253
    
    9838	96786244	952183068472
    
    9839	96805921	952473456719
    
    9840	96825600	952763904000
    
    9841	96845281	953054410321
    
    9842	96864964	953344975688
    
    9843	96884649	953635600107
    
    9844	96904336	953926283584
    
    9845	96924025	954217026125
    
    9846	96943716	954507827736
    
    9847	96963409	954798688423
    
    9848	96983104	955089608192
    
    9849	97002801	955380587049
    
    9850	97022500	955671625000
    
    9851	97042201	955962722051
    
    9852	97061904	956253878208
    
    9853	97081609	956545093477
    
    9854	97101316	956836367864
    
    9855	97121025	957127701375
    
    9856	97140736	957419094016
    
    9857	97160449	957710545793
    
    9858	97180164	958002056712
    
    9859	97199881	958293626779
    
    9860	97219600	958585256000
    
    9861	97239321	958876944381
    
    9862	97259044	959168691928
    
    9863	97278769	959460498647
    
    9864	97298496	959752364544
    
    9865	97318225	960044289625
    
    9866	97337956	960336273896
    
    9867	97357689	960628317363
    
    9868	97377424	960920420032
    
    9869	97397161	961212581909
    
    9870	97416900	961504803000
    
    9871	97436641	961797083311
    
    9872	97456384	962089422848
    
    9873	97476129	962381821617
    
    9874	97495876	962674279624
    
    9875	97515625	962966796875
    
    9876	97535376	963259373376
    
    9877	97555129	963552009133
    
    9878	97574884	963844704152
    
    9879	97594641	964137458439
    
    9880	97614400	964430272000
    
    9881	97634161	964723144841
    
    9882	97653924	965016076968
    
    9883	97673689	965309068387
    
    9884	97693456	965602119104
    
    9885	97713225	965895229125
    
    9886	97732996	966188398456
    
    9887	97752769	966481627103
    
    9888	97772544	966774915072
    
    9889	97792321	967068262369
    
    9890	97812100	967361669000
    
    9891	97831881	967655134971
    
    9892	97851664	967948660288
    
    9893	97871449	968242244957
    
    9894	97891236	968535888984
    
    9895	97911025	968829592375
    
    9896	97930816	969123355136
    
    9897	97950609	969417177273
    
    9898	97970404	969711058792
    
    9899	97990201	970004999699
    
    9900	98010000	970299000000
    
    9901	98029801	970593059701
    
    9902	98049604	970887178808
    
    9903	98069409	971181357327
    
    9904	98089216	971475595264
    
    9905	98109025	971769892625
    
    9906	98128836	972064249416
    
    9907	98148649	972358665643
    
    9908	98168464	972653141312
    
    9909	98188281	972947676429
    
    9910	98208100	973242271000
    
    9911	98227921	973536925031
    
    9912	98247744	973831638528
    
    9913	98267569	974126411497
    
    9914	98287396	974421243944
    
    9915	98307225	974716135875
    
    9916	98327056	975011087296
    
    9917	98346889	975306098213
    
    9918	98366724	975601168632
    
    9919	98386561	975896298559
    
    9920	98406400	976191488000
    
    9921	98426241	976486736961
    
    9922	98446084	976782045448
    
    9923	98465929	977077413467
    
    9924	98485776	977372841024
    
    9925	98505625	977668328125
    
    9926	98525476	977963874776
    
    9927	98545329	978259480983
    
    9928	98565184	978555146752
    
    9929	98585041	978850872089
    
    9930	98604900	979146657000
    
    9931	98624761	979442501491
    
    9932	98644624	979738405568
    
    9933	98664489	980034369237
    
    9934	98684356	980330392504
    
    9935	98704225	980626475375
    
    9936	98724096	980922617856
    
    9937	98743969	981218819953
    
    9938	98763844	981515081672
    
    9939	98783721	981811403019
    
    9940	98803600	982107784000
    
    9941	98823481	982404224621
    
    9942	98843364	982700724888
    
    9943	98863249	982997284807
    
    9944	98883136	983293904384
    
    9945	98903025	983590583625
    
    9946	98922916	983887322536
    
    9947	98942809	984184121123
    
    9948	98962704	984480979392
    
    9949	98982601	984777897349
    
    9950	99002500	985074875000
    
    9951	99022401	985371912351
    
    9952	99042304	985669009408
    
    9953	99062209	985966166177
    
    9954	99082116	986263382664
    
    9955	99102025	986560658875
    
    9956	99121936	986857994816
    
    9957	99141849	987155390493
    
    9958	99161764	987452845912
    
    9959	99181681	987750361079
    
    9960	99201600	988047936000
    
    9961	99221521	988345570681
    
    9962	99241444	988643265128
    
    9963	99261369	988941019347
    
    9964	99281296	989238833344
    
    9965	99301225	989536707125
    
    9966	99321156	989834640696
    
    9967	99341089	990132634063
    
    9968	99361024	990430687232
    
    9969	99380961	990728800209
    
    9970	99400900	991026973000
    
    9971	99420841	991325205611
    
    9972	99440784	991623498048
    
    9973	99460729	991921850317
    
    9974	99480676	992220262424
    
    9975	99500625	992518734375
    
    9976	99520576	992817266176
    
    9977	99540529	993115857833
    
    9978	99560484	993414509352
    
    9979	99580441	993713220739
    
    9980	99600400	994011992000
    
    9981	99620361	994310823141
    
    9982	99640324	994609714168
    
    9983	99660289	994908665087
    
    9984	99680256	995207675904
    
    9985	99700225	995506746625
    
    9986	99720196	995805877256
    
    9987	99740169	996105067803
    
    9988	99760144	996404318272
    
    9989	99780121	996703628669
    
    9990	99800100	997002999000
    
    9991	99820081	997302429271
    
    9992	99840064	997601919488
    
    9993	99860049	997901469657
    
    9994	99880036	998201079784
    
    9995	99900025	998500749875
    
    9996	99920016	998800479936
    
    9997	99940009	999100269973
    
    9998	99960004	999400119992
    
    9999	99980001	999700029999
    
    


```python
import pandas as pd
```


```python
help(pd.read_csv)
```

    Help on function read_csv in module pandas.io.parsers:
    
    read_csv(filepath_or_buffer, sep=',', delimiter=None, header='infer', names=None, index_col=None, usecols=None, squeeze=False, prefix=None, mangle_dupe_cols=True, dtype=None, engine=None, converters=None, true_values=None, false_values=None, skipinitialspace=False, skiprows=None, skipfooter=0, nrows=None, na_values=None, keep_default_na=True, na_filter=True, verbose=False, skip_blank_lines=True, parse_dates=False, infer_datetime_format=False, keep_date_col=False, date_parser=None, dayfirst=False, iterator=False, chunksize=None, compression='infer', thousands=None, decimal=b'.', lineterminator=None, quotechar='"', quoting=0, doublequote=True, escapechar=None, comment=None, encoding=None, dialect=None, tupleize_cols=None, error_bad_lines=True, warn_bad_lines=True, delim_whitespace=False, low_memory=True, memory_map=False, float_precision=None)
        Read a comma-separated values (csv) file into DataFrame.
        
        Also supports optionally iterating or breaking of the file
        into chunks.
        
        Additional help can be found in the online docs for
        `IO Tools <http://pandas.pydata.org/pandas-docs/stable/io.html>`_.
        
        Parameters
        ----------
        filepath_or_buffer : str, path object, or file-like object
            Any valid string path is acceptable. The string could be a URL. Valid
            URL schemes include http, ftp, s3, and file. For file URLs, a host is
            expected. A local file could be: file://localhost/path/to/table.csv.
        
            If you want to pass in a path object, pandas accepts either
            ``pathlib.Path`` or ``py._path.local.LocalPath``.
        
            By file-like object, we refer to objects with a ``read()`` method, such as
            a file handler (e.g. via builtin ``open`` function) or ``StringIO``.
        sep : str, default ','
            Delimiter to use. If sep is None, the C engine cannot automatically detect
            the separator, but the Python parsing engine can, meaning the latter will
            be used and automatically detect the separator by Python's builtin sniffer
            tool, ``csv.Sniffer``. In addition, separators longer than 1 character and
            different from ``'\s+'`` will be interpreted as regular expressions and
            will also force the use of the Python parsing engine. Note that regex
            delimiters are prone to ignoring quoted data. Regex example: ``'\r\t'``.
        delimiter : str, default ``None``
            Alias for sep.
        header : int, list of int, default 'infer'
            Row number(s) to use as the column names, and the start of the
            data.  Default behavior is to infer the column names: if no names
            are passed the behavior is identical to ``header=0`` and column
            names are inferred from the first line of the file, if column
            names are passed explicitly then the behavior is identical to
            ``header=None``. Explicitly pass ``header=0`` to be able to
            replace existing names. The header can be a list of integers that
            specify row locations for a multi-index on the columns
            e.g. [0,1,3]. Intervening rows that are not specified will be
            skipped (e.g. 2 in this example is skipped). Note that this
            parameter ignores commented lines and empty lines if
            ``skip_blank_lines=True``, so ``header=0`` denotes the first line of
            data rather than the first line of the file.
        names : array-like, optional
            List of column names to use. If file contains no header row, then you
            should explicitly pass ``header=None``. Duplicates in this list will cause
            a ``UserWarning`` to be issued.
        index_col : int, sequence or bool, optional
            Column to use as the row labels of the DataFrame. If a sequence is given, a
            MultiIndex is used. If you have a malformed file with delimiters at the end
            of each line, you might consider ``index_col=False`` to force pandas to
            not use the first column as the index (row names).
        usecols : list-like or callable, optional
            Return a subset of the columns. If list-like, all elements must either
            be positional (i.e. integer indices into the document columns) or strings
            that correspond to column names provided either by the user in `names` or
            inferred from the document header row(s). For example, a valid list-like
            `usecols` parameter would be ``[0, 1, 2]`` or ``['foo', 'bar', 'baz']``.
            Element order is ignored, so ``usecols=[0, 1]`` is the same as ``[1, 0]``.
            To instantiate a DataFrame from ``data`` with element order preserved use
            ``pd.read_csv(data, usecols=['foo', 'bar'])[['foo', 'bar']]`` for columns
            in ``['foo', 'bar']`` order or
            ``pd.read_csv(data, usecols=['foo', 'bar'])[['bar', 'foo']]``
            for ``['bar', 'foo']`` order.
        
            If callable, the callable function will be evaluated against the column
            names, returning names where the callable function evaluates to True. An
            example of a valid callable argument would be ``lambda x: x.upper() in
            ['AAA', 'BBB', 'DDD']``. Using this parameter results in much faster
            parsing time and lower memory usage.
        squeeze : bool, default False
            If the parsed data only contains one column then return a Series.
        prefix : str, optional
            Prefix to add to column numbers when no header, e.g. 'X' for X0, X1, ...
        mangle_dupe_cols : bool, default True
            Duplicate columns will be specified as 'X', 'X.1', ...'X.N', rather than
            'X'...'X'. Passing in False will cause data to be overwritten if there
            are duplicate names in the columns.
        dtype : Type name or dict of column -> type, optional
            Data type for data or columns. E.g. {'a': np.float64, 'b': np.int32,
            'c': 'Int64'}
            Use `str` or `object` together with suitable `na_values` settings
            to preserve and not interpret dtype.
            If converters are specified, they will be applied INSTEAD
            of dtype conversion.
        engine : {'c', 'python'}, optional
            Parser engine to use. The C engine is faster while the python engine is
            currently more feature-complete.
        converters : dict, optional
            Dict of functions for converting values in certain columns. Keys can either
            be integers or column labels.
        true_values : list, optional
            Values to consider as True.
        false_values : list, optional
            Values to consider as False.
        skipinitialspace : bool, default False
            Skip spaces after delimiter.
        skiprows : list-like, int or callable, optional
            Line numbers to skip (0-indexed) or number of lines to skip (int)
            at the start of the file.
        
            If callable, the callable function will be evaluated against the row
            indices, returning True if the row should be skipped and False otherwise.
            An example of a valid callable argument would be ``lambda x: x in [0, 2]``.
        skipfooter : int, default 0
            Number of lines at bottom of file to skip (Unsupported with engine='c').
        nrows : int, optional
            Number of rows of file to read. Useful for reading pieces of large files.
        na_values : scalar, str, list-like, or dict, optional
            Additional strings to recognize as NA/NaN. If dict passed, specific
            per-column NA values.  By default the following values are interpreted as
            NaN: '', '#N/A', '#N/A N/A', '#NA', '-1.#IND', '-1.#QNAN', '-NaN', '-nan',
            '1.#IND', '1.#QNAN', 'N/A', 'NA', 'NULL', 'NaN', 'n/a', 'nan',
            'null'.
        keep_default_na : bool, default True
            Whether or not to include the default NaN values when parsing the data.
            Depending on whether `na_values` is passed in, the behavior is as follows:
        
            * If `keep_default_na` is True, and `na_values` are specified, `na_values`
              is appended to the default NaN values used for parsing.
            * If `keep_default_na` is True, and `na_values` are not specified, only
              the default NaN values are used for parsing.
            * If `keep_default_na` is False, and `na_values` are specified, only
              the NaN values specified `na_values` are used for parsing.
            * If `keep_default_na` is False, and `na_values` are not specified, no
              strings will be parsed as NaN.
        
            Note that if `na_filter` is passed in as False, the `keep_default_na` and
            `na_values` parameters will be ignored.
        na_filter : bool, default True
            Detect missing value markers (empty strings and the value of na_values). In
            data without any NAs, passing na_filter=False can improve the performance
            of reading a large file.
        verbose : bool, default False
            Indicate number of NA values placed in non-numeric columns.
        skip_blank_lines : bool, default True
            If True, skip over blank lines rather than interpreting as NaN values.
        parse_dates : bool or list of int or names or list of lists or dict, default False
            The behavior is as follows:
        
            * boolean. If True -> try parsing the index.
            * list of int or names. e.g. If [1, 2, 3] -> try parsing columns 1, 2, 3
              each as a separate date column.
            * list of lists. e.g.  If [[1, 3]] -> combine columns 1 and 3 and parse as
              a single date column.
            * dict, e.g. {'foo' : [1, 3]} -> parse columns 1, 3 as date and call
              result 'foo'
        
            If a column or index cannot be represented as an array of datetimes,
            say because of an unparseable value or a mixture of timezones, the column
            or index will be returned unaltered as an object data type. For
            non-standard datetime parsing, use ``pd.to_datetime`` after
            ``pd.read_csv``. To parse an index or column with a mixture of timezones,
            specify ``date_parser`` to be a partially-applied
            :func:`pandas.to_datetime` with ``utc=True``. See
            :ref:`io.csv.mixed_timezones` for more.
        
            Note: A fast-path exists for iso8601-formatted dates.
        infer_datetime_format : bool, default False
            If True and `parse_dates` is enabled, pandas will attempt to infer the
            format of the datetime strings in the columns, and if it can be inferred,
            switch to a faster method of parsing them. In some cases this can increase
            the parsing speed by 5-10x.
        keep_date_col : bool, default False
            If True and `parse_dates` specifies combining multiple columns then
            keep the original columns.
        date_parser : function, optional
            Function to use for converting a sequence of string columns to an array of
            datetime instances. The default uses ``dateutil.parser.parser`` to do the
            conversion. Pandas will try to call `date_parser` in three different ways,
            advancing to the next if an exception occurs: 1) Pass one or more arrays
            (as defined by `parse_dates`) as arguments; 2) concatenate (row-wise) the
            string values from the columns defined by `parse_dates` into a single array
            and pass that; and 3) call `date_parser` once for each row using one or
            more strings (corresponding to the columns defined by `parse_dates`) as
            arguments.
        dayfirst : bool, default False
            DD/MM format dates, international and European format.
        iterator : bool, default False
            Return TextFileReader object for iteration or getting chunks with
            ``get_chunk()``.
        chunksize : int, optional
            Return TextFileReader object for iteration.
            See the `IO Tools docs
            <http://pandas.pydata.org/pandas-docs/stable/io.html#io-chunking>`_
            for more information on ``iterator`` and ``chunksize``.
        compression : {'infer', 'gzip', 'bz2', 'zip', 'xz', None}, default 'infer'
            For on-the-fly decompression of on-disk data. If 'infer' and
            `filepath_or_buffer` is path-like, then detect compression from the
            following extensions: '.gz', '.bz2', '.zip', or '.xz' (otherwise no
            decompression). If using 'zip', the ZIP file must contain only one data
            file to be read in. Set to None for no decompression.
        
            .. versionadded:: 0.18.1 support for 'zip' and 'xz' compression.
        
        thousands : str, optional
            Thousands separator.
        decimal : str, default '.'
            Character to recognize as decimal point (e.g. use ',' for European data).
        lineterminator : str (length 1), optional
            Character to break file into lines. Only valid with C parser.
        quotechar : str (length 1), optional
            The character used to denote the start and end of a quoted item. Quoted
            items can include the delimiter and it will be ignored.
        quoting : int or csv.QUOTE_* instance, default 0
            Control field quoting behavior per ``csv.QUOTE_*`` constants. Use one of
            QUOTE_MINIMAL (0), QUOTE_ALL (1), QUOTE_NONNUMERIC (2) or QUOTE_NONE (3).
        doublequote : bool, default ``True``
           When quotechar is specified and quoting is not ``QUOTE_NONE``, indicate
           whether or not to interpret two consecutive quotechar elements INSIDE a
           field as a single ``quotechar`` element.
        escapechar : str (length 1), optional
            One-character string used to escape other characters.
        comment : str, optional
            Indicates remainder of line should not be parsed. If found at the beginning
            of a line, the line will be ignored altogether. This parameter must be a
            single character. Like empty lines (as long as ``skip_blank_lines=True``),
            fully commented lines are ignored by the parameter `header` but not by
            `skiprows`. For example, if ``comment='#'``, parsing
            ``#empty\na,b,c\n1,2,3`` with ``header=0`` will result in 'a,b,c' being
            treated as the header.
        encoding : str, optional
            Encoding to use for UTF when reading/writing (ex. 'utf-8'). `List of Python
            standard encodings
            <https://docs.python.org/3/library/codecs.html#standard-encodings>`_ .
        dialect : str or csv.Dialect, optional
            If provided, this parameter will override values (default or not) for the
            following parameters: `delimiter`, `doublequote`, `escapechar`,
            `skipinitialspace`, `quotechar`, and `quoting`. If it is necessary to
            override values, a ParserWarning will be issued. See csv.Dialect
            documentation for more details.
        tupleize_cols : bool, default False
            Leave a list of tuples on columns as is (default is to convert to
            a MultiIndex on the columns).
        
            .. deprecated:: 0.21.0
               This argument will be removed and will always convert to MultiIndex
        
        error_bad_lines : bool, default True
            Lines with too many fields (e.g. a csv line with too many commas) will by
            default cause an exception to be raised, and no DataFrame will be returned.
            If False, then these "bad lines" will dropped from the DataFrame that is
            returned.
        warn_bad_lines : bool, default True
            If error_bad_lines is False, and warn_bad_lines is True, a warning for each
            "bad line" will be output.
        delim_whitespace : bool, default False
            Specifies whether or not whitespace (e.g. ``' '`` or ``'    '``) will be
            used as the sep. Equivalent to setting ``sep='\s+'``. If this option
            is set to True, nothing should be passed in for the ``delimiter``
            parameter.
        
            .. versionadded:: 0.18.1 support for the Python parser.
        
        low_memory : bool, default True
            Internally process the file in chunks, resulting in lower memory use
            while parsing, but possibly mixed type inference.  To ensure no mixed
            types either set False, or specify the type with the `dtype` parameter.
            Note that the entire file is read into a single DataFrame regardless,
            use the `chunksize` or `iterator` parameter to return the data in chunks.
            (Only valid with C parser).
        memory_map : bool, default False
            If a filepath is provided for `filepath_or_buffer`, map the file object
            directly onto memory and access the data directly from there. Using this
            option can improve performance because there is no longer any I/O overhead.
        float_precision : str, optional
            Specifies which converter the C engine should use for floating-point
            values. The options are `None` for the ordinary converter,
            `high` for the high-precision converter, and `round_trip` for the
            round-trip converter.
        
        Returns
        -------
        DataFrame or TextParser
            A comma-separated values (csv) file is returned as two-dimensional
            data structure with labeled axes.
        
        See Also
        --------
        to_csv : Write DataFrame to a comma-separated values (csv) file.
        read_csv : Read a comma-separated values (csv) file into DataFrame.
        read_fwf : Read a table of fixed-width formatted lines into DataFrame.
        
        Examples
        --------
        >>> pd.read_csv('data.csv')  # doctest: +SKIP
    
    


```python
import json
data_dict = {'a':1, 'b':2, 'c':3}
with open('save_dict.json', 'w') as f:
    json.dump(data_dict, f)
```


```python
dd = json.load(open("save_dict.json"))
dd
```




    {'a': 1, 'b': 2, 'c': 3}




```python
data_list = list(range(10))
with open('save_list.json', 'w') as f:
    json.dump(data_list, f)
```


```python
dl = json.load(open("save_list.json"))
dl
```




    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]




```python
%matplotlib inline

import matplotlib.pyplot as plt
x = range(1, 100)
y = [i**-3 for i in x]
plt.plot(x, y, 'b-s')
plt.ylabel('$p(k)$', fontsize = 20)
plt.xlabel('$k$', fontsize = 20)
plt.xscale('log')
plt.yscale('log')
plt.title('Degree Distribution', fontsize = 20)
plt.show()
```


![png](output_62_0.png)



```python
import numpy as np
# red dashes, blue squares and green triangles
t = np.arange(0., 5., 0.2)
plt.plot(t, t, 'r--')
plt.plot(t, t**2, 'bs')
plt.plot(t, t**3, 'g^')
plt.show()
```


![png](output_63_0.png)



```python
# red dashes, blue squares and green triangles
t = np.arange(0., 5., 0.2)
plt.plot(t, t**2, 'b-s', label = '1')
plt.plot(t, t**2.5, 'r-o', label = '2')
plt.plot(t, t**3, 'g-^', label = '3')
plt.annotate(r'$\alpha = 3$', xy=(3.5, 40), xytext=(2, 80),
            arrowprops=dict(facecolor='black', shrink=0.05),
            fontsize = 20)
plt.ylabel('$f(t)$', fontsize = 20)
plt.xlabel('$t$', fontsize = 20)
plt.legend(loc=0,numpoints=1,fontsize=10)
plt.show()
# plt.savefig('/Users/chengjun/GitHub/cjc/figure/save_figure.png',
#             dpi = 300, bbox_inches="tight",transparent = True)
```


![png](output_64_0.png)



```python
plt.figure(1)
plt.subplot(221)
plt.plot(t, t, 'r--')
plt.text(2, 0.8*np.max(t), r'$\alpha = 1$', fontsize = 20)
plt.subplot(222)
plt.plot(t, t**2, 'bs')
plt.text(2, 0.8*np.max(t**2), r'$\alpha = 2$', fontsize = 20)
plt.subplot(223)
plt.plot(t, t**3, 'g^')
plt.text(2, 0.8*np.max(t**3), r'$\alpha = 3$', fontsize = 20)
plt.subplot(224)
plt.plot(t, t**4, 'r-o')
plt.text(2, 0.8*np.max(t**4), r'$\alpha = 4$', fontsize = 20)
plt.show()
```


![png](output_65_0.png)



```python
def f(t):
    return np.exp(-t) * np.cos(2*np.pi*t)

t1 = np.arange(0.0, 5.0, 0.1)
t2 = np.arange(0.0, 5.0, 0.02)
```


```python
plt.figure(1)
plt.subplot(211)
plt.plot(t1, f(t1), 'bo')
plt.plot(t2, f(t2), 'k')

plt.subplot(212)
plt.plot(t2, np.cos(2*np.pi*t2), 'r--')
plt.show()
```


![png](output_67_0.png)



```python

import matplotlib.gridspec as gridspec
import numpy as np

t = np.arange(0., 5., 0.2)

gs = gridspec.GridSpec(3, 3)
ax1 = plt.subplot(gs[0, :])
plt.plot(t, t**2, 'b-s')
ax2 = plt.subplot(gs[1,:-1])
plt.plot(t, t**2, 'g-s')
ax3 = plt.subplot(gs[1:, -1])
plt.plot(t, t**2, 'r-o')
ax4 = plt.subplot(gs[-1,0])
plt.plot(t, t**2, 'g-^')
ax5 = plt.subplot(gs[-1,1])
plt.plot(t, t**2, 'b-<')
plt.tight_layout()
```


![png](output_68_0.png)



```python
def OLSRegressPlot(x,y,col,xlab,ylab):
    xx = sm.add_constant(x, prepend=True)
    res = sm.OLS(y,xx).fit()
    constant, beta = res.params
    r2 = res.rsquared
    lab = r'$\beta = %.2f, \,R^2 = %.2f$' %(beta,r2)
    plt.scatter(x,y,s=60,facecolors='none', edgecolors=col)
    plt.plot(x,constant + x*beta,"red",label=lab)
    plt.legend(loc = 'upper left',fontsize=16)
    plt.xlabel(xlab,fontsize=26)
    plt.ylabel(ylab,fontsize=26)
```


```python
x = np.random.randn(50)
y = np.random.randn(50) + 3*x
pearsonr(x, y)
fig = plt.figure(figsize=(10, 4),facecolor='white')
OLSRegressPlot(x,y,'RoyalBlue',r'$x$',r'$y$')
plt.show()
```


![png](output_70_0.png)



```python
fig = plt.figure(figsize=(7, 4),facecolor='white')
data = norm.rvs(10.0, 2.5, size=5000)
mu, std = norm.fit(data)
plt.hist(data, bins=25, normed=True, alpha=0.6, color='g')
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'r', linewidth=2)
title = r"$\mu = %.2f, \,  \sigma = %.2f$" % (mu, std)
plt.title(title,size=16)
plt.show()
```

    D:\PH\lib\site-packages\ipykernel_launcher.py:4: MatplotlibDeprecationWarning: 
    The 'normed' kwarg was deprecated in Matplotlib 2.1 and will be removed in 3.1. Use 'density' instead.
      after removing the cwd from sys.path.
    


![png](output_71_1.png)



```python

import pandas as pd
df = pd.read_csv('data_write_to_file.txt', sep = '\t', names = ['a', 'b', 'c'])
df[:5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>a</th>
      <th>b</th>
      <th>c</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>4</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>9</td>
      <td>27</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>16</td>
      <td>64</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.plot.line()
plt.yscale('log')
plt.ylabel('$values$', fontsize = 20)
plt.xlabel('$index$', fontsize = 20)
plt.show()
```


![png](output_73_0.png)



```python
df.plot.scatter(x='a', y='b')
plt.show()
```


![png](output_74_0.png)



```python

df.plot.hexbin(x='a', y='b', gridsize=25)
plt.show()
```


![png](output_75_0.png)



```python
df['a'].plot.kde()
plt.show()
```


![png](output_76_0.png)



```python
bp = df.boxplot()
plt.yscale('log')
plt.show()
```


![png](output_77_0.png)



```python
df['c'].diff().hist()
plt.show()
```


![png](output_78_0.png)



```python
df.plot.hist(stacked=True, bins=20)
# plt.yscale('log')
plt.show()
```


![png](output_79_0.png)



```python

```
